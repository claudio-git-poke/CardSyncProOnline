// ── coda_pendente.js ─────────────────────────────────────────────────────────
// Colonna "Coda pendente" nell'hub (app.html): pannello NATIVO (non un
// iframe di un'altra pagina) che mostra, in sola lettura, cosa c'è in questo
// momento nella coda condivisa 'coda_carte' — utile per verificare che gli
// inserimenti fatti dal sito siano stati presi in carico da un'estensione,
// e per Claudio per capire se qualcosa si è bloccato. Non scrive MAI nulla
// su 'coda_carte': solo SELECT, stesso principio già usato per
// 'leggiAnteprima' in supabase_adapter.js, ma qui in una query diretta
// (nessuna nuova azione nel dispatcher centrale, per non toccarlo).
//
// Stati possibili di una riga (vedi contrassegnaEsitoERimuovi in
// aggiungi_carta_popup.js): 'pending' (in attesa che qualcuno la prenda in
// carico), 'in_corso' (un dispositivo la sta processando), 'completato'
// (finita bene — non mostrata qui), 'errore' (finita male — mostrata tra
// gli "Errori recenti" per un po', poi sparisce da sola da questa vista).

(function () {
  const INTERVALLO_AGGIORNAMENTO_MS = 15000;
  const FINESTRA_ERRORI_RECENTI_MIN = 15;

  const elAttive = document.getElementById('codaPendenteAttive');
  const elErrori = document.getElementById('codaPendenteErrori');
  const elUltimoAgg = document.getElementById('codaPendenteUltimoAgg');
  if (!elAttive || !elErrori || !elUltimoAgg) return; // colonna non presente in questa pagina

  function escapeHtml(testo) {
    const div = document.createElement('div');
    div.textContent = testo == null ? '' : String(testo);
    return div.innerHTML;
  }

  function etichettaTipo(riga) {
    const parti = [];
    parti.push(riga.destinazione === 'wishlist' ? 'Wishlist' : (riga.tipo === 'sealed' ? 'Sealed' : 'Carta'));
    if (riga.qty && riga.qty > 1) parti.push('x' + riga.qty);
    return parti.join(' · ');
  }

  function renderRigaAttiva(riga) {
    const badgeClasse = riga.stato === 'in_corso' ? 'in_corso' : 'pending';
    const badgeTesto = riga.stato === 'in_corso' ? 'In corso' : 'In attesa';
    const chi = riga.stato === 'in_corso' && riga.dispositivo ? ` · preso in carico da ${escapeHtml(riga.dispositivo)}` : '';
    return `
      <div class="coda-pendente-item">
        <div class="coda-pendente-item-riga1">
          <span class="coda-pendente-nome">${escapeHtml(riga.nome || '(senza nome)')}</span>
          <span class="coda-pendente-badge ${badgeClasse}">${badgeTesto}</span>
        </div>
        <span class="coda-pendente-sotto">${escapeHtml(etichettaTipo(riga))}${chi}</span>
      </div>
    `;
  }

  function renderRigaErrore(riga) {
    return `
      <div class="coda-pendente-item">
        <div class="coda-pendente-item-riga1">
          <span class="coda-pendente-nome">${escapeHtml(riga.nome || '(senza nome)')}</span>
          <span class="coda-pendente-badge errore">Errore</span>
        </div>
        <span class="coda-pendente-sotto">${escapeHtml(riga.errore_msg || 'Errore non specificato')}</span>
      </div>
    `;
  }

  async function aggiornaCodaPendente() {
    try {
      const { data: sessionData } = await supabaseClient.auth.getSession();
      if (!sessionData || !sessionData.session) {
        elAttive.innerHTML = '<p class="coda-pendente-vuoto">Accedi per vedere la coda.</p>';
        elErrori.innerHTML = '';
        return;
      }

      const { data: attive, error: errAttive } = await supabaseClient
        .from('coda_carte')
        .select('nome, tipo, destinazione, qty, stato, dispositivo, creato_il')
        .in('stato', ['pending', 'in_corso'])
        .order('creato_il', { ascending: true })
        .limit(100);

      if (errAttive) {
        elAttive.innerHTML = '<p class="coda-pendente-vuoto">Errore nel leggere la coda: ' + escapeHtml(errAttive.message) + '</p>';
      } else if (!attive || attive.length === 0) {
        elAttive.innerHTML = '<p class="coda-pendente-vuoto">Nessuna riga in attesa o in corso — tutto elaborato.</p>';
      } else {
        elAttive.innerHTML = attive.map(renderRigaAttiva).join('');
      }

      const sogliaIso = new Date(Date.now() - FINESTRA_ERRORI_RECENTI_MIN * 60 * 1000).toISOString();
      const { data: errori, error: errErrori } = await supabaseClient
        .from('coda_carte')
        .select('nome, errore_msg, completato_il')
        .eq('stato', 'errore')
        .gte('completato_il', sogliaIso)
        .order('completato_il', { ascending: false })
        .limit(50);

      if (errErrori) {
        elErrori.innerHTML = '<p class="coda-pendente-vuoto">Errore nel leggere gli errori: ' + escapeHtml(errErrori.message) + '</p>';
      } else if (!errori || errori.length === 0) {
        elErrori.innerHTML = '<p class="coda-pendente-vuoto">Nessun errore negli ultimi ' + FINESTRA_ERRORI_RECENTI_MIN + ' minuti.</p>';
      } else {
        elErrori.innerHTML = errori.map(renderRigaErrore).join('');
      }

      elUltimoAgg.textContent = 'Aggiornato alle ' + new Date().toLocaleTimeString('it-IT', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    } catch (e) {
      elUltimoAgg.textContent = 'Aggiornamento fallito — riprovo tra poco.';
      console.error('[coda_pendente] errore:', e.message);
    }
  }

  aggiornaCodaPendente();
  setInterval(aggiornaCodaPendente, INTERVALLO_AGGIORNAMENTO_MS);
})();
