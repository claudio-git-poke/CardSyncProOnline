// ── COSTANTI ──────────────────────────────────────────────────────────────────
// Colonne del foglio "Wishlist" (scheda separata dall'Inventario, stesso
// Google Sheet — vedi ISTRUZIONI.md). Stesso schema base delle carte, con in
// più la colonna J per il prezzo obiettivo.
const COL = {
  NOME:              'B',
  CODICE:            'C',
  LOCATION:          'D', // prima non esisteva per la wishlist — vedi wishlist_location.sql
  QTY:               'E',
  LINGUA:            'F',
  CONDIZIONE:        'G',
  URL:               'H',
  PREZZO:            'I',
  PREZZO_OBIETTIVO:  'J',
  NOTE:              'K',
  IMMAGINE:          'L', // già recuperata dalla ricerca (background.js), prima mai salvata
};

// Colonne dell'Inventario — usate SOLO quando si clicca "✓ Comprata" per
// scrivere la riga nel foglio principale. Stesso schema di aggiungi_carta_popup.js.
const COL_INVENTARIO = {
  NOME:       'B',
  CODICE:     'C',
  LOCATION:   'D',
  QTY:        'E',
  LINGUA:     'F',
  CONDIZIONE: 'G',
  URL:        'H',
  NOTE:       'K',
};

// FIX (immagini mancanti/rotte su Wishlist): tutti i punti di questo file
// scrivevano direttamente il link grezzo di Cardmarket (bloccato
// dall'hotlink protection se aperto da un altro dominio), senza mai
// passare per la conversione/caricamento su Supabase Storage — a
// differenza del controllo prezzi delle carte, che lo fa da tempo. Stesso
// schema riusato qui: manda l'URL grezzo a background.js (privilegio di
// estensione, bypassa CORS), che scarica e carica su Storage, restituendo
// il link definitivo. Fallback silenzioso sull'URL grezzo se qualcosa va
// storto, per non bloccare mai l'aggiunta/aggiornamento per questo.
async function _convertiImmagine(urlGrezzo) {
  if (!urlGrezzo) return '';
  try {
    const risposta = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'CONVERTI_IMMAGINE', url: urlGrezzo }, (r) => resolve(r));
    });
    return risposta?.immagine || urlGrezzo;
  } catch (_) {
    return urlGrezzo;
  }
}

const CAMPI_STORAGE = ['selectedTheme'];

const LISTA_TEMI = ['purple', 'green', 'blue', 'contrast', 'dark', 'sakura', 'wine', 'autunno', 'estate', 'heartgold', 'soulsilver', 'steel', 'electric', 'grass', 'pokemon', 'team-rocket'];

// ── SISTEMA PROFILI — GUSCIO VUOTO ──────────────────────────────────────────
// Il vecchio sistema (registro profili su Google Apps Script) è stato
// rimosso con la migrazione a Supabase. La tendina resta come punto di
// aggancio per un futuro sistema profili basato su Supabase.
document.getElementById('selectProfilo')?.addEventListener('change', () => {
  setStatus('ℹ️ Il sistema profili è in aggiornamento — non ancora disponibile.', 'info');
});

const DELAY_SEC_MIN = 1;
const DELAY_SEC_MAX = 60;
const LEGACY_DELAY_RANGES_SEC = [[1,3],[3,7],[5,10],[8,15],[12,20],[20,30],[30,45],[45,60]];
const DEFAULT_DELAY_MIN_SEC = 10;
const DEFAULT_DELAY_MAX_SEC = 20;
const CF_ESCALATION_STEP_SEC = 3;
const CF_ESCALATION_MAX_LEVEL = 5;
const PAUSA_OGNI_LABELS = ['25', '50', '75', '100', 'Mai'];
const PAUSA_OGNI_VALUES = [25, 50, 75, 100, Infinity];
const BULK_MAX_RETRY = 2;

// ── FETCH SUPABASE (leggiWishlist, svuotaRiga, aggiungi) ────────────────────
// L'unica funzione ancora necessaria: reindirizza ogni azione verso Supabase.
async function _chiamaWebApp(payload) {
  return chiamaSupabase(payload.azione, payload);
}

// ── TIMEOUT LETTURA CARTA (stesso pattern delle altre pagine bulk) ──────────
function _timeoutLetturaCarta() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['sliderCfTimeout'], (res) => {
      const minuti = (typeof res.sliderCfTimeout === 'number' && res.sliderCfTimeout >= 1) ? res.sliderCfTimeout : 3;
      resolve(minuti * 60 * 1000 + 20000);
    });
  });
}

// ── INVIO MESSAGGIO RESILIENTE + WATCHDOG (identico alle altre pagine bulk) ──
function _erroreConnessioneSW(msg) {
  if (!msg) return false;
  const m = msg.toLowerCase();
  return m.includes('message port closed') || m.includes('receiving end does not exist')
      || m.includes('context invalidated') || m.includes('could not establish connection');
}

function _inviaMessaggioConRetry(messaggio, timeoutTotaleMs) {
  const scadenza = Date.now() + timeoutTotaleMs;
  return new Promise((resolve, reject) => {
    function tenta() {
      const rimanente = scadenza - Date.now();
      if (rimanente <= 0) { reject(new Error('Timeout')); return; }
      const timeoutId = setTimeout(() => reject(new Error('Timeout')), rimanente);
      chrome.runtime.sendMessage(messaggio, (r) => {
        clearTimeout(timeoutId);
        if (chrome.runtime.lastError) {
          if (_erroreConnessioneSW(chrome.runtime.lastError.message) && Date.now() < scadenza) {
            setTimeout(tenta, 1000);
            return;
          }
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(r);
      });
    }
    tenta();
  });
}

function _nuovoRequestId() {
  return 'r' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

function _pingRichiesta(requestId) {
  return new Promise((resolve) => {
    const timeoutId = setTimeout(() => resolve(null), 5000);
    try {
      chrome.runtime.sendMessage({ type: 'PING_RICHIESTA', requestId }, (r) => {
        clearTimeout(timeoutId);
        if (chrome.runtime.lastError) { resolve(null); return; }
        resolve(r || null);
      });
    } catch (_) { clearTimeout(timeoutId); resolve(null); }
  });
}

function _inviaMessaggioConWatchdog(messaggio, timeoutTotaleMs) {
  const requestId = _nuovoRequestId();
  const messaggioConId = Object.assign({}, messaggio, { requestId });
  let risolta = false, mancatiConsecutivi = 0, heartbeatTimer = null;

  const promiseMessaggio = _inviaMessaggioConRetry(messaggioConId, timeoutTotaleMs)
    .then((r) => ({ orfano: false, risposta: r }))
    .catch((e) => ({ orfano: false, errore: e }))
    .finally(() => { risolta = true; if (heartbeatTimer) clearInterval(heartbeatTimer); });

  const promiseWatchdog = new Promise((resolve) => {
    heartbeatTimer = setInterval(async () => {
      if (risolta) return;
      const esito = await _pingRichiesta(requestId);
      if (risolta) return;
      if (esito && esito.attiva) { mancatiConsecutivi = 0; return; }
      mancatiConsecutivi++;
      if (mancatiConsecutivi >= 3) { if (heartbeatTimer) clearInterval(heartbeatTimer); resolve({ orfano: true }); }
    }, 8000);
  });

  return Promise.race([promiseMessaggio, promiseWatchdog]).then((esito) => {
    if (heartbeatTimer) clearInterval(heartbeatTimer);
    if (esito.orfano) { const err = new Error('service worker riavviato durante l\'attesa — carta saltata'); err.orfano = true; throw err; }
    if (esito.errore) throw esito.errore;
    return esito.risposta;
  });
}

// ── URL CARDMARKET (identico a aggiungi_carta_popup.js) ─────────────────────
function urlRicerca(codice, nome) {
  const q = (codice || nome).trim();
  return `https://www.cardmarket.com/it/Pokemon/Products/Search?searchMode=v2&searchString=${q.replace(/\s+/g, '+')}`;
}

// La wishlist può contenere sia carte singole che prodotti sealed (ETB, UPC,
// box...) — questi ultimi vivono in una sezione diversa di Cardmarket dalle
// carte. Identica a quella già usata da aggiungi_sealed_popup.js.
function urlRicercaSealed(nome, lingua) {
  const query = nome.trim().replace(/\s+/g, '+');
  let url = `https://www.cardmarket.com/it/Pokemon/Products/Search?searchMode=v2&searchString=${query}`;
  const codiceLingua = (lingua || 'IT').toUpperCase().trim();
  const idLingua = LINGUA_MAP_SHARED[codiceLingua];
  if (idLingua) url += `&language=${idLingua}`;
  return url;
}

const _costruisciUrlFiltrato = costruisciUrlFiltrato;

function _appendOloParams(url, reverse, oloType, firstEd) {
  let u = url;
  if (reverse || oloType === 'RH') u = u + (u.includes('?') ? '&' : '?') + 'isReverseHolo=Y';
  if (firstEd) u = u + (u.includes('?') ? '&' : '?') + 'isFirstEd=Y';
  return u;
}

function oloLabel(reverse, oloType) { return (reverse || oloType === 'RH') ? '✨ RH' : ''; }
function firstEdLabel(firstEd) { return firstEd ? '🅰️ 1ED' : ''; }
function condizioneLabel(condizione) {
  const c = (condizione || '').toUpperCase().trim();
  if (c.endsWith('+')) return `⬆️ prezzo condizione superiore (${c})`;
  if (c.endsWith('-')) return `⬇️ prezzo condizione anche inferiore (${c})`;
  return '';
}
function variantiLabel(reverse, oloType, firstEd, condizione) {
  return [oloLabel(reverse, oloType), firstEdLabel(firstEd), condizioneLabel(condizione)].filter(Boolean).join(' · ');
}

// ── PANNELLO CORREZIONE MANUALE ──────────────────────────────────────────────
const LINGUE_CORREZIONE     = ['IT','EN','FR','DE','ES','PT','JA','KOR','CHN','CHN-T','RU','THAI','IND'];
const CONDIZIONI_CORREZIONE = ['MT','NM+','NM','NM-','EX+','EX','EX-','GD+','GD','GD-','LP+','LP','LP-','PL+','PL','PL-','PO+','PO'];

let _codaCorrezione = [];
let _codaCorrezioneTot = 0;

function _mostraProssimaCorrezione() {
  const cardCorrezione = document.getElementById('cardCorrezione');
  const pannello = document.getElementById('pannelloCorrezione');

  if (_codaCorrezione.length === 0) {
    cardCorrezione.style.display = 'none';
    pannello.innerHTML = '';
    pannello.classList.remove('visible');
    _codaCorrezioneTot = 0;
    return;
  }

  cardCorrezione.style.display = 'flex';
  pannello.classList.add('visible');
  pannello.innerHTML = '';

  const { codice, lingua, condizione, qty, oloType, reverse, firstEd, notaBulk, prezzoObiettivo } = _codaCorrezione[0];
  const numeroCorrente = _codaCorrezioneTot - _codaCorrezione.length + 1;
  const oloTag = variantiLabel(reverse, oloType, firstEd, condizione);
  const urlCerca = urlRicerca(codice, '');

  const div = document.createElement('div');
  div.className = 'correzione-item';

  const header = document.createElement('div');
  header.style.cssText = 'display:flex;justify-content:space-between;align-items:baseline;gap:6px;';
  header.innerHTML = `
    <div class="correzione-item-label" style="min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">${codice}${oloTag ? ' · ' + oloTag : ''}</div>
    <div class="correzione-item-sub" style="flex-shrink:0;">${numeroCorrente}/${_codaCorrezioneTot}${prezzoObiettivo != null ? ' · 🎯 ' + prezzoObiettivo + '€' : ''}</div>`;
  div.appendChild(header);

  const editRow = document.createElement('div');
  editRow.style.cssText = 'display:flex;align-items:center;gap:5px;margin-top:1px;';

  function _campoCompatto(testoLabel, valori, valoreDefault) {
    const wrap = document.createElement('div');
    wrap.style.cssText = 'flex:1;display:flex;align-items:center;gap:4px;min-width:0;';
    const lbl = document.createElement('span');
    lbl.style.cssText = 'font-size:9.5px;color:var(--ink-muted);flex-shrink:0;';
    lbl.textContent = testoLabel;
    const sel = document.createElement('select');
    sel.className = 'correzione-url-input';
    sel.style.cssText = 'padding:3px 4px;font-size:10px;flex:1;min-width:0;';
    valori.forEach(v => {
      const opt = document.createElement('option');
      opt.value = v; opt.textContent = v;
      if (v === valoreDefault) opt.selected = true;
      sel.appendChild(opt);
    });
    wrap.appendChild(lbl);
    wrap.appendChild(sel);
    return sel;
  }

  const selectLingua     = _campoCompatto('Lang', LINGUE_CORREZIONE, (lingua || 'IT').toUpperCase());
  const selectCondizione = _campoCompatto('Cond', CONDIZIONI_CORREZIONE, (condizione || 'NM').toUpperCase());
  editRow.appendChild(selectLingua.parentElement);
  editRow.appendChild(selectCondizione.parentElement);

  const linkApri = document.createElement('a');
  linkApri.href = '#';
  linkApri.textContent = '🔗';
  linkApri.title = 'Apri la pagina di ricerca su Cardmarket';
  linkApri.style.cssText = 'flex-shrink:0;font-size:13px;text-decoration:none;cursor:pointer;padding:4px 7px;border-radius:6px;border:1px solid var(--border);background:var(--surface);line-height:1;';
  linkApri.addEventListener('click', (e) => {
    e.preventDefault();
    chrome.runtime.sendMessage({ type: 'APRI_URL_WORKER_TAB', kind: 'carte', url: urlCerca });
  });
  editRow.appendChild(linkApri);
  div.appendChild(editRow);

  const urlNoteRow = document.createElement('div');
  urlNoteRow.style.cssText = 'display:flex;gap:4px;margin-top:2px;';

  const input = document.createElement('input');
  input.type = 'url';
  input.placeholder = "Incolla l'URL /Singles/…";
  input.style.cssText = 'flex:1;min-width:0;font-size:10.5px;padding:5px 7px;';
  urlNoteRow.appendChild(input);
  div.appendChild(urlNoteRow);

  const azioniRow = document.createElement('div');
  azioniRow.className = 'correzione-url-row';
  azioniRow.style.marginTop = '4px';

  const btnAdd = document.createElement('button');
  btnAdd.className = 'correzione-btn';
  btnAdd.style.flex = '1';
  btnAdd.textContent = '➕ Aggiungi';

  const btnSalta = document.createElement('button');
  btnSalta.className = 'correzione-btn-salta';
  btnSalta.title = 'Ignora questa carta';
  btnSalta.textContent = '✕ Ignora';

  btnAdd.addEventListener('click', async () => {
    const urlManuale = input.value.trim();
    if (!urlManuale || !urlManuale.includes('/Singles/')) { input.style.borderColor = 'red'; return; }
    input.style.borderColor = '';
    btnAdd.disabled = true; btnSalta.disabled = true; btnAdd.textContent = '⏳';

    const linguaFinale = selectLingua.value;
    const condizioneFinale = selectCondizione.value;

    try {
      const timeoutMs = await _timeoutLetturaCarta();
      const risposta = await _inviaMessaggioConWatchdog({
        type: 'LEGGI_NOME_CARTA', urlNome: urlManuale.split('?')[0],
        lingua: linguaFinale, condizione: condizioneFinale,
        oloType: oloType || (reverse ? 'RH' : ''), firstEd: !!firstEd, usaWorkerTab: true,
      }, timeoutMs);

      const notaFinale = [notaBulk, variantiLabel(reverse, oloType, firstEd, condizioneFinale)].filter(Boolean).join(' | ');
      const immagineConvertita = await _convertiImmagine(risposta?.immagine);
      const rigaDati = {
        [COL.NOME]:       risposta?.nome || '',
        [COL.CODICE]:     risposta?.codice || codice,
        [COL.LOCATION]:   'WISHLIST',
        [COL.QTY]:        qty,
        [COL.LINGUA]:     linguaFinale,
        [COL.CONDIZIONE]: condizioneFinale,
        [COL.URL]:        _appendOloParams(_costruisciUrlFiltrato(urlManuale.split('?')[0], linguaFinale, condizioneFinale), reverse, oloType, firstEd),
        [COL.PREZZO]:     risposta?.prezzo ?? '',
        [COL.NOTE]:       notaFinale,
        [COL.IMMAGINE]:   immagineConvertita,
      };
      if (prezzoObiettivo != null) rigaDati[COL.PREZZO_OBIETTIVO] = prezzoObiettivo;

      const data = await _chiamaWebApp({ azione: 'aggiungiWishlist', rigaDati });

      if (data.ok) {
        aggiungiLog(`R${data.riga} · ${rigaDati[COL.CODICE]} · ${linguaFinale} · ${condizioneFinale}${oloTag ? ' · ' + oloTag : ''} (manuale)`, 'ok');
        setStatus(`✅ "${rigaDati[COL.CODICE]}" aggiunta alla riga ${data.riga}!`, 'ok');
      } else {
        aggiungiLog(`${codice} — errore: ${data.errore || '?'}`, 'err');
        setStatus(`❌ Errore: ${data.errore || 'risposta sconosciuta'}`, 'errore');
      }
    } catch (e) {
      aggiungiLog(`${codice} — ${e.message}`, 'err');
      setStatus(`❌ Errore: ${e.message}`, 'errore');
    }

    _codaCorrezione.shift();
    _mostraProssimaCorrezione();
  });

  btnSalta.addEventListener('click', () => {
    aggiungiLog(`${codice} — ignorata manualmente`, 'err');
    _codaCorrezione.shift();
    _mostraProssimaCorrezione();
  });

  azioniRow.appendChild(btnAdd);
  azioniRow.appendChild(btnSalta);
  div.appendChild(azioniRow);
  pannello.appendChild(div);
  setTimeout(() => cardCorrezione.scrollIntoView({ behavior: 'smooth', block: 'nearest' }), 100);
}

// ── STATUS / LOG ──────────────────────────────────────────────────────────────
function setStatus(msg, tipo = '') {
  const el = document.getElementById('status');
  el.textContent = msg;
  el.className = msg ? `visible ${tipo}` : '';
}

let logCount = 0;
let logEntries = [];

function aggiungiLog(msg, tipo = 'ok') {
  logCount++;
  logEntries.push({ n: logCount, msg, tipo });
  document.getElementById('logBadge').textContent = logCount;
  const empty = document.querySelector('.log-empty');
  if (empty) empty.remove();
  const entry = document.createElement('div');
  entry.className = 'log-entry';
  const rigaEl = document.createElement('span');
  rigaEl.className = 'log-row';
  rigaEl.textContent = '#' + logCount;
  const msgEl = document.createElement('span');
  msgEl.className = 'log-msg ' + tipo;
  msgEl.textContent = msg;
  entry.appendChild(rigaEl);
  entry.appendChild(msgEl);
  const body = document.getElementById('logBody');
  body.insertBefore(entry, body.firstChild);
  body.classList.add('visible');
  document.getElementById('logHeader').classList.add('open');
}

document.getElementById('logHeader').addEventListener('click', () => {
  document.getElementById('logBody').classList.toggle('visible');
  document.getElementById('logHeader').classList.toggle('open');
});

document.getElementById('logCopy').addEventListener('click', (e) => {
  e.stopPropagation();
  if (logEntries.length === 0) return;
  const testo = [...logEntries].reverse().map(e => `#${e.n}\t${e.msg}`).join('\n');
  navigator.clipboard.writeText(testo).then(() => {
    const btn = document.getElementById('logCopy');
    btn.textContent = '✅';
    setTimeout(() => { btn.textContent = '📋'; }, 1500);
  });
});

document.getElementById('logClear').addEventListener('click', (e) => {
  e.stopPropagation();
  logEntries = []; logCount = 0;
  document.getElementById('logBody').innerHTML = '<div class="log-empty">Nessuna carta aggiunta ancora.</div>';
  document.getElementById('logBadge').textContent = '0';
});

// ── PARSER BULK (identico a aggiungi_carta_popup.js + token @prezzo) ────────
const CONDIZIONI_VALIDE = new Set(['MT','NM','EX','GD','LP','PL','PO']);

function _condizioneToken(tok) {
  const up = (tok || '').toUpperCase();
  if (CONDIZIONI_VALIDE.has(up)) return up;
  const ultimo = up.slice(-1);
  if (ultimo === '+' || ultimo === '-') {
    const base = up.slice(0, -1);
    if (CONDIZIONI_VALIDE.has(base)) return up;
  }
  return null;
}

// FIX-equivalente: token "@PREZZO" per il prezzo obiettivo — nuovo rispetto
// al parser carte, specifico della wishlist. Accetta sia virgola sia punto
// come separatore decimale (@9.50 o @9,50).
function _prezzoObiettivoToken(tok) {
  const m = /^@(\d+(?:[.,]\d+)?)$/.exec((tok || '').trim());
  if (!m) return null;
  const v = parseFloat(m[1].replace(',', '.'));
  return isNaN(v) ? null : v;
}

const LINGUA_ALIAS_MAP = {
  'IT':'IT','ITA':'IT','ITALIANO':'IT','ITALIAN':'IT',
  'EN':'EN','ENG':'EN','INGLESE':'EN','ENGLISH':'EN',
  'FR':'FR','FRA':'FR','FRANCESE':'FR','FRENCH':'FR',
  'DE':'DE','DEU':'DE','GER':'DE','TEDESCO':'DE','GERMAN':'DE','DEUTSCH':'DE',
  'ES':'ES','ESP':'ES','SPAGNOLO':'ES','SPANISH':'ES','ESPAÑOL':'ES',
  'PT':'PT','POR':'PT','PORTOGHESE':'PT','PORTUGUESE':'PT',
  'JA':'JA','JP':'JA','JAP':'JA','JPN':'JA','GIAPPONESE':'JA','JAPANESE':'JA',
  'KOR':'KOR','KO':'KOR','KR':'KOR','COREANO':'KOR','KOREAN':'KOR',
  'CHN':'CHN','ZH':'CHN','CN':'CHN','CHS':'CHN','CINESE':'CHN','CHINESE':'CHN','CINESE-S':'CHN','CHINESE-S':'CHN',
  'CHN-T':'CHN-T','ZHT':'CHN-T','TW':'CHN-T','CHT':'CHN-T','CINESE-T':'CHN-T','CHINESE-T':'CHN-T',
  'RU':'RU','RUS':'RU','RUSSO':'RU','RUSSIAN':'RU',
  'THAI':'THAI','TH':'THAI','TAILANDESE':'THAI',
  'IND':'IND','ID':'IND','INDONESIANO':'IND','INDONESIAN':'IND',
};

const REVERSE_TOKEN = new Set(['RH','REV','REVERSE','REVERSEHOLO','REVERSE-HOLO']);
const FIRST_ED_TOKEN = new Set(['1ED','1STED','1ST-ED','FIRSTED','FIRST-ED','PRIMAED','PRIMA-ED']);

function parsaBulkRiga(riga) {
  const rigaTrim = riga.trim();
  if (!rigaTrim) return null;

  const virgolaIdx = rigaTrim.indexOf(',');
  if (virgolaIdx !== -1) {
    const nomeParte = rigaTrim.slice(0, virgolaIdx).trim();
    const modificatoriParte = rigaTrim.slice(virgolaIdx + 1).trim();
    if (!nomeParte) return null;

    let lingua = 'IT', condizione = 'NM', reverse = false, firstEd = false, prezzoObiettivo = null;
    const notaTokens = [];
    const tokensModificatori = modificatoriParte.split(/[\s,]+/).filter(Boolean);
    for (const t of tokensModificatori) {
      const up = t.toUpperCase();
      if (REVERSE_TOKEN.has(up)) { reverse = true; continue; }
      if (FIRST_ED_TOKEN.has(up)) { firstEd = true; continue; }
      const _condTokV = _condizioneToken(up);
      if (_condTokV) { condizione = _condTokV; continue; }
      const lc = LINGUA_ALIAS_MAP[up];
      if (lc) { lingua = lc; continue; }
      const _prezzoTok = _prezzoObiettivoToken(t);
      if (_prezzoTok !== null) { prezzoObiettivo = _prezzoTok; continue; }
      notaTokens.push(t);
    }
    const notaBulk = notaTokens.join(' ');
    return { codice: nomeParte, lingua, condizione, qty: 1, reverse, oloType: '', firstEd, notaBulk, prezzoObiettivo };
  }

  const tokens = rigaTrim.split(/\s+/);
  const tokensCodice = [];
  let lingua = 'IT', condizione = 'NM', reverse = false, firstEd = false, prezzoObiettivo = null;

  for (const t of tokens) {
    const up = t.toUpperCase();
    if (REVERSE_TOKEN.has(up)) { reverse = true; continue; }
    if (FIRST_ED_TOKEN.has(up)) { firstEd = true; continue; }
    const _condTok = _condizioneToken(up);
    if (_condTok) { condizione = _condTok; continue; }
    const lc = LINGUA_ALIAS_MAP[up];
    if (lc) { lingua = lc; continue; }
    const _prezzoTok = _prezzoObiettivoToken(t);
    if (_prezzoTok !== null) { prezzoObiettivo = _prezzoTok; continue; }
    tokensCodice.push(t);
  }

  const codice = tokensCodice.join(' ').trim();
  if (!codice) return null;
  return { codice, lingua, condizione, qty: 1, reverse, oloType: '', firstEd, notaBulk: '', prezzoObiettivo };
}

// ── BACKOFF ADATTIVO CLOUDFLARE (riusa il kind 'carte', stesso della pagina
// "Aggiungi carte" — così condivide la stessa worker tab senza bisogno di
// modifiche a background.js, che serializza già per kind) ──────────────────
let _cfEscalationLevel = 0;
let _cfHitPendente = false;

chrome.runtime.onMessage.addListener((message) => {
  if (message && message.type === 'CLOUDFLARE_HIT_BULK' && message.kind === 'carte') {
    _cfHitPendente = true;
  }
});

// ── AGGIUNGI BULK ─────────────────────────────────────────────────────────────
let _bulkAttivo = false;

async function avviaSessioneBulk(riprendi = 0, carteOverride = null) {
  // carteOverride: quando presente (righe pescate da 'coda_wishlist', vedi
  // _recuperaAltreRigheDaDbWishlist più sotto), salta la lettura/parsing del
  // textarea e usa direttamente questo elenco già strutturato — ogni voce
  // porta con sé un dbRigaId per scrivere l'esito sulla riga giusta della
  // coda persistente a fine elaborazione.
  const listaRaw = carteOverride ? '' : document.getElementById('bulkInput').value;
  const righeRaw = carteOverride ? [] : listaRaw.split('\n').map(r => r.trim()).filter(Boolean);
  if (!carteOverride && righeRaw.length === 0) { setStatus('⚠️ Nessuna carta nella lista.', 'errore'); return; }

  const carte = carteOverride || righeRaw.map(r => parsaBulkRiga(r)).filter(Boolean);
  if (carte.length === 0) { setStatus('⚠️ Nessuna riga valida trovata.', 'errore'); return; }

  _dbRigaIdsAncoraInCarico = new Set(carte.map((c) => c.dbRigaId).filter(Boolean));

  // FIX (sessione si blocca se la tab va in background per ore, es. lasciata
  // aperta la notte): vedi commento esteso su avviaAudioKeepAlive() in
  // shared.js. Fermato più sotto, dove la sessione termina (_bulkAttivo = false).
  avviaAudioKeepAlive();

  const btnBulk = document.getElementById('btnBulkAggiungi');
  const btnReset = document.getElementById('btnReset');
  _bulkAttivo = true;
  _cfEscalationLevel = 0;
  _cfHitPendente = false;
  btnBulk.disabled = false;
  btnBulk.textContent = '🛑 Ferma';
  btnReset.disabled = true;

  let bulkStopRequested = false;
  const stopHandler = () => { bulkStopRequested = true; btnBulk.disabled = true; btnBulk.textContent = '⏱️ Arresto…'; setStatus('⏳ Finisco la carta attuale e mi fermo…', 'info'); };
  btnBulk.addEventListener('click', stopHandler, { once: true });

  const timeoutLettura = await _timeoutLetturaCarta();
  const pianoDiInserimento = carte.map(carta => ({ carta }));
  const pianoEffettivo = riprendi > 0 ? pianoDiInserimento.slice(riprendi) : pianoDiInserimento;
  const offsetLog = riprendi;

  const progressEl = document.getElementById('bulkProgress');
  const bpCarta = document.getElementById('bpCarta');
  const bpFill  = document.getElementById('bpFill');
  const bpCount = document.getElementById('bpCount');
  const bpStima = document.getElementById('bpStima');
  const bpTimer = document.getElementById('bpTimer');
  progressEl.classList.add('visible');

  const _bpStart = Date.now();
  function _aggiornaBp(idx, totale, codice) {
    const pct = totale > 0 ? Math.round((idx / totale) * 100) : 0;
    if (bpFill) bpFill.style.width = pct + '%';
    if (bpCount) bpCount.textContent = `${idx + 1} / ${totale}`;
    if (bpCarta) bpCarta.textContent = `⏳ ${codice}`;
    const elapsed = (Date.now() - _bpStart) / 1000;
    const perCarta = idx > 0 ? elapsed / idx : null;
    const rimanenti = totale - idx - 1;
    if (perCarta && rimanenti > 0) {
      const secRimanenti = Math.round(perCarta * rimanenti);
      const fineStimata = new Date(Date.now() + secRimanenti * 1000);
      const hh = String(fineStimata.getHours()).padStart(2, '0');
      const mm = String(fineStimata.getMinutes()).padStart(2, '0');
      if (bpStima) bpStima.textContent = `fine stimata ~${hh}:${mm}`;
    } else if (bpStima) bpStima.textContent = 'fine stimata —';
    if (bpTimer) bpTimer.textContent = '—';
  }

  async function _attendiConCountdown(ms, etichetta) {
    const fineAttesa = Date.now() + ms;
    while (Date.now() < fineAttesa) {
      if (bulkStopRequested) return;
      const restante = Math.max(0, fineAttesa - Date.now());
      const totSec = Math.ceil(restante / 1000);
      const m = Math.floor(totSec / 60), s = totSec % 60;
      const testo = `${m > 0 ? m + 'm ' : ''}${s}s`;
      if (bpTimer) bpTimer.textContent = etichetta ? `${etichetta} ${testo}` : testo;
      await new Promise(r => setTimeout(r, 1000));
    }
    if (bpTimer && !bulkStopRequested) bpTimer.textContent = '—';
  }

  let ok = 0, err = 0;
  const _rateLimitRetries = {};
  const daCorreggere = [];

  async function _attendiDelay(i) {
    if (i >= pianoEffettivo.length - 1 || bulkStopRequested) return;
    const savedPausa = await new Promise(r => chrome.storage.local.get(
      ['sliderDelay', 'sliderDelayMinSec', 'sliderDelayMaxSec', 'sliderPausaOgni'], r));
    const pausaOgniN = PAUSA_OGNI_VALUES[savedPausa.sliderPausaOgni ?? 1] ?? 50;

    if (_cfHitPendente) {
      _cfEscalationLevel = Math.min(_cfEscalationLevel + 1, CF_ESCALATION_MAX_LEVEL);
      _cfHitPendente = false;
      aggiungiLog('⚠️ Cloudflare rilevato — rallento temporaneamente il ritmo tra le carte', '');
    } else if (_cfEscalationLevel > 0) {
      _cfEscalationLevel--;
    }

    if ((offsetLog + i + 1) % pausaOgniN === 0) {
      _aggiornaBp(offsetLog + i, pianoDiInserimento.length, 'Pausa anti-quota…');
      await _attendiConCountdown(30000, 'Pausa anti-quota —');
    } else {
      let dMinSec = savedPausa.sliderDelayMinSec;
      let dMaxSec = savedPausa.sliderDelayMaxSec;
      if (dMinSec === undefined || dMaxSec === undefined) {
        if (typeof savedPausa.sliderDelay === 'number' && LEGACY_DELAY_RANGES_SEC[savedPausa.sliderDelay]) {
          [dMinSec, dMaxSec] = LEGACY_DELAY_RANGES_SEC[savedPausa.sliderDelay];
        } else {
          dMinSec = DEFAULT_DELAY_MIN_SEC;
          dMaxSec = DEFAULT_DELAY_MAX_SEC;
        }
      }
      const dMin = dMinSec * 1000;
      const dMax = Math.max(dMaxSec, dMinSec) * 1000;
      const MARGINE_RIUSO_TAB_MS = 1200;
      const margineCfMs = _cfEscalationLevel * CF_ESCALATION_STEP_SEC * 1000;
      const delayMs = dMin + Math.floor(Math.random() * (dMax - dMin)) + MARGINE_RIUSO_TAB_MS + margineCfMs;
      await _attendiConCountdown(delayMs, _cfEscalationLevel > 0 ? 'Prossima tra (rallentato)' : 'Prossima tra');
    }
  }

  for (let i = 0; i < pianoEffettivo.length; i++) {
    if (bulkStopRequested) break;
    const { carta } = pianoEffettivo[i];
    const { codice, lingua, condizione, qty, oloType, reverse, firstEd, notaBulk, prezzoObiettivo, dbRigaId, location, tipo: tipoProdotto } = carta;
    const isSealed = tipoProdotto === 'sealed';

    // Come per coda_carte: non salvare la ripresa locale per righe che
    // vengono dal database — hanno già la propria persistenza (stato/
    // claimed_at su coda_wishlist + rilascio immediato alla chiusura),
    // salvarle ANCHE qui causerebbe una doppia ripresa (locale + database)
    // alla riapertura, con conseguente doppia elaborazione della stessa carta.
    if (!carteOverride) {
      chrome.storage.local.set({ wishlistSessione: { listaRaw, indiceFermo: offsetLog + i, totale: pianoDiInserimento.length } });
    }
    _aggiornaBp(offsetLog + i, pianoDiInserimento.length, codice);
    setStatus(`⏳ Processo ${offsetLog + i + 1}/${pianoDiInserimento.length}: ${codice}…`, 'info');

    try {
      let risposta;
      if (isSealed) {
        risposta = await _inviaMessaggioConWatchdog({
          type: 'LEGGI_SEALED', urlNome: urlRicercaSealed(codice, lingua), lingua, usaWorkerTab: true,
        }, timeoutLettura);
      } else {
        const urlRic = urlRicerca(codice, '');
        risposta = await _inviaMessaggioConWatchdog({
          type: 'LEGGI_NOME_CARTA', urlNome: urlRic, lingua, condizione,
          oloType: oloType || (reverse ? 'RH' : ''), firstEd: !!firstEd, usaWorkerTab: true,
        }, timeoutLettura);
      }

      if (risposta?.rateLimited) {
        _rateLimitRetries[i] = (_rateLimitRetries[i] || 0) + 1;
        aggiungiLog(`${codice} — Error 1015 (rate limited) → pausa 30 min`, 'err');
        setStatus('🚫 Error 1015: troppe richieste. Pausa di 30 minuti…', 'errore');
        progressEl.classList.add('visible');
        if (bpFill) bpFill.style.width = '100%';
        if (bpCarta) bpCarta.textContent = '☕ Error 1015 — in pausa';
        if (bpStima) bpStima.textContent = 'pausa rate-limit';
        if (bpCount) bpCount.textContent = `${offsetLog + i + 1} / ${pianoDiInserimento.length}`;
        await _attendiConCountdown(PAUSA_RATE_LIMIT_MS, 'Riprende tra');
        if (bulkStopRequested) break;
        if (_rateLimitRetries[i] >= 3) {
          aggiungiLog(`${codice} — saltata dopo 3 rate limit consecutivi`, 'err');
          if (dbRigaId) { await _segnaEsitoCodaWishlist(dbRigaId, 'errore', 'Troppi rate-limit (Error 1015) consecutivi su Cardmarket.'); }
          else { daCorreggere.push({ codice, lingua, condizione, qty, oloType, reverse, firstEd, notaBulk, prezzoObiettivo, tipo: 'fallita' }); }
          err++;
          await _attendiDelay(i);
          continue;
        }
        i--;
        continue;
      }

      const urlTrovato = isSealed ? risposta?.urlProdotto : risposta?.urlSingles;
      if (!urlTrovato) {
        let motivoLog;
        if (isSealed) {
          motivoLog = risposta?.disambiguation ? 'disambiguazione — correzione manuale'
            : (risposta === null || risposta === undefined ? 'errore di rete / timeout' : 'non trovato su Cardmarket');
        } else {
          if (risposta?.varianteNonTrovata) motivoLog = `variante ${oloLabel(reverse, oloType)} non trovata`;
          else if (risposta?.disambiguation) motivoLog = 'disambiguazione — correzione manuale';
          else if (risposta === null || risposta === undefined) motivoLog = 'errore di rete / timeout';
          else motivoLog = 'non trovata su Cardmarket';
        }
        aggiungiLog(`${codice} — ${motivoLog}`, 'err');
        const _tipoCoda = risposta?.disambiguation ? 'disambiguation' : 'fallita';
        if (dbRigaId) { await _segnaEsitoCodaWishlist(dbRigaId, 'errore', motivoLog); }
        else { daCorreggere.push({ codice, lingua, condizione, qty, oloType, reverse, firstEd, notaBulk, prezzoObiettivo, tipo: _tipoCoda }); }
        err++;
        await _attendiDelay(i);
        continue;
      }

      const codiceFinale = isSealed ? codice : (risposta.codice || codice);
      const immagineConvertita2 = await _convertiImmagine(risposta.immagine);
      const rigaDati = isSealed ? {
        [COL.NOME]:       risposta.nome || codice,
        [COL.CODICE]:     '',
        [COL.LOCATION]:   location || 'WISHLIST',
        [COL.QTY]:        qty,
        [COL.LINGUA]:     lingua,
        [COL.CONDIZIONE]: 'NM', // irrilevante per i sealed
        [COL.URL]:        risposta.urlProdotto,
        [COL.PREZZO]:     risposta.prezzo ?? '',
        [COL.NOTE]:       notaBulk || '',
        [COL.IMMAGINE]:   immagineConvertita2,
      } : {
        [COL.NOME]:       risposta.nome || '',
        [COL.CODICE]:     codiceFinale,
        [COL.LOCATION]:   location || 'WISHLIST',
        [COL.QTY]:        qty,
        [COL.LINGUA]:     lingua,
        [COL.CONDIZIONE]: condizione,
        [COL.URL]:        (() => { let u = _costruisciUrlFiltrato(risposta.urlSingles, lingua, condizione); return _appendOloParams(u, reverse, oloType, firstEd); })(),
        [COL.PREZZO]:     risposta.prezzo ?? '',
        [COL.NOTE]:       [notaBulk, variantiLabel(reverse, oloType, firstEd, condizione)].filter(Boolean).join(' | '),
        [COL.IMMAGINE]:   immagineConvertita2,
      };
      if (prezzoObiettivo != null) rigaDati[COL.PREZZO_OBIETTIVO] = prezzoObiettivo;

      const data = await _chiamaWebApp({ azione: 'aggiungiWishlist', rigaDati, tipo: tipoProdotto || undefined });

      const oloLog = variantiLabel(reverse, oloType, firstEd, condizione);
      if (!data.ok) {
        aggiungiLog(`${codiceFinale} — errore: ${data.errore || '?'}`, 'err');
        err++;
        if (dbRigaId) await _segnaEsitoCodaWishlist(dbRigaId, 'errore', data.errore || 'Scrittura in wishlist fallita.');
      } else {
        aggiungiLog(`R${data.riga} · ${codiceFinale} · ${lingua} · ${condizione}${oloLog ? ' · ' + oloLog : ''}${prezzoObiettivo != null ? ' · 🎯 ' + prezzoObiettivo + '€' : ''}`, 'ok');
        ok++;
        if (dbRigaId) await _segnaEsitoCodaWishlist(dbRigaId, 'ok');
        // FIX: prima l'elenco "Wishlist attuale" si aggiornava solo a fine
        // dell'INTERO lotto (anche con decine di carte, con secondi di
        // pausa tra una e l'altra) — ora si vede comparire ogni carta subito
        // dopo che è stata trovata, non alla fine di tutto.
        await _caricaWishlist();
      }
    } catch (e) {
      aggiungiLog(`${codice} — ${e.message}`, 'err'); err++;
      if (dbRigaId) { await _segnaEsitoCodaWishlist(dbRigaId, 'errore', e.message); }
      else { daCorreggere.push({ codice, lingua, condizione, qty, oloType, reverse, firstEd, notaBulk, prezzoObiettivo, tipo: 'fallita' }); }
    }

    await _attendiDelay(i);
  }

  progressEl.classList.remove('visible');
  if (bpFill) bpFill.style.width = '0%';
  if (bpCount) bpCount.textContent = '0 / 0';
  if (bpCarta) bpCarta.textContent = '—';
  if (bpStima) bpStima.textContent = 'stima —';
  if (bpTimer) bpTimer.textContent = '—';
  chrome.runtime.sendMessage({ type: 'CHIUDI_WORKER_TAB', kind: 'carte' });
  // FIX (sessione si blocca se la tab va in background per ore): ferma
  // l'audio silenzioso avviato da avviaAudioKeepAlive() più sopra.
  fermaAudioKeepAlive();
  btnBulk.removeEventListener('click', stopHandler);
  _bulkAttivo = false;
  btnBulk.disabled = false;
  btnBulk.textContent = '🗂️ Aggiungi alla wishlist';
  btnReset.disabled = false;

  if (bulkStopRequested) {
    setStatus(`🛑 Interrotto. ${ok} aggiunt${ok === 1 ? 'a' : 'e'}${err > 0 ? `, ${err} errori` : ''}. Riapri per riprendere dalla carta ${offsetLog + ok + err + 1}.`, 'info');
  }

  if (daCorreggere.length > 0) {
    daCorreggere.forEach((c) => { _codaCorrezione.push(c); _codaCorrezioneTot++; });
    _mostraProssimaCorrezione();
  }

  if (!bulkStopRequested) {
    setStatus(`✅ ${ok} aggiunt${ok === 1 ? 'a' : 'e'}${err > 0 ? ` · ❌ ${err} errori` : ''}.`, err === 0 ? 'ok' : (ok === 0 ? 'errore' : 'info'));
    chrome.storage.local.remove('wishlistSessione');
  }
  if (ok > 0 && !bulkStopRequested) {
    const ora = Date.now();
    document.getElementById('ultimaCarta').textContent = `✔ ${formattaDataOra(ora)} · ${ok} cart${ok === 1 ? 'a aggiunta' : 'e aggiunte'}`;
    document.getElementById('bulkInput').value = '';
  }

  // Aggiorna da sola l'elenco "Wishlist attuale" mostrato in pagina — prima
  // bisognava premere "↺ Carica" a mano per vedere le carte appena aggiunte.
  if (ok > 0) await _caricaWishlist();

  // FIX (coda unica): questa pagina non "prende in carico" più nulla da
  // sola — quel lavoro ora lo fa SOLO aggiungi_carta_popup.js, che legge
  // un'UNICA coda condivisa (coda_carte, con destinazione='wishlist' o
  // 'collezione') invece di due code indipendenti che potevano partire in
  // parallelo confondendosi a vicenda con più dispositivi online insieme.
  // Vedi coda_unificata.sql e _recuperaAltreRigheDaDb in
  // aggiungi_carta_popup.js.
}

// Scrive l'esito (trovata/errore) sulla riga di 'coda_wishlist' e la toglie
// dal Set di quelle "ancora in carico" (vedi _rilasciaClaimWishlistAllaChiusura).
async function _segnaEsitoCodaWishlist(dbRigaId, esito, msg) {
  if (!dbRigaId) return;
  _dbRigaIdsAncoraInCarico.delete(dbRigaId);
  try {
    const aggiornamento = esito === 'ok'
      ? { stato: 'completato', completato_il: new Date().toISOString() }
      : { stato: 'errore', completato_il: new Date().toISOString(), errore_msg: msg || 'Errore sconosciuto.' };
    await supabaseClient.from('coda_wishlist').update(aggiornamento).eq('id', dbRigaId);
  } catch (e) {
    console.error('[coda_wishlist] impossibile scrivere l\'esito:', e);
  }
}

function formattaDataOra(ts) {
  if (!ts) return null;
  const d = new Date(ts);
  const pad = n => String(n).padStart(2, '0');
  return `${pad(d.getDate())}/${pad(d.getMonth()+1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

// ── VERIFICA LOGIN CARDMARKET ────────────────────────────────────────────────
async function _richiediConfermaLogin(onConferma, onNonLoggato) {
  setStatus('🔍 Verifico il login su Cardmarket...', 'info');
  let risposta;
  try {
    risposta = await new Promise((resolve, reject) => {
      // FIX (troppe tab in sequenza → Cloudflare): kind:'carte' — stesso
      // kind già usato dalla worker tab di questa pagina (vedi
      // LEGGI_NOME_CARTA/LEGGI_SOLO_PREZZO/CHIUDI_WORKER_TAB più sotto) — fa
      // sì che background.js esegua il controllo login nella STESSA worker
      // tab invece di aprirne una a parte. Vale sia per l'avvio della
      // sessione bulk sia per "🔄 Aggiorna prezzi", che chiama questa stessa
      // funzione.
      chrome.runtime.sendMessage({ type: 'VERIFICA_LOGIN_SILENZIOSA', kind: 'carte' }, (r) => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message)); else resolve(r);
      });
    });
  } catch (e) {
    setStatus('⚠️ Impossibile verificare il login (' + e.message + ') — procedo comunque.', 'info');
    onConferma();
    return;
  }
  if (risposta && risposta.loggato === false) {
    setStatus('🔒 Non risulti loggato su Cardmarket — ho aperto una tab per te: accedi e riprova.', 'errore');
    if (onNonLoggato) onNonLoggato();
    return;
  }
  if (!risposta || risposta.loggato === null) setStatus('⚠️ Non sono riuscito a confermare il login — procedo comunque.', 'info');
  onConferma();
}

document.getElementById('btnBulkAggiungi').addEventListener('click', () => {
  if (_bulkAttivo) return;
  _richiediConfermaLogin(() => avviaSessioneBulk(0));
});

// ── ORDINI DAL SITO — coda persistente "coda_wishlist" (Supabase) ───────────
// Stesso schema già usato per 'coda_carte' in aggiungi_carta_popup.js: il
// sito scrive una riga per carta desiderata in 'coda_wishlist', questa
// pagina le pesca a lotti, claim-based (lock ottimistico: la condizione di
// eleggibilità va ripetuta identica nell'update, altrimenti due PC potrebbero
// prendersi in carico la stessa riga quasi in contemporanea), e le versa nel
// motore avviaSessioneBulk tramite il parametro carteOverride. L'esito
// (trovata/errore) viene scritto sulla riga con dbRigaId, e — a differenza di
// aggiungi_carte — le righe "da correggere manualmente" (non trovate,
// disambiguazione) qui vengono segnate 'errore' subito invece di entrare
// nella coda di correzione interattiva: nessuno è lì a risolverle a mano
// quando la pagina è aperta in automatico dal sito.
const _LOTTO_RECUPERO_WISHLIST = 5;
let _recuperoWishlistDaDbInCorso = false;

async function _recuperaAltreRigheDaDbWishlist() {
  if (_recuperoWishlistDaDbInCorso || _bulkAttivo) return;
  _recuperoWishlistDaDbInCorso = true;
  try {
    const { data: sessionData } = await supabaseClient.auth.getSession();
    const userId = sessionData?.session?.user?.id;
    if (!userId) return;

    const sogliaStalloIso = new Date(Date.now() - 10 * 60 * 1000).toISOString();
    const filtroEleggibili = `stato.eq.pending,and(stato.eq.in_corso,claimed_at.lt.${sogliaStalloIso})`;
    const { data: candidate, error: errLettura } = await supabaseClient
      .from('coda_wishlist')
      .select('*')
      .or(filtroEleggibili)
      .order('creato_il', { ascending: true })
      .limit(_LOTTO_RECUPERO_WISHLIST);
    if (errLettura) { console.error('[coda_wishlist] errore lettura:', errLettura.message); return; }
    if (!candidate || candidate.length === 0) return;

    const ids = candidate.map((r) => r.id);
    const { data: claimate, error: errClaim } = await supabaseClient
      .from('coda_wishlist')
      .update({ stato: 'in_corso', claimed_by: userId, claimed_at: new Date().toISOString() })
      .in('id', ids)
      .or(filtroEleggibili)
      .select();
    if (errClaim) { console.error('[coda_wishlist] errore claim:', errClaim.message); return; }
    if (!claimate || claimate.length === 0) return; // già prese da un altro dispositivo

    const carteDaProcessare = claimate.map((r) => ({
      codice: r.nome,
      lingua: r.lingua || 'IT',
      condizione: r.condizione || 'NM',
      qty: r.qty || 1,
      reverse: !!r.reverse,
      oloType: r.reverse ? 'RH' : '',
      firstEd: !!r.first_ed,
      notaBulk: r.nota || '',
      prezzoObiettivo: r.prezzo_obiettivo ?? null,
      location: r.location || 'WISHLIST',
      tipo: r.tipo || null, // 'sealed' se un ETB/UPC/box, altrimenti carta singola
      dbRigaId: r.id,
    }));

    _richiediConfermaLogin(
      () => avviaSessioneBulk(0, carteDaProcessare),
      () => {
        // FIX: prima, se il login su Cardmarket falliva qui, le righe
        // restavano 'in_corso' (già claimate poco sopra) MA MAI elaborate —
        // sparivano sia dalla wishlist (mai scritte, la ricerca non è
        // partita) sia da un nuovo tentativo di recupero (non ancora
        // "scadute": la soglia di sicurezza è 10 minuti). Le rimettiamo
        // 'pending' subito, così il prossimo giro (o riaprendo dopo aver
        // fatto login) le ritrova immediatamente.
        const idsDaRilasciare = carteDaProcessare.map((c) => c.dbRigaId).filter(Boolean);
        if (idsDaRilasciare.length > 0) {
          supabaseClient.from('coda_wishlist')
            .update({ stato: 'pending', claimed_by: null, claimed_at: null })
            .in('id', idsDaRilasciare)
            .then(({ error }) => { if (error) console.error('[coda_wishlist] impossibile rilasciare dopo login fallito:', error.message); });
        }
      }
    );
  } finally {
    _recuperoWishlistDaDbInCorso = false;
  }
}

// Controllo periodico: ogni ~20s ricarica la vista "Wishlist attuale" (sola
// lettura, MAI un claim) — così si vedono anche le carte scritte da
// aggiungi_carta_popup.js (che ora è l'unico a elaborare la coda unica)
// senza dover ricaricare manualmente questa pagina.
setInterval(() => { _caricaWishlist(); }, 20000);

// ── RILASCIO IMMEDIATO ALLA CHIUSURA ─────────────────────────────────────────
// Stesso meccanismo di aggiungi_carta_popup.js: le righe che questo PC aveva
// ancora in carico tornano SUBITO disponibili per un altro PC, invece di
// aspettare i 10 minuti di sicurezza.
let _accessTokenCorrenteWishlist = null;
supabaseClient.auth.onAuthStateChange((_event, session) => {
  _accessTokenCorrenteWishlist = session?.access_token || null;
});
supabaseClient.auth.getSession().then(({ data }) => {
  _accessTokenCorrenteWishlist = data?.session?.access_token || null;
});

function _rilasciaClaimWishlistAllaChiusura() {
  const ids = [..._dbRigaIdsAncoraInCarico];
  if (ids.length === 0 || !_accessTokenCorrenteWishlist) return;
  const filtroIds = ids.map((id) => `"${id}"`).join(',');
  fetch(`${SUPABASE_URL}/rest/v1/coda_wishlist?id=in.(${filtroIds})`, {
    method: 'PATCH',
    keepalive: true,
    headers: {
      apikey: SUPABASE_ANON_KEY,
      Authorization: 'Bearer ' + _accessTokenCorrenteWishlist,
      'Content-Type': 'application/json',
      Prefer: 'return=minimal',
    },
    body: JSON.stringify({ stato: 'pending', claimed_by: null, claimed_at: null }),
  }).catch(() => {});
}
window.addEventListener('beforeunload', _rilasciaClaimWishlistAllaChiusura);
window.addEventListener('pagehide', _rilasciaClaimWishlistAllaChiusura);

// Insieme delle dbRigaId ancora "in carico" da QUESTA pagina in questo
// momento — si aggiorna in tempo reale dentro avviaSessioneBulk (una riga
// esce da qui appena il suo esito è scritto su coda_wishlist), così il
// rilascio alla chiusura sopra non rimette per sbaglio in 'pending' righe
// già completate con successo un istante prima.
let _dbRigaIdsAncoraInCarico = new Set();

// ── WISHLIST ATTUALE: carica / comprata / rimuovi / aggiorna prezzi ──────────
let _wishlistRighe = []; // cache dell'ultimo caricamento, usata da comprata/rimuovi/refresh

function _renderWishlist() {
  const wrap = document.getElementById('wishList');
  wrap.innerHTML = '';
  if (_wishlistRighe.length === 0) {
    wrap.innerHTML = '<div class="wish-empty">Nessuna carta in wishlist (o non ancora caricata).</div>';
    return;
  }
  _wishlistRighe.forEach((r) => {
    const hit = r.prezzoObiettivo != null && r.prezzo != null && Number(r.prezzo) <= Number(r.prezzoObiettivo);
    const div = document.createElement('div');
    div.className = 'wish-item' + (hit ? ' wish-hit' : '');

    const top = document.createElement('div');
    top.className = 'wish-item-top';
    const nomeEl = document.createElement('div');
    nomeEl.className = 'wish-item-nome';
    nomeEl.textContent = r.nome || r.codice || ('Riga ' + r.riga);
    nomeEl.title = nomeEl.textContent;
    const subEl = document.createElement('div');
    subEl.className = 'wish-item-sub';
    subEl.textContent = [r.codice, r.lingua, r.condizione].filter(Boolean).join(' · ');
    top.appendChild(nomeEl);
    top.appendChild(subEl);
    div.appendChild(top);

    const prezzi = document.createElement('div');
    prezzi.className = 'wish-item-prezzi';
    const prezzoEl = document.createElement('span');
    prezzoEl.className = 'wish-item-prezzo';
    prezzoEl.innerHTML = 'Attuale: <strong>' + (r.prezzo != null && r.prezzo !== '' ? r.prezzo + '€' : '—') + '</strong>';
    prezzi.appendChild(prezzoEl);
    if (r.prezzoObiettivo != null && r.prezzoObiettivo !== '') {
      const obEl = document.createElement('span');
      obEl.className = 'wish-item-obiettivo' + (hit ? ' hit' : '');
      obEl.textContent = (hit ? '🎯 ' : 'Obiettivo: ') + r.prezzoObiettivo + '€' + (hit ? ' — conviene!' : '');
      prezzi.appendChild(obEl);
    }
    div.appendChild(prezzi);

    const azioni = document.createElement('div');
    azioni.className = 'wish-item-actions';

    const btnComprata = document.createElement('button');
    btnComprata.className = 'wish-btn comprata';
    btnComprata.textContent = '✓ Comprata';
    btnComprata.addEventListener('click', () => _segnaComprata(r, btnComprata, btnRimuovi));

    const btnRimuovi = document.createElement('button');
    btnRimuovi.className = 'wish-btn rimuovi';
    btnRimuovi.textContent = '🗑️ Rimuovi';
    btnRimuovi.addEventListener('click', () => _rimuoviDaWishlist(r, btnComprata, btnRimuovi));

    azioni.appendChild(btnComprata);
    azioni.appendChild(btnRimuovi);
    div.appendChild(azioni);

    wrap.appendChild(div);
  });
}

async function _caricaWishlist() {
  const btn = document.getElementById('btnAggiornaWishlist');
  btn.disabled = true; btn.textContent = '⏳';
  try {
    const data = await _chiamaWebApp({ azione: 'leggiWishlist' });
    if (!data.ok) { setStatus('❌ ' + (data.errore || 'Errore nel caricamento wishlist.'), 'errore'); return; }
    _wishlistRighe = data.righe || [];
    _renderWishlist();
    setStatus(`📋 Wishlist caricata: ${_wishlistRighe.length} cart${_wishlistRighe.length === 1 ? 'a' : 'e'}.`, 'ok');
  } catch (e) {
    setStatus('❌ ' + e.message, 'errore');
  }
  btn.disabled = false; btn.textContent = '↺ Carica';
}

document.getElementById('btnAggiornaWishlist').addEventListener('click', _caricaWishlist);

async function _segnaComprata(r, btnComprata, btnRimuovi) {
  const conferma = confirm(`Segnare "${r.nome || r.codice}" come comprata? Verrà spostata dalla wishlist alla collezione.`);
  if (!conferma) return;
  btnComprata.disabled = true; btnRimuovi.disabled = true; btnComprata.textContent = '⏳';
  try {
    await _registraLocationSeNuova();
    const dataAgg = await _chiamaWebApp({
      azione: 'spostaWishlistInCollezione',
      wishlistRigaId: r.riga,
      nome: r.nome || '',
      codice: r.codice || '',
      location: _leggiLocationCorrente(),
      qty: r.qty || 1,
      lingua: r.lingua || 'IT',
      condizione: r.condizione || 'NM',
      url: r.url || '',
      note: r.note || '',
      prezzo: r.prezzo != null ? r.prezzo : '',
    });
    if (!dataAgg.ok) { setStatus('❌ Spostamento in collezione fallito: ' + (dataAgg.errore || '?'), 'errore'); btnComprata.disabled = false; btnRimuovi.disabled = false; btnComprata.textContent = '✓ Comprata'; return; }

    _wishlistRighe = _wishlistRighe.filter(x => x.riga !== r.riga);
    _renderWishlist();
    setStatus(`✅ "${r.nome || r.codice}" spostata in collezione.`, 'ok');
  } catch (e) {
    setStatus('❌ ' + e.message, 'errore');
    btnComprata.disabled = false; btnRimuovi.disabled = false; btnComprata.textContent = '✓ Comprata';
  }
}

async function _rimuoviDaWishlist(r, btnComprata, btnRimuovi) {
  const conferma = confirm(`Rimuovere "${r.nome || r.codice}" dalla wishlist? Questa azione non si può annullare.`);
  if (!conferma) return;
  btnComprata.disabled = true; btnRimuovi.disabled = true; btnRimuovi.textContent = '⏳';
  try {
    await _chiamaWebApp({ azione: 'eliminaWishlistRiga', riga: r.riga });
    _wishlistRighe = _wishlistRighe.filter(x => x.riga !== r.riga);
    _renderWishlist();
    setStatus(`🗑️ "${r.nome || r.codice}" rimossa dalla wishlist.`, 'info');
  } catch (e) {
    setStatus('❌ ' + e.message, 'errore');
    btnComprata.disabled = false; btnRimuovi.disabled = false; btnRimuovi.textContent = '🗑️ Rimuovi';
  }
}

// ── AGGIORNA PREZZI WISHLIST ──────────────────────────────────────────────────
// Riusa LEGGI_SOLO_PREZZO (già in background.js) — nessuna modifica al service
// worker: la stessa identica infrastruttura di ricontrollo prezzo usata dal
// bulk carte/sealed, qui applicata in sequenza a tutte le righe caricate.
let _aggiornamentoPrezziAttivo = false;

async function _aggiornaPrezziWishlist() {
  if (_aggiornamentoPrezziAttivo) return { avviato: false };
  if (_wishlistRighe.length === 0) { setStatus('⚠️ Wishlist vuota, niente da controllare.', 'info'); return { avviato: false }; }

  _aggiornamentoPrezziAttivo = true;
  // FIX (sessione si blocca se la tab va in background per ore): stesso
  // meccanismo di avviaSessioneBulk — vedi avviaAudioKeepAlive() in shared.js.
  avviaAudioKeepAlive();
  const btn = document.getElementById('btnAggiornaPrezziWishlist');
  btn.disabled = true;
  const righeConUrl = _wishlistRighe.filter(r => r.url && r.url.includes('/Singles/'));

  let aggiornate = 0;
  for (let i = 0; i < righeConUrl.length; i++) {
    const r = righeConUrl[i];
    btn.textContent = `⏳ ${i + 1}/${righeConUrl.length}…`;
    setStatus(`🔄 Aggiorno prezzo ${i + 1}/${righeConUrl.length}: ${r.nome || r.codice}…`, 'info');
    try {
      const urlConFiltri = costruisciUrlFiltrato(r.url, r.lingua, r.condizione);
      const timeoutMs = await _timeoutLetturaCarta();
      const risposta = await _inviaMessaggioConWatchdog({ type: 'LEGGI_SOLO_PREZZO', urlConFiltri, usaWorkerTab: true }, timeoutMs);
      if (risposta && risposta.prezzo != null) {
        // FIX: questa chiamata non aveva MAI il campo 'azione' (residuo
        // dell'epoca Google Apps Script, mai aggiornato con la migrazione a
        // Supabase) — chiamaSupabase(undefined, payload) finiva sempre nel
        // ramo 'default' e falliva in silenzio: il prezzo sembrava
        // aggiornarsi (la riga locale r.prezzo veniva comunque aggiornata
        // sotto) ma la scrittura sul database non avveniva MAI.
        const immagineConvertita3 = risposta.immagine ? await _convertiImmagine(risposta.immagine) : undefined;
        await _chiamaWebApp({ azione: 'aggiornaPrezzoWishlistRiga', riga: r.riga, prezzo: risposta.prezzo, immagine: immagineConvertita3 });
        r.prezzo = risposta.prezzo;
        aggiornate++;
      }
    } catch (_) {
      // Riga singola fallita: non interrompere il resto dell'aggiornamento.
    }
    if (i < righeConUrl.length - 1) await new Promise(res => setTimeout(res, 4000 + Math.floor(Math.random() * 4000)));
  }

  chrome.runtime.sendMessage({ type: 'CHIUDI_WORKER_TAB', kind: 'carte' });
  fermaAudioKeepAlive();
  _renderWishlist();
  setStatus(`✅ Prezzi aggiornati: ${aggiornate}/${righeConUrl.length}.`, 'ok');
  btn.disabled = false;
  btn.textContent = '🔄 Aggiorna prezzi';
  _aggiornamentoPrezziAttivo = false;
  return { avviato: true, aggiornate, totale: righeConUrl.length };
}

// ── ORDINI DAL SITO (autorun) ────────────────────────────────────────────────
// Stesso schema già usato in popup.js per 'controlla_prezzi': background.js
// salva un flag in chrome.storage.local quando prende in carico un ordine
// 'controlla_prezzi_wishlist', e apre/porta in primo piano questa pagina.
// Qui lo consumiamo e avviamo da soli l'aggiornamento, poi scriviamo
// l'esito sulla riga dell'ordine.
async function _avviaAutorunPrezziWishlistSeRichiesto() {
  const { ordinePendenteAutorunWishlist } = await chrome.storage.local.get('ordinePendenteAutorunWishlist');
  if (!ordinePendenteAutorunWishlist) return;
  await chrome.storage.local.remove('ordinePendenteAutorunWishlist');

  const ordineId = ordinePendenteAutorunWishlist.id;
  await assicuraLoginSupabase();
  await _caricaWishlist(); // assicura che _wishlistRighe sia fresca prima di partire

  setStatus('🤖 Ordine ricevuto dal sito — avvio controllo prezzi wishlist...', 'info');
  const risultato = await _aggiornaPrezziWishlist();

  try {
    if (!risultato.avviato) {
      await supabaseClient.from('ordini').update({
        stato: 'completato',
        risultato: { aggiornate: 0, totale: 0, nota: 'Wishlist vuota o nessuna carta con URL valido.' },
        completato_il: new Date().toISOString(),
      }).eq('id', ordineId);
    } else {
      await supabaseClient.from('ordini').update({
        stato: 'completato',
        risultato: { aggiornate: risultato.aggiornate, totale: risultato.totale },
        completato_il: new Date().toISOString(),
      }).eq('id', ordineId);
    }
  } catch (e) {
    console.error('[ordini] impossibile scrivere l\'esito sull\'ordine wishlist:', e);
  }
}

// Se un controllo prezzi wishlist è già "in_corso" (avviato da qualcun
// altro nel gruppo), questo dispositivo controlla anche la PROPRIA
// wishlist appena apre l'estensione — non serve premere nulla. A
// differenza del controllo prezzi delle carte (condiviso tra tutti), la
// wishlist resta personale: "unirsi" qui significa semplicemente "già che
// c'è un giro di controlli in corso nel gruppo, aggiorno anche la mia".
async function _unisciteControlloPrezziWishlistInCorsoSeCe() {
  try {
    // Stesso consenso esplicito usato per il controllo prezzi delle carte
    // (vedi popup.js) — riusa lo stesso interruttore "Aiuta anche il
    // gruppo" già esistente, invece di introdurne uno nuovo.
    const { aiutaGruppo } = await chrome.storage.local.get('aiutaGruppo');
    if (!aiutaGruppo) return;

    const { data: sessionData } = await supabaseClient.auth.getSession();
    if (!sessionData?.session?.user?.id) return;
    if (_aggiornamentoPrezziAttivo) return;

    const sogliaIso = new Date(Date.now() - 15 * 60 * 1000).toISOString();
    const { data: inCorso } = await supabaseClient
      .from('ordini')
      .select('id')
      .eq('tipo', 'controlla_prezzi_wishlist')
      .eq('stato', 'in_corso')
      .gt('preso_in_carico_il', sogliaIso)
      .order('preso_in_carico_il', { ascending: false })
      .limit(1);

    if (!inCorso || inCorso.length === 0) return;
    if (_aggiornamentoPrezziAttivo) return;

    await _caricaWishlist();
    setStatus('🤝 Controllo prezzi wishlist in corso nel gruppo — aggiorno anche la mia...', 'info');
    await _aggiornaPrezziWishlist();
  } catch (e) {
    console.error('[unisciti controllo prezzi wishlist] errore:', e.message);
  }
}

document.getElementById('btnAggiornaPrezziWishlist').addEventListener('click', () => {
  _richiediConfermaLogin(_aggiornaPrezziWishlist);
});

// ── IMPOSTAZIONI BULK (condivise) ────────────────────────────────────────────
function toggleSettingsPanel() {
  const panel = document.getElementById('settingsPanel');
  const btn = document.getElementById('gearBtn');
  const open = panel.classList.toggle('visible');
  btn.classList.toggle('open', open);
  btn.setAttribute('aria-expanded', String(open));
}

document.getElementById('gearBtn').addEventListener('click', toggleSettingsPanel);

// ── ⚙ INOLTRATO DALL'HUB (app.html) ──────────────────────────────────────────
// Quando questa pagina è dentro l'hub (vedi tab_detect.js/embedded-in-hub),
// il proprio header — e quindi questo stesso gearBtn — è nascosto: l'hub
// mostra un'unica icona ⚙ in cima e, al click, la inoltra qui via postMessage
// così il pannello che si apre resta sempre quello giusto per questa pagina.
window.addEventListener('message', (e) => {
  if (e.data && e.data.type === 'CARDSYNC_TOGGLE_SETTINGS') toggleSettingsPanel();
  // FIX: quando una location viene rinominata/eliminata dal popover 📍
  // dell'hub, questa pagina ricarica la propria datalist — altrimenti
  // resterebbe con l'elenco vecchio finché non si riapre/ricarica.
  if (e.data && e.data.type === 'CARDSYNC_REFRESH_LOCATION') _popolaDatalistLocation();
});

function aggiornaLabelDelayMinMax() {
  const vMin = document.getElementById('sliderDelayMin').value;
  const vMax = document.getElementById('sliderDelayMax').value;
  document.getElementById('valDelayMin').textContent = vMin + 's';
  document.getElementById('valDelayMax').textContent = vMax + 's';
}

document.getElementById('sliderDelayMin').addEventListener('input', (e) => {
  const vMin = parseInt(e.target.value);
  const sliderMax = document.getElementById('sliderDelayMax');
  if (vMin > parseInt(sliderMax.value)) sliderMax.value = vMin;
  aggiornaLabelDelayMinMax();
  chrome.storage.local.set({ sliderDelayMinSec: vMin, sliderDelayMaxSec: parseInt(sliderMax.value) });
});

document.getElementById('sliderDelayMax').addEventListener('input', (e) => {
  const vMax = parseInt(e.target.value);
  const sliderMin = document.getElementById('sliderDelayMin');
  if (vMax < parseInt(sliderMin.value)) sliderMin.value = vMax;
  aggiornaLabelDelayMinMax();
  chrome.storage.local.set({ sliderDelayMinSec: parseInt(sliderMin.value), sliderDelayMaxSec: vMax });
});

document.getElementById('sliderPausaOgni').addEventListener('input', (e) => {
  const v = parseInt(e.target.value);
  document.getElementById('valPausaOgni').textContent = PAUSA_OGNI_LABELS[v];
  chrome.storage.local.set({ sliderPausaOgni: v });
});

document.getElementById('avvisoSonoro').addEventListener('change', (e) => {
  chrome.storage.local.set({ avvisoSonoro: e.target.checked });
});

function applicaTema(nome) {
  LISTA_TEMI.forEach(t => document.body.classList.remove(`theme-${t}`));
  if (nome !== 'purple') document.body.classList.add(`theme-${nome}`);
  document.body.classList.toggle('tema-attivo', nome !== 'purple');
}

// ── LOCATION (condivisa con Carte e Sealed) ──────────────────────────────────
// Le location vivono nella scheda dedicata "LOCATION" (colonna B, valori da
// riga 2) — quella collegata alla validazione dati della tendina Location
// nell'Inventario. Il campo qui sotto legge quell'elenco (autocompletamento)
// e, se si scrive un valore nuovo mai visto, lo registra al volo in quella
// scheda quando si clicca "✓ Comprata" (vedi _registraLocationSeNuova) —
// così da quel momento compare anche nella tendina nativa del foglio.
// Condiviso in storage con le altre pagine "aggiungi".
const LOCATION_TAB_NAME = 'LOCATION';
const LOCATION_TAB_COL = 'B';
const LOCATION_TAB_RIGA_INIZIO = 2;
let _locationConosciute = [];

function _leggiLocationCorrente() {
  const el = document.getElementById('inputLocation');
  const val = el ? el.value.trim() : '';
  return val || '?';
}

document.getElementById('inputLocation')?.addEventListener('input', (e) => {
  chrome.storage.local.set({ bulkLocation: e.target.value });
});

async function _popolaDatalistLocation() {
  const datalist = document.getElementById('locationOptions');
  if (!datalist) return;
  try {
    const data = await chiamaSupabase('elencaLocationTab', {});
    if (!data.ok) return;
    _locationConosciute = data.location || [];
    datalist.innerHTML = '';
    _locationConosciute.forEach((loc) => {
      const opt = document.createElement('option');
      opt.value = loc;
      datalist.appendChild(opt);
    });
  } catch (_) {
    // Silenzioso: connessione non ancora configurata/raggiungibile — il
    // campo resta comunque utilizzabile in scrittura libera.
  }
}

// Se il valore scelto non è tra quelli già noti nella scheda LOCATION, lo
// registra lì al volo prima di usarlo — chiamata da _segnaComprata.
async function _registraLocationSeNuova() {
  const nome = document.getElementById('inputLocation')?.value.trim();
  if (!nome || _locationConosciute.includes(nome)) return;
  try {
    const data = await chiamaSupabase('aggiungiLocationTab', { nome });
    if (data.ok) {
      _locationConosciute.push(nome);
      window.parent.postMessage({ type: 'CARDSYNC_LOCATION_ADDED' }, '*');
    }
  } catch (_) {
    // Silenzioso: se la registrazione fallisce, la carta viene comunque
    // spostata con questo valore in Location — solo la tendina nativa del
    // foglio non lo includerà finché non si riprova.
  }
}

// ── LOGIN SUPABASE ────────────────────────────────────────────────────────────
assicuraLoginSupabase();

// ── BOOT ──────────────────────────────────────────────────────────────────────
chrome.storage.local.get([...CAMPI_STORAGE, 'wishlistSessione',
  'sliderDelay', 'sliderDelayMinSec', 'sliderDelayMaxSec', 'sliderPausaOgni', 'avvisoSonoro', 'bulkLocation', 'cardsyncDarkMode'], (saved) => {
  applicaTema(saved.selectedTheme || 'purple');
  document.body.classList.toggle('modo-scuro', saved.cardsyncDarkMode === true);
  const _inputLocationEl = document.getElementById('inputLocation');
  if (_inputLocationEl && saved.bulkLocation) _inputLocationEl.value = saved.bulkLocation;
  _popolaDatalistLocation();

  let vDelayMin = saved.sliderDelayMinSec;
  let vDelayMax = saved.sliderDelayMaxSec;
  if (vDelayMin === undefined || vDelayMax === undefined) {
    if (typeof saved.sliderDelay === 'number' && LEGACY_DELAY_RANGES_SEC[saved.sliderDelay]) {
      [vDelayMin, vDelayMax] = LEGACY_DELAY_RANGES_SEC[saved.sliderDelay];
    } else {
      vDelayMin = DEFAULT_DELAY_MIN_SEC;
      vDelayMax = DEFAULT_DELAY_MAX_SEC;
    }
    chrome.storage.local.set({ sliderDelayMinSec: vDelayMin, sliderDelayMaxSec: vDelayMax });
  }
  const vPausa = saved.sliderPausaOgni ?? 1;
  document.getElementById('sliderDelayMin').value = vDelayMin;
  document.getElementById('sliderDelayMax').value = vDelayMax;
  document.getElementById('sliderPausaOgni').value = vPausa;
  aggiornaLabelDelayMinMax();
  document.getElementById('valPausaOgni').textContent = PAUSA_OGNI_LABELS[vPausa];
  document.getElementById('avvisoSonoro').checked = saved.avvisoSonoro !== false;

  if (saved.wishlistSessione) {
    const { listaRaw, indiceFermo, totale } = saved.wishlistSessione;
    const banner = document.getElementById('bulkRiprendiBanner');
    if (banner) {
      banner.style.display = '';
      banner.querySelector('.bulk-riprendi-info').textContent = `Sessione interrotta: ${indiceFermo}/${totale} carte completate. Riprendi dalla carta ${indiceFermo + 1}?`;
      banner.querySelector('#btnRiprendi').addEventListener('click', () => {
        banner.style.display = 'none';
        document.getElementById('bulkInput').value = listaRaw;
        _richiediConfermaLogin(() => setTimeout(() => avviaSessioneBulk(indiceFermo), 100));
      });
      banner.querySelector('#btnScartaSessione').addEventListener('click', () => {
        banner.style.display = 'none';
        chrome.storage.local.remove('wishlistSessione');
      });
    }
  }

  // Caricamento automatico: prima bisognava premere "↺ Carica" a mano —
  // l'obiettivo ora è che l'utente non debba fare nulla dentro l'estensione,
  // comandando tutto da Pages, quindi la wishlist si carica da sola appena
  // la pagina è pronta.
  _caricaWishlist();

  // FIX (coda unica): questa pagina NON prende più in carico da sola righe
  // in attesa — quel compito ora appartiene solo ad aggiungi_carta_popup.js,
  // che legge un'unica coda condivisa (coda_carte) invece di due code
  // indipendenti. Qui restano solo un refresh periodico della vista (vedi
  // setInterval più sotto) per mostrare quanto l'altra pagina ha scritto nel
  // frattempo, e l'autorun del controllo prezzi qui sotto (concetto diverso,
  // non tocca la coda di inserimento).

  // FASE ordini "controlla_prezzi_wishlist": se background.js ha lasciato un
  // flag in attesa (perché il sito ha chiesto un controllo prezzi anche per
  // la wishlist), lo consumiamo qui e avviamo da soli lo stesso identico
  // aggiornamento che partirebbe cliccando "🔄 Aggiorna prezzi" a mano.
  _avviaAutorunPrezziWishlistSeRichiesto().then(() => {
    if (!_aggiornamentoPrezziAttivo) _unisciteControlloPrezziWishlistInCorsoSeCe();
  });
});

chrome.storage.onChanged.addListener((changes) => {
  if (changes.selectedTheme) location.reload(); // FIX: refresh vero invece di un cambio 'a caldo' incompleto
  if (changes.cardsyncDarkMode) location.reload();
  if (changes.bulkLocation !== undefined) {
    const el = document.getElementById('inputLocation');
    if (el && document.activeElement !== el) el.value = changes.bulkLocation.newValue || '';
  }
  if (changes.sliderDelayMinSec) document.getElementById('sliderDelayMin').value = changes.sliderDelayMinSec.newValue ?? 10;
  if (changes.sliderDelayMaxSec) document.getElementById('sliderDelayMax').value = changes.sliderDelayMaxSec.newValue ?? 20;
  if (changes.sliderDelayMinSec || changes.sliderDelayMaxSec) aggiornaLabelDelayMinMax();
  if (changes.sliderPausaOgni) {
    const v = changes.sliderPausaOgni.newValue ?? 1;
    document.getElementById('sliderPausaOgni').value = v;
    document.getElementById('valPausaOgni').textContent = PAUSA_OGNI_LABELS[v];
  }
  if (changes.avvisoSonoro !== undefined) document.getElementById('avvisoSonoro').checked = changes.avvisoSonoro.newValue !== false;
});

// ── RESET ─────────────────────────────────────────────────────────────────────
document.getElementById('btnReset').addEventListener('click', () => {
  setStatus('', '');
  chrome.runtime.sendMessage({ type: 'CHIUDI_WORKER_TAB', kind: 'carte' });
  const cardCorr = document.getElementById('cardCorrezione');
  if (cardCorr) { cardCorr.style.display = 'none'; const p = document.getElementById('pannelloCorrezione'); p.innerHTML = ''; p.classList.remove('visible'); }
  _codaCorrezione = []; _codaCorrezioneTot = 0;
  const bulkProg = document.getElementById('bulkProgress');
  if (bulkProg) {
    bulkProg.classList.remove('visible');
    document.getElementById('bpFill').style.width = '0%';
    document.getElementById('bpCount').textContent = '0 / 0';
    document.getElementById('bpCarta').textContent = '—';
    document.getElementById('bpStima').textContent = 'stima —';
    document.getElementById('bpTimer').textContent = '—';
  }
  document.getElementById('bulkInput').value = '';
  logEntries = []; logCount = 0;
  document.getElementById('logBody').innerHTML = '<div class="log-empty">Nessuna carta aggiunta ancora.</div>';
  document.getElementById('logBadge').textContent = '0';
  chrome.storage.local.remove('wishlistSessione');
});

// ── BUG REPORT / CHANGELOG ────────────────────────────────────────────────────
document.getElementById('bugReportLink').addEventListener('click', (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: e.currentTarget.href });
});
document.getElementById('changelogLink').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('changelog.html') });
});

// ── AUTO-MAIUSCOLO ───────────────────────────────────────────────────────────
document.getElementById('bulkInput').addEventListener('input', (e) => {
  const el = e.target;
  const start = el.selectionStart, end = el.selectionEnd;
  el.value = el.value.toUpperCase();
  el.setSelectionRange(start, end);
});
