// ─────────────────────────────────────────────────────────────────────────────
// SNIPPET — Gestione scheda LOCATION (elenco / aggiungi / rinomina / elimina)
// ─────────────────────────────────────────────────────────────────────────────
// SOSTITUISCE la versione precedente di questo file — quella partiva dal
// presupposto sbagliato che le location venissero lette scansionando la
// colonna Location dell'Inventario. In realtà esiste una scheda dedicata
// chiamata "LOCATION" (colonna B, valori dalla riga 2 — riga 1 vuota) usata
// come validazione dati per la tendina Location nell'Inventario: è QUELLA
// la fonte vera, e va gestita direttamente.
//
// Da incollare dentro il tuo doPost(e) esistente in webapp_scrivi_prezzi.gs,
// come quattro nuovi rami "if (dati.azione === ...)" accanto a quelli già
// presenti — stesso pattern già usato per Wishlist/profili.
//
// COME INTEGRARLO
//   1. Se avevi già incollato la VERSIONE PRECEDENTE di questo snippet,
//      rimuovila prima di incollare questa (cerca 'rinominaLocation' e
//      'eliminaLocation' SENZA "Tab" alla fine — sono i vecchi nomi azione,
//      da non confondere con quelli nuovi qui sotto).
//   2. Apri il tuo Google Sheet → Estensioni → Apps Script.
//   3. Nel tuo doPost(e) esistente, incolla i QUATTRO blocchi qui sotto
//      accanto alle altre azioni, PRIMA del ramo "else" finale che gestisce
//      la scrittura diretta di cella (quello usato da colPrezzo/prezzi,
//      senza "azione").
//   4. Salva (Ctrl+S).
//   5. IMPORTANTE — "Gestisci distribuzioni" → modifica la versione attiva
//      (o crea una nuova distribuzione): salvare da solo l'editor NON basta.
//
// COSA FANNO
//   'elencaLocationTab'   — legge tutti i valori dalla scheda LOCATION
//                           (colonna B, da riga 2 in poi).
//   'aggiungiLocationTab' — aggiunge un nuovo valore in fondo alla lista
//                           nella scheda LOCATION (se non è già presente,
//                           confronto case-sensitive su testo "trimmato").
//                           Grazie alla validazione dati già collegata a
//                           quell'intervallo, il nuovo valore compare subito
//                           anche nella tendina nativa di Google Sheets.
//   'rinominaLocationTab' — cambia un valore nella scheda LOCATION E, in
//                           più, aggiorna tutte le righe dell'Inventario che
//                           lo usavano (stessa colonna/riga di partenza già
//                           configurate per il foglio principale).
//   'eliminaLocationTab'  — rimuove la riga corrispondente dalla scheda
//                           LOCATION (sparisce dalla tendina) E riporta a
//                           "?" le righe dell'Inventario che la usavano
//                           (non le cancella).
//
//   Nomi scheda/colonna/riga di partenza della scheda LOCATION sono
//   parametrizzati nel payload (con questi default): sheetLocationTab
//   = 'LOCATION', colLocationTab = 'B', rigaInizioLocationTab = 2.
// ─────────────────────────────────────────────────────────────────────────────

if (dati.azione === 'elencaLocationTab') {
  var sheetLocTab = dati.sheetLocationTab || 'LOCATION';
  var colLocTab = dati.colLocationTab || 'B';
  var rigaInizioLocTab = dati.rigaInizioLocationTab || 2;

  var foglioLoc = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(sheetLocTab);
  if (!foglioLoc) {
    return ContentService.createTextOutput(JSON.stringify({
      ok: false, errore: 'Scheda "' + sheetLocTab + '" non trovata.'
    })).setMimeType(ContentService.MimeType.JSON);
  }

  var ultimaRigaLoc = foglioLoc.getLastRow();
  var elenco = [];
  if (ultimaRigaLoc >= rigaInizioLocTab) {
    var valoriLoc = foglioLoc.getRange(colLocTab + rigaInizioLocTab + ':' + colLocTab + ultimaRigaLoc).getValues();
    for (var i = 0; i < valoriLoc.length; i++) {
      var v = (valoriLoc[i][0] || '').toString().trim();
      if (v) elenco.push(v);
    }
  }

  return ContentService.createTextOutput(JSON.stringify({
    ok: true, location: elenco
  })).setMimeType(ContentService.MimeType.JSON);
}

if (dati.azione === 'aggiungiLocationTab') {
  var sheetLocTab = dati.sheetLocationTab || 'LOCATION';
  var colLocTab = dati.colLocationTab || 'B';
  var rigaInizioLocTab = dati.rigaInizioLocationTab || 2;
  var nomeNuovo = (dati.nome || '').toString().trim();

  if (!nomeNuovo) {
    return ContentService.createTextOutput(JSON.stringify({
      ok: false, errore: 'Nome location mancante.'
    })).setMimeType(ContentService.MimeType.JSON);
  }

  var foglioLoc = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(sheetLocTab);
  if (!foglioLoc) {
    return ContentService.createTextOutput(JSON.stringify({
      ok: false, errore: 'Scheda "' + sheetLocTab + '" non trovata.'
    })).setMimeType(ContentService.MimeType.JSON);
  }

  var ultimaRigaLoc = foglioLoc.getLastRow();
  var primaRigaLibera = rigaInizioLocTab;

  if (ultimaRigaLoc >= rigaInizioLocTab) {
    var valoriLoc = foglioLoc.getRange(colLocTab + rigaInizioLocTab + ':' + colLocTab + ultimaRigaLoc).getValues();
    for (var i = 0; i < valoriLoc.length; i++) {
      var v = (valoriLoc[i][0] || '').toString().trim();
      if (v === nomeNuovo) {
        return ContentService.createTextOutput(JSON.stringify({
          ok: true, giaEsistente: true, riga: rigaInizioLocTab + i
        })).setMimeType(ContentService.MimeType.JSON);
      }
      if (v) primaRigaLibera = rigaInizioLocTab + i + 1;
    }
  }

  foglioLoc.getRange(colLocTab + primaRigaLibera).setValue(nomeNuovo);

  return ContentService.createTextOutput(JSON.stringify({
    ok: true, giaEsistente: false, riga: primaRigaLibera
  })).setMimeType(ContentService.MimeType.JSON);
}

if (dati.azione === 'rinominaLocationTab') {
  var sheetLocTab = dati.sheetLocationTab || 'LOCATION';
  var colLocTab = dati.colLocationTab || 'B';
  var rigaInizioLocTab = dati.rigaInizioLocationTab || 2;
  var vecchioNome = (dati.vecchioNome || '').toString().trim();
  var nuovoNome = (dati.nuovoNome || '').toString().trim();

  if (!vecchioNome || !nuovoNome) {
    return ContentService.createTextOutput(JSON.stringify({
      ok: false, errore: 'Nome vecchio/nuovo mancante.'
    })).setMimeType(ContentService.MimeType.JSON);
  }

  var foglioLoc = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(sheetLocTab);
  if (!foglioLoc) {
    return ContentService.createTextOutput(JSON.stringify({
      ok: false, errore: 'Scheda "' + sheetLocTab + '" non trovata.'
    })).setMimeType(ContentService.MimeType.JSON);
  }

  // 1) Rinomina nella scheda LOCATION (il "master" della tendina).
  var ultimaRigaLoc = foglioLoc.getLastRow();
  if (ultimaRigaLoc >= rigaInizioLocTab) {
    var rangeLoc = foglioLoc.getRange(colLocTab + rigaInizioLocTab + ':' + colLocTab + ultimaRigaLoc);
    var valoriLoc = rangeLoc.getValues();
    for (var i = 0; i < valoriLoc.length; i++) {
      var v = (valoriLoc[i][0] || '').toString().trim();
      if (v === vecchioNome) { valoriLoc[i][0] = nuovoNome; }
    }
    rangeLoc.setValues(valoriLoc);
  }

  // 2) Propaga il rinomino a tutte le righe dell'Inventario che usavano il
  //    vecchio nome, così restano coerenti con la scheda LOCATION.
  var foglioInv = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(dati.sheetName);
  var righeInventarioAggiornate = 0;
  if (foglioInv) {
    var colInv = dati.colLocation || 'D';
    var rigaInizioInv = dati.rigaInizio || 4;
    var ultimaRigaInv = foglioInv.getLastRow();
    if (ultimaRigaInv >= rigaInizioInv) {
      var rangeInv = foglioInv.getRange(colInv + rigaInizioInv + ':' + colInv + ultimaRigaInv);
      var valoriInv = rangeInv.getValues();
      for (var j = 0; j < valoriInv.length; j++) {
        var vi = (valoriInv[j][0] || '').toString().trim();
        if (vi === vecchioNome) { valoriInv[j][0] = nuovoNome; righeInventarioAggiornate++; }
      }
      if (righeInventarioAggiornate > 0) rangeInv.setValues(valoriInv);
    }
  }

  return ContentService.createTextOutput(JSON.stringify({
    ok: true, righeInventarioAggiornate: righeInventarioAggiornate
  })).setMimeType(ContentService.MimeType.JSON);
}

if (dati.azione === 'eliminaLocationTab') {
  var sheetLocTab = dati.sheetLocationTab || 'LOCATION';
  var colLocTab = dati.colLocationTab || 'B';
  var rigaInizioLocTab = dati.rigaInizioLocationTab || 2;
  var nomeElimina = (dati.nome || '').toString().trim();

  if (!nomeElimina) {
    return ContentService.createTextOutput(JSON.stringify({
      ok: false, errore: 'Nome location mancante.'
    })).setMimeType(ContentService.MimeType.JSON);
  }

  var foglioLoc = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(sheetLocTab);
  if (!foglioLoc) {
    return ContentService.createTextOutput(JSON.stringify({
      ok: false, errore: 'Scheda "' + sheetLocTab + '" non trovata.'
    })).setMimeType(ContentService.MimeType.JSON);
  }

  // 1) Rimuove la riga corrispondente dalla scheda LOCATION (sparisce dalla
  //    tendina nativa, che punta a quell'intervallo).
  var ultimaRigaLoc = foglioLoc.getLastRow();
  if (ultimaRigaLoc >= rigaInizioLocTab) {
    var valoriLoc = foglioLoc.getRange(colLocTab + rigaInizioLocTab + ':' + colLocTab + ultimaRigaLoc).getValues();
    for (var i = 0; i < valoriLoc.length; i++) {
      var v = (valoriLoc[i][0] || '').toString().trim();
      if (v === nomeElimina) {
        foglioLoc.deleteRow(rigaInizioLocTab + i);
        break;
      }
    }
  }

  // 2) Le righe dell'Inventario che la usavano tornano a "?" (non vengono
  //    cancellate, solo il tag Location viene rimosso).
  var foglioInv = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(dati.sheetName);
  var righeInventarioAggiornate = 0;
  if (foglioInv) {
    var colInv = dati.colLocation || 'D';
    var rigaInizioInv = dati.rigaInizio || 4;
    var ultimaRigaInv = foglioInv.getLastRow();
    if (ultimaRigaInv >= rigaInizioInv) {
      var rangeInv = foglioInv.getRange(colInv + rigaInizioInv + ':' + colInv + ultimaRigaInv);
      var valoriInv = rangeInv.getValues();
      for (var j = 0; j < valoriInv.length; j++) {
        var vi = (valoriInv[j][0] || '').toString().trim();
        if (vi === nomeElimina) { valoriInv[j][0] = '?'; righeInventarioAggiornate++; }
      }
      if (righeInventarioAggiornate > 0) rangeInv.setValues(valoriInv);
    }
  }

  return ContentService.createTextOutput(JSON.stringify({
    ok: true, righeInventarioAggiornate: righeInventarioAggiornate
  })).setMimeType(ContentService.MimeType.JSON);
}
