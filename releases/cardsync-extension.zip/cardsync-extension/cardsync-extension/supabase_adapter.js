// ── supabase_adapter.js ──────────────────────────────────────────────────────
const SUPABASE_URL = 'https://iwdkgehbktvkujhwqdwq.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Iml3ZGtnZWhia3R2a3VqaHdxZHdxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODYxMzM1MzYsImV4cCI6MjEwMTcwOTUzNn0.Pdcmuj5eXuh_z43CInsdGRkNwloHpqlhBGnBI9kvKe0';

const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    storage: {
      getItem: (key) => new Promise((resolve) => {
        chrome.storage.local.get([key], (r) => resolve(r[key] || null));
      }),
      setItem: (key, value) => new Promise((resolve) => {
        chrome.storage.local.set({ [key]: value }, resolve);
      }),
      removeItem: (key) => new Promise((resolve) => {
        chrome.storage.local.remove([key], resolve);
      }),
    },
    autoRefreshToken: true,
    persistSession: true,
  },
});

// ── CONTROLLO VERSIONE PRIMA DI OGNI SCRITTURA ────────────────────────────────
// Richiesta esplicita: un'estensione con una versione vecchia in giro
// potrebbe scrivere dati nel formato sbagliato o con una logica superata,
// rischiando di danneggiare il database condiviso da tutto il gruppo. Prima
// di QUALUNQUE azione (lettura o scrittura, per sicurezza — non solo le
// scritture) si verifica di essere aggiornati.
//
// Il controllo è messo in CACHE per 3 minuti (non ad ogni singola chiamata)
// per non rallentare il lavoro con una richiesta di rete continua — un
// controllo ogni 3 minuti è più che sufficiente per intercettare in tempo
// utile un'estensione rimasta indietro, senza appesantire nulla.
//
// Fallisce in modo PERMISSIVO se il controllo stesso non riesce (es.
// offline): meglio lasciar lavorare qualcuno senza internet in quel momento
// che bloccarlo per un controllo che non può nemmeno completarsi.
const URL_ULTIMA_VERSIONE_ADAPTER = 'https://claudio-git-poke.github.io/CardSyncProOnline/releases/latest-version.txt';
let _ultimoControlloVersioneMs = 0;
let _versioneAggiornataCache = true;

function _versioneMaggioreAdapter(a, b) {
  const pa = String(a).split('.').map(Number);
  const pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const na = pa[i] || 0, nb = pb[i] || 0;
    if (na > nb) return true;
    if (na < nb) return false;
  }
  return false;
}

async function _verificaVersioneAggiornata() {
  const ora = Date.now();
  if (ora - _ultimoControlloVersioneMs < 3 * 60 * 1000) return _versioneAggiornataCache;
  _ultimoControlloVersioneMs = ora;

  // Controllo 1 — lato CLIENT: confronta con il file di testo sul sito.
  // Veloce, ma un'estensione manomessa potrebbe teoricamente aggirarlo.
  let clientOk = true;
  try {
    const resp = await fetch(URL_ULTIMA_VERSIONE_ADAPTER + '?t=' + ora, { cache: 'no-store' });
    if (resp.ok) {
      const ultima = (await resp.text()).trim();
      const locale = chrome.runtime.getManifest().version;
      clientOk = !ultima || !_versioneMaggioreAdapter(ultima, locale);
    }
  } catch (_) { /* offline — non blocca su questo controllo da solo */ }

  // Controllo 2 — lato DATABASE: la decisione finale non dipende solo dal
  // client. Anche se qualcuno manomettesse l'estensione per aggirare il
  // controllo 1, questa chiamata al database solleva comunque un errore
  // esplicito se la versione dichiarata non è quella minima richiesta —
  // impostata nella tabella configurazione_app, modificabile solo da SQL.
  let dbOk = true;
  try {
    await supabaseClient.rpc('verifica_versione_minima', { p_versione_client: chrome.runtime.getManifest().version });
  } catch (e) {
    if (e?.message?.includes('ESTENSIONE_NON_AGGIORNATA')) dbOk = false;
    // altri errori (es. offline, funzione non ancora creata) non bloccano —
    // permissivo per non impedire il lavoro per un controllo che non è
    // nemmeno riuscito a completarsi.
  }

  _versioneAggiornataCache = clientOk && dbOk;
  return _versioneAggiornataCache;
}

// ── FUNZIONE PRINCIPALE — traduce ogni "azione" in un comando Supabase ─────
async function chiamaSupabase(azione, payload) {
  const { data: sessionData } = await supabaseClient.auth.getSession();
  const userId = sessionData?.session?.user?.id;
  if (!userId) return { ok: false, errore: 'Non sei loggato — apri il popover account.' };

  if (!(await _verificaVersioneAggiornata())) {
    return { ok: false, errore: 'Estensione non aggiornata — aggiorna prima di continuare (vedi il sito per le istruzioni).' };
  }

  switch (azione) {

    case 'aggiungi': {
      const riga = _rigaDatiToSupabase(payload.rigaDati, payload.statoOverride);
      // FIX (bug "carte di un altro finite nel mio database"): se questa
      // riga viene dalla coda condivisa (coda_carte, dbRigaId presente),
      // usa la RPC che scrive col proprietario REALE della richiesta —
      // letto dalla riga di coda stessa, non da chi sta materialmente
      // elaborando in questo momento. Solo l'aggiunta manuale (senza
      // dbRigaId) resta attribuita a chi è loggato qui.
      if (payload.dbRigaId) {
        const { data: nuovoId, error } = await supabaseClient.rpc('completa_riga_coda_carte', {
          p_riga_coda_id: payload.dbRigaId,
          p_nome: riga.nome, p_codice: riga.codice, p_location: riga.location,
          p_qty: riga.qty, p_lingua: riga.lingua, p_condizione: riga.condizione,
          p_url: riga.url, p_prezzo: riga.prezzo, p_note: riga.note,
          p_immagine: riga.immagine, p_tipo: payload.tipoOverride || null,
          p_destinazione: payload.destinazione || 'collezione',
          p_prezzo_obiettivo: riga.prezzo_obiettivo,
        });
        if (error) return { ok: false, errore: error.message };
        return { ok: true, riga: nuovoId };
      }
      riga.owner_id = userId;
      if (payload.tipoOverride) riga.tipo = payload.tipoOverride;
      const { data, error } = await supabaseClient.from('carte').insert(riga).select().single();
      if (error) return { ok: false, errore: error.message };
      return { ok: true, riga: data.id };
    }

    // ── WISHLIST (tabella separata da 'carte', vedi wishlist_tabella_separata.sql) ─
    case 'aggiungiWishlist': {
      const riga = _rigaDatiToWishlist(payload.rigaDati);
      // FIX: stesso bug/stessa soluzione del case 'aggiungi' qui sopra —
      // vedi quei commenti per il perché.
      if (payload.dbRigaId) {
        const { data: nuovoId, error } = await supabaseClient.rpc('completa_riga_coda_carte', {
          p_riga_coda_id: payload.dbRigaId,
          p_nome: riga.nome, p_codice: riga.codice, p_location: riga.location,
          p_qty: riga.qty, p_lingua: riga.lingua, p_condizione: riga.condizione,
          p_url: riga.url, p_prezzo: riga.prezzo, p_note: riga.note,
          p_immagine: riga.immagine, p_tipo: payload.tipo || null,
          p_destinazione: 'wishlist',
          p_prezzo_obiettivo: riga.prezzo_obiettivo,
        });
        if (error) return { ok: false, errore: error.message };
        return { ok: true, riga: nuovoId };
      }
      riga.owner_id = userId;
      if (payload.tipo) riga.tipo = payload.tipo; // 'sealed' per ETB/UPC/box, altrimenti carta singola
      const { data, error } = await supabaseClient.from('wishlist').insert(riga).select().single();
      if (error) return { ok: false, errore: error.message };
      return { ok: true, riga: data.id };
    }

    case 'leggiWishlist': {
      const { data, error } = await supabaseClient.from('wishlist').select('*').eq('owner_id', userId).order('nome');
      if (error) return { ok: false, errore: error.message };
      return { ok: true, righe: (data || []).map(_supabaseToRigaWishlist) };
    }

    case 'eliminaWishlistRiga': {
      const { error } = await supabaseClient.from('wishlist').delete().eq('id', payload.riga).eq('owner_id', userId);
      if (error) return { ok: false, errore: error.message };
      return { ok: true };
    }

    case 'aggiornaPrezzoWishlistRiga': {
      const aggiornamento = { prezzo: payload.prezzo, ultimo_controllo: new Date().toISOString() };
      if (payload.immagine) aggiornamento.immagine = payload.immagine; // stesso FIX di aggiornaPrezzoRiga
      const { error } = await supabaseClient.from('wishlist')
        .update(aggiornamento)
        .eq('id', payload.riga).eq('owner_id', userId);
      if (error) return { ok: false, errore: error.message };
      return { ok: true };
    }

    case 'spostaWishlistInCollezione': {
      // "✓ Comprata": copia la riga nella collezione vera e propria (stato
      // 'collezione'), poi la rimuove dalla wishlist. Due passaggi separati,
      // non una singola transazione SQL — se il secondo fallisse dopo il
      // primo, la riga resterebbe duplicata in entrambe le tabelle invece
      // che sparire da tutte e due: un doppione è un problema visibile e
      // facile da sistemare a mano, una carta persa no.
      const riga = {
        nome: payload.nome || null,
        codice: payload.codice || null,
        location: payload.location || null,
        qty: payload.qty || 1,
        lingua: payload.lingua || 'IT',
        condizione: payload.condizione || 'NM',
        url: payload.url || null,
        prezzo: (payload.prezzo !== '' && payload.prezzo != null) ? payload.prezzo : null,
        note: payload.note || null,
        stato: 'collezione',
        owner_id: userId,
      };
      const { data, error } = await supabaseClient.from('carte').insert(riga).select().single();
      if (error) return { ok: false, errore: error.message };
      const { error: errDel } = await supabaseClient.from('wishlist').delete().eq('id', payload.wishlistRigaId).eq('owner_id', userId);
      if (errDel) return { ok: false, errore: 'Aggiunta alla collezione riuscita, ma rimozione dalla wishlist fallita: ' + errDel.message };
      return { ok: true, riga: data.id };
    }

    case 'svuotaRiga': {
      const { error } = await supabaseClient.from('carte').delete().eq('id', payload.riga).eq('owner_id', userId);
      if (error) return { ok: false, errore: error.message };
      return { ok: true, riga: payload.riga };
    }

    // ── LETTURA COLLEZIONE (pagina "Aggiorna prezzi") ──────────────────────
    case 'leggi': {
      // FIX (Fase 8 — controllo prezzi condiviso): niente più filtro
      // owner_id FISSO — la collezione (stato 'collezione') è visibile a
      // tutto il gruppo grazie alla policy RLS "collezione condivisa
      // gruppo", ma di default (soloProprie=true, valore inviato dal popup
      // quando "🤝 Aiuta anche il gruppo" è SPENTO — il default) ogni
      // sessione filtra comunque solo le proprie carte: nessuno deve
      // ritrovarsi ad "aiutare" gli altri senza averlo attivato lui stesso.
      // FIX (controllo prezzi eseguito da un dispositivo diverso da chi
      // l'ha richiesto): "solo le mie" deve riferirsi al PROPRIETARIO
      // DELLA RICHIESTA (payload.ownerIdRichiesto, presente per gli ordini
      // creati dal sito), non a chi sta materialmente eseguendo in questo
      // momento — altrimenti un dispositivo che esegue per conto di
      // qualcun altro finiva per controllare le proprie carte al posto di
      // quelle richieste.
      // FIX: un array vuoto ([]) è "truthy" in JavaScript — senza questo
      // controllo, filtroLocation:[] finiva comunque nel ramo "applica
      // filtro" qui sotto, e un IN su un elenco vuoto restituirebbe SEMPRE
      // zero righe. "Nessuna location scelta" deve sempre significare
      // "tutte", mai "nessuna".
      const haFiltroLocation = payload.filtroLocation
        && (!Array.isArray(payload.filtroLocation) || payload.filtroLocation.length > 0);

      // FIX (controllo prezzi non diviso tra dispositivi, come già successo
      // per l'aggiunta carte): prima questa chiamata reclamava TUTTE le
      // carte eleggibili in un colpo solo — chi partiva per primo si
      // prendeva tutto, lasciando l'altro dispositivo a zero. payload.soloConta
      // fa un conteggio veloce senza reclamare nulla (usato solo per la
      // stima a schermo); altrimenti il lotto è limitato a poche carte per
      // volta (payload.lottoSize, default 3) — il chiamante (popup.js) ne
      // richiede altre quando questo lotto finisce, lasciando periodicamente
      // spazio ad altri dispositivi per reclamare la loro parte.
      //
      // RISOLTO (Problema #1, ultimo punto): questo conteggio, quando "Aiuta
      // il gruppo" è attivo, doveva leggere righe di altri owner — prima si
      // appoggiava alla stessa policy larga già rimossa dagli altri punti
      // (query diretta con select('*') eseguita solo in modalità count/head,
      // quindi nessun dato reale usciva comunque, ma la policy restava
      // necessaria per il conteggio stesso). Ora passa dalla RPC dedicata
      // conta_carte_da_controllare_gruppo (SECURITY DEFINER), stessa identica
      // logica di filtro replicata lato database, restituisce solo un
      // numero.
      if (payload.soloConta) {
        const { data: totale, error: errConta } = await supabaseClient.rpc('conta_carte_da_controllare_gruppo', {
          p_owner_id_richiesto: payload.ownerIdRichiesto || null,
          p_solo_proprie: payload.soloProprie !== false,
          p_filtro_location: haFiltroLocation ? (Array.isArray(payload.filtroLocation) ? payload.filtroLocation : [payload.filtroLocation]) : null,
          p_solo_vecchie: !!payload.soloVecchie,
          p_giorni_minimi: payload.giorniMinimi || 3,
        });
        if (errConta) return { ok: false, errore: errConta.message };
        return { ok: true, totale: totale || 0 };
      }

      // FIX (due dispositivi finivano per controllare le STESSE carte):
      // prima la prenotazione avveniva in due passaggi separati — prima si
      // LEGGEVANO le carte libere, poi si SCRIVEVA la prenotazione. Tra
      // questi due passaggi c'era una finestra in cui un secondo
      // dispositivo, chiedendo lavoro quasi nello stesso istante, poteva
      // leggere le STESSE carte (ancora non risultavano prenotate) prima
      // che la scrittura del primo si registrasse — una race condition
      // classica. Ora una funzione sul database fa lettura+prenotazione in
      // un solo passaggio indivisibile (FOR UPDATE SKIP LOCKED), che
      // Postgres garantisce non poter mai assegnare due volte.
      const { data, error } = await supabaseClient.rpc('reclama_carte_per_controllo_prezzi', {
        p_user_id: userId,
        p_owner_id_richiesto: payload.ownerIdRichiesto || null,
        p_solo_proprie: payload.soloProprie !== false,
        p_filtro_location: haFiltroLocation ? (Array.isArray(payload.filtroLocation) ? payload.filtroLocation : [payload.filtroLocation]) : null,
        p_solo_vecchie: !!payload.soloVecchie,
        p_giorni_minimi: payload.giorniMinimi || 3,
        p_lotto_size: payload.lottoSize || 3,
      });
      if (error) return { ok: false, errore: error.message };
      const righeReclamate = data || [];

      // FIX (claim del controllo prezzi confuso tra più PC con lo stesso
      // account): la funzione sul database (reclama_carte_per_controllo_prezzi)
      // prenota le righe con claimed_by=userId, MA userId è l'ACCOUNT, non il
      // singolo PC — due dispositivi loggati con lo stesso account (es.
      // desktop + portatile) finivano indistinguibili agli occhi del claim, e
      // 'rilasciaClaim' (sotto) liberava le prenotazioni di ENTRAMBI insieme,
      // anche se uno dei due stava ancora lavorando. Qui, subito dopo il claim
      // atomico già fatto dalla funzione database, marchiamo in più le stesse
      // righe con il nome di QUESTO dispositivo (stesso campo 'dispositivo'
      // già usato per coda_carte, vedi nomeDispositivo() in shared.js) — un
      // solo aggiornamento per l'intero lotto (non uno a carta), quindi non
      // rallenta la sessione. Se questa scrittura extra fallisse per un
      // motivo qualunque, non blocchiamo comunque la sessione: le carte
      // restano prenotate lo stesso (claimed_by è già a posto), semplicemente
      // 'rilasciaClaim' a fine sessione sarà un po' più "generoso" quella
      // volta sola.
      //
      // RISOLTO (Problema #1, parte UPDATE): prima scriveva direttamente su
      // 'carte' appoggiandosi alla policy larga "aggiornamento condiviso per
      // controllo prezzi gruppo". Ora passa dalla RPC dedicata
      // tagga_dispositivo_claim_gruppo (SECURITY DEFINER) — stesso identico
      // comportamento (stesso filtro claimed_by=chi chiama, stesso batch su
      // tutto il lotto in un colpo solo), solo senza più bisogno della
      // policy larga.
      if (righeReclamate.length > 0 && payload.nomeDispositivo) {
        const idsReclamati = righeReclamate.map((r) => r.id);
        try {
          await supabaseClient.rpc('tagga_dispositivo_claim_gruppo', {
            p_ids: idsReclamati,
            p_dispositivo: payload.nomeDispositivo,
          });
        } catch (_) {
          // Silenzioso di proposito — vedi commento sopra: le carte restano
          // comunque prenotate (claimed_by), solo senza il tag dispositivo.
        }
      }

      return { ok: true, carte: righeReclamate.map(_supabaseToRigaLeggi) };
    }

    case 'rilasciaClaim': {
      // Chiamata a fine sessione (completata o interrotta): libera le
      // prenotazioni ancora attive fatte da QUESTO dispositivo — non tutte
      // quelle dell'utente. FIX (vedi commento sopra in 'leggi'): prima
      // filtrava solo su claimed_by=userId, quindi con due PC sullo stesso
      // account il primo che finiva liberava anche le carte che l'altro
      // stava ancora controllando in quel momento. Se per qualche motivo la
      // colonna 'dispositivo' non fosse valorizzata su una riga (vecchia
      // sessione prima di questo fix, o scrittura extra fallita sopra), il
      // secondo filtro .eq('dispositivo', ...) la escluderebbe per errore —
      // per questo il rilascio "di sicurezza" resta anche quello per solo
      // userId, ma SOLO se non è stato possibile identificare il dispositivo.
      //
      // RISOLTO (Problema #1, parte UPDATE): prima scriveva direttamente su
      // 'carte' appoggiandosi alla policy larga. Ora passa dalla RPC
      // rilascia_claim_controllo_prezzi (SECURITY DEFINER) — stesso identico
      // filtro (claimed_by=chi chiama, + dispositivo se noto).
      const { error } = await supabaseClient.rpc('rilascia_claim_controllo_prezzi', {
        p_dispositivo: payload.nomeDispositivo || null,
      });
      if (error) return { ok: false, errore: error.message };
      return { ok: true };
    }

    case 'leggiAnteprima': {
      const q = supabaseClient.from('carte').select('*').eq('owner_id', userId).order('created_at');
      const { data, error } = await _selectTuttePagine(q);
      if (error) return { ok: false, errore: error.message };
      return { ok: true, righe: (data || []).map((r, idx) => ({ rigaSheet: idx + 4, celle: _supabaseToCelleAnteprima(r), _id: r.id })) };
    }

    case 'elencaLocation': {
      const { data, error } = await supabaseClient.from('carte').select('location').eq('owner_id', userId).eq('stato', 'collezione').not('location', 'is', null);
      if (error) return { ok: false, errore: error.message };
      const set = new Set((data || []).map(r => r.location).filter(Boolean));
      return { ok: true, location: Array.from(set).sort() };
    }

    // ── AGGIORNAMENTO PREZZO / URL (usate da "Aggiorna prezzi") ────────────
    case 'aggiornaPrezzoRiga': {
      // FIX: l'estensione recuperava già l'immagine durante ogni controllo
      // prezzi ma non la scriveva mai — le carte aggiunte prima di avere la
      // colonna 'immagine' restavano senza miniatura per sempre, anche
      // ricontrollando il prezzo cento volte. Ora, se la pagina ne ha
      // trovata una, la registriamo qui — le miniature si popolano da sole
      // col tempo, man mano che ricontrolli i prezzi.
      //
      // FIX (loop infinito sulle stesse 2-3 carte): 'ultimo_controllo'
      // mancava del tutto da questo aggiornamento — la carta restava per
      // sempre "mai controllata" agli occhi dell'ordinamento (ultimo_controllo
      // ASC NULLS FIRST in 'leggi'), quindi ogni nuovo lotto ripescava le
      // STESSE carte all'infinito invece di avanzare verso le altre.
      //
      // FIX (aggiornamento silenziosamente ignorato quando si controllano
      // le carte di un altro membro): '.eq(owner_id, userId)' filtrava
      // sull'utente che sta ESEGUENDO, non sul proprietario reale della
      // carta — un dispositivo che aiuta il gruppo scriveva su righe che
      // non esistevano per lui (0 righe toccate, nessun errore). L'id
      // della riga (già specifico e univoco) basta da solo a individuarla
      // — la sicurezza reale è comunque garantita dalla regola RLS che
      // permette la scrittura solo su carte con stato='collezione'.
      //
      // RISOLTO (Problema #1, parte UPDATE): la RLS di cui sopra ("collezione
      // condivisa"/"aggiornamento condiviso") esponeva TUTTE le colonne di
      // TUTTI gli owner, non solo prezzo/ultimo_controllo/immagine. Ora passa
      // dalla RPC dedicata aggiorna_prezzo_controllo_gruppo (SECURITY
      // DEFINER) — stesso comportamento esatto (nessun controllo su chi ha
      // claimato la carta, scelta esplicita confermata da Claudio il
      // 18/08/2026 per non introdurre complessità/rischi non necessari nel
      // flusso reale), ma senza più bisogno della policy larga.
      const { error } = await supabaseClient.rpc('aggiorna_prezzo_controllo_gruppo', {
        p_id: payload.riga,
        p_prezzo: payload.prezzo,
        p_immagine: payload.immagine || null,
      });
      if (error) return { ok: false, errore: error.message };
      return { ok: true, scritti: 1 };
    }

    case 'aggiornaUrlRiga': {
      // RISOLTO (bug [9], stesso schema di aggiornaPrezzoRiga sopra): prima
      // '.eq(owner_id, userId)' filtrava sull'utente che ESEGUE l'azione,
      // non sul proprietario reale della carta — con "Aiuta il gruppo"
      // attivo su carte di un altro utente, 0 righe toccate, nessun errore
      // visibile. Ora passa dalla RPC dedicata aggiorna_url_controllo_gruppo
      // (SECURITY DEFINER, verificata su DB reale il 20/08/2026).
      const { error } = await supabaseClient.rpc('aggiorna_url_controllo_gruppo', {
        p_id: payload.riga,
        p_url: payload.url,
      });
      if (error) return { ok: false, errore: error.message };
      return { ok: true, scritti: 1 };
    }

    case 'aggiornaNotaRiga': {
      // RISOLTO (bug [9]): stesso fix di aggiornaUrlRiga sopra, stesso
      // giorno di verifica.
      const { error } = await supabaseClient.rpc('aggiorna_nota_controllo_gruppo', {
        p_id: payload.riga,
        p_nota: payload.nota,
      });
      if (error) return { ok: false, errore: error.message };
      return { ok: true, scritti: 1 };
    }

    case 'aggiornaLocationRiga': {
      const { error } = await supabaseClient.from('carte').update({ location: payload.location || null }).eq('id', payload.riga).eq('owner_id', userId);
      if (error) return { ok: false, errore: error.message };
      return { ok: true, scritti: 1 };
    }

    case 'segnaControllata': {
      // Aggiorna SOLO la data di ultimo controllo, senza toccare nessun
      // altro campo — chiamata ad ogni carta effettivamente controllata
      // durante "Aggiorna prezzi", scriva o no il prezzo (vedi soloVariazioni
      // in popup.js: il prezzo non sempre viene riscritto, ma la carta va
      // comunque considerata "vista" ai fini dell'ordinamento in 'leggi'.
      //
      // FIX (stesso bug di aggiornaPrezzoRiga qui sopra): '.eq(owner_id,
      // userId)' bloccava silenziosamente questo aggiornamento quando si
      // controllano le carte di un altro membro del gruppo — la carta
      // restava "mai controllata" e veniva ripescata all'infinito.
      //
      // RISOLTO (Problema #1, parte UPDATE): come sopra, ora passa dalla RPC
      // dedicata segna_controllata_gruppo (SECURITY DEFINER) invece di
      // appoggiarsi alla policy larga.
      const { error } = await supabaseClient.rpc('segna_controllata_gruppo', { p_id: payload.riga });
      if (error) return { ok: false, errore: error.message };
      return { ok: true };
    }

    // ── AGGIORNAMENTO PREZZO / QUANTITA' (usate da "Aggiungi carta") ───────
    case 'aggiornaPrezzo': {
      const aggiornamenti = {};
      if (payload.prezzo != null) aggiornamenti.prezzo = payload.prezzo;
      if (payload.nome)           aggiornamenti.nome = payload.nome;
      if (payload.codice)         aggiornamenti.codice = payload.codice;
      const { error } = await supabaseClient.from('carte').update(aggiornamenti).eq('id', payload.riga).eq('owner_id', userId);
      if (error) return { ok: false, errore: error.message };
      return { ok: true };
    }

    case 'aggiornaQty': {
      const { error } = await supabaseClient.from('carte').update({ qty: payload.qty }).eq('id', payload.riga).eq('owner_id', userId);
      if (error) return { ok: false, errore: error.message };
      return { ok: true, riga: payload.riga };
    }

    // ── RICERCA (usate per capire se una carta è già in collezione) ────────
    case 'cerca': {
      let q = supabaseClient.from('carte').select('*').eq('owner_id', userId).eq('stato', 'collezione');
      if (payload.codice)     q = q.eq('codice', _normalizzaCodice(payload.codice));
      if (payload.lingua)     q = q.eq('lingua', payload.lingua);
      if (payload.condizione) q = q.eq('condizione', payload.condizione);
      const { data, error } = await q;
      if (error) return { ok: false, errore: error.message };
      return { ok: true, trovate: (data || []).map(_supabaseToRigaTrovata) };
    }

    case 'cercaBulk': {
      const risultati = [];
      for (const req of payload.richieste) {
        const r = await chiamaSupabase('cerca', { codice: req.codice, lingua: req.lingua, condizione: req.condizione });
        risultati.push({ idx: req.idx, trovate: r.trovate || [] });
      }
      return { ok: true, risultati };
    }

    // ── LOCATION (tendina + gestione hub) ───────────────────────────────────
    case 'elencaLocationTab': {
      const { data, error } = await supabaseClient.from('location').select('nome').eq('owner_id', userId).order('nome');
      if (error) return { ok: false, errore: error.message };
      return { ok: true, location: (data || []).map(r => r.nome) };
    }

    case 'aggiungiLocationTab': {
      const { data: esistenti } = await supabaseClient.from('location').select('nome').eq('owner_id', userId).eq('nome', payload.nome);
      if (esistenti && esistenti.length > 0) return { ok: true, giaEsistente: true };
      const { error } = await supabaseClient.from('location').insert({ owner_id: userId, nome: payload.nome });
      if (error) return { ok: false, errore: error.message };
      return { ok: true, giaEsistente: false };
    }

    case 'rinominaLocationTab': {
      const { error: e1 } = await supabaseClient.from('location').update({ nome: payload.nuovoNome }).eq('owner_id', userId).eq('nome', payload.vecchioNome);
      if (e1) return { ok: false, errore: e1.message };
      const { data: righeAgg, error: e2 } = await supabaseClient.from('carte').update({ location: payload.nuovoNome }).eq('owner_id', userId).eq('location', payload.vecchioNome).select();
      if (e2) return { ok: false, errore: e2.message };
      return { ok: true, righeInventarioAggiornate: (righeAgg || []).length };
    }

    case 'eliminaLocationTab': {
      const { error: e1 } = await supabaseClient.from('location').delete().eq('owner_id', userId).eq('nome', payload.nome);
      if (e1) return { ok: false, errore: e1.message };
      const { data: righeAgg, error: e2 } = await supabaseClient.from('carte').update({ location: null }).eq('owner_id', userId).eq('location', payload.nome).select();
      if (e2) return { ok: false, errore: e2.message };
      return { ok: true, righeInventarioAggiornate: (righeAgg || []).length };
    }

    default:
      return { ok: false, errore: `Azione "${azione}" non ancora implementata nell'adapter Supabase.` };
  }
}

// ── HELPER DI CONVERSIONE ────────────────────────────────────────────────────
// Supabase (PostgREST) non restituisce più di 1000 righe per chiamata, anche
// se la collezione ne ha di più — senza questo helper, una collezione sopra
// le 1000 carte veniva letta solo a metà, senza nessun errore visibile.
// "query" deve essere una query Supabase COSTRUITA ma non ancora eseguita
// (cioè senza await/then chiamato sopra) — questa funzione la esegue a
// blocchi di 1000 con .range(), finché non trova un blocco più corto del
// massimo, segno che non ci sono altre righe.
async function _selectTuttePagine(query) {
  const PAGINA = 1000;
  let tutte = [];
  let da = 0;
  while (true) {
    const { data, error } = await query.range(da, da + PAGINA - 1);
    if (error) return { data: null, error };
    tutte = tutte.concat(data || []);
    if (!data || data.length < PAGINA) break;
    da += PAGINA;
  }
  return { data: tutte, error: null };
}

function _rigaDatiToSupabase(rigaDati, statoOverride) {
  return {
    nome:             rigaDati['B'] || null,
    codice:           rigaDati['C'] || null,
    location:         rigaDati['D'] || null,
    qty:              rigaDati['E'] || 1,
    lingua:           rigaDati['F'] || 'IT',
    condizione:       rigaDati['G'] || 'NM',
    url:              rigaDati['H'] || null,
    prezzo:           (rigaDati['I'] !== '' && rigaDati['I'] != null) ? rigaDati['I'] : null,
    prezzo_obiettivo: (rigaDati['J'] !== '' && rigaDati['J'] != null) ? rigaDati['J'] : null,
    note:             rigaDati['K'] || null,
    immagine:         rigaDati['L'] || null,
    stato:            statoOverride || 'collezione',
  };
}

// Analoga a _rigaDatiToSupabase ma per la tabella 'wishlist' separata.
// A differenza delle carte in collezione, qui la location è per ora sempre
// un valore unico fisso (vedi impostaModalitaInserimento sul sito) — il
// campo esiste comunque già in tabella, pronto per quando/se servissero
// location diverse anche per la wishlist.
function _rigaDatiToWishlist(rigaDati) {
  return {
    nome:             rigaDati['B'] || null,
    codice:           rigaDati['C'] || null,
    location:         rigaDati['D'] || null,
    qty:              rigaDati['E'] || 1,
    lingua:           rigaDati['F'] || 'IT',
    condizione:       rigaDati['G'] || 'NM',
    url:              rigaDati['H'] || null,
    prezzo:           (rigaDati['I'] !== '' && rigaDati['I'] != null) ? rigaDati['I'] : null,
    prezzo_obiettivo: (rigaDati['J'] !== '' && rigaDati['J'] != null) ? rigaDati['J'] : null,
    note:             rigaDati['K'] || null,
    immagine:         rigaDati['L'] || null,
  };
}

function _normalizzaCodice(codice) {
  return (codice || '').toString().trim().toUpperCase().replace(/[\s-]/g, '');
}

function _supabaseToRigaTrovata(r) {
  return { riga: r.id, nome: r.nome, codice: r.codice, location: r.location, qty: r.qty, lingua: r.lingua, condizione: r.condizione, url: r.url };
}

function _supabaseToRigaLeggi(r) {
  return {
    rigaSheet: r.id, urlBase: r.url, lingua: r.lingua, condizione: r.condizione,
    codice: r.codice, nome: r.nome, location: r.location, prezzoPrecedente: r.prezzo,
  };
}

function _supabaseToRigaWishlist(r) {
  return {
    riga: r.id, nome: r.nome, codice: r.codice, qty: r.qty, lingua: r.lingua,
    condizione: r.condizione, url: r.url, prezzo: r.prezzo, prezzoObiettivo: r.prezzo_obiettivo, note: r.note,
  };
}

function _supabaseToCelleAnteprima(r) {
  // Ordine equivalente alle colonne A..K del vecchio foglio (A vuota, come
  // legge davvero webapp_scrivi_prezzi.gs), per riusare renderTabella() in
  // stessa logica già collaudata altrove nell'estensione.
  // FIX: qty e prezzo arrivano da Supabase come NUMERI, non stringhe — il
  // resto del codice chiama .trim() su ogni cella assumendo sempre testo
  // (come faceva Google Sheets con getDisplayValues()). Senza questa
  // conversione esplicita, una carta con qty/prezzo diverso da 0 o vuoto
  // mandava in errore l'intera tabella.
  const s = (v) => (v === null || v === undefined) ? '' : String(v);
  return ['', s(r.nome), s(r.codice), s(r.location), s(r.qty), s(r.lingua), s(r.condizione), s(r.url), s(r.prezzo), '', s(r.note)];
}

async function testConnessioneSupabase() {
  const { data, error } = await supabaseClient.auth.getSession();
  console.log('[Supabase test] sessione attuale:', data, 'errore:', error);
}
