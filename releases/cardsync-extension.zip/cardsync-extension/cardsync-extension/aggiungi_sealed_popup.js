// ── LOGIN SUPABASE ────────────────────────────────────────────────────────────
assicuraLoginSupabase();

// ── COSTANTI ──────────────────────────────────────────────────────────────────
const COL = {
  NOME:       'B',
  CODICE:     'C',
  LOCATION:   'D',
  QTY:        'E',
  LINGUA:     'F', // FIX: mancava del tutto — la lingua veniva usata solo
                    // per filtrare l'URL ma non era mai scritta nel foglio.
  URL:        'H',
  IMMAGINE:   'L', // già recuperata dalla ricerca (background.js), prima mai salvata
};

// FIX (immagini mancanti/rotte sui Sealed): questo file scriveva
// direttamente il link grezzo di Cardmarket (bloccato dall'hotlink
// protection se aperto da un altro dominio), senza mai passare per la
// conversione/caricamento su Supabase Storage — stesso schema già usato
// per le carte normali. Fallback silenzioso sull'URL grezzo se qualcosa
// va storto, per non bloccare mai l'aggiunta per questo.
async function _convertiImmagine(urlGrezzo) {
  if (!urlGrezzo) return '';
  try {
    const risposta = await new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'CONVERTI_IMMAGINE', url: urlGrezzo }, (r) => resolve(r));
    });
    return risposta?.immagine || urlGrezzo;
  } catch (_) {
    return urlGrezzo;
  }
}

const CAMPI_STORAGE     = ['selectedTheme'];
const LISTA_TEMI        = ['purple', 'green', 'blue', 'contrast', 'dark', 'sakura', 'wine', 'autunno', 'estate', 'heartgold', 'soulsilver', 'steel', 'electric', 'grass', 'pokemon', 'team-rocket'];

// ── SISTEMA PROFILI — GUSCIO VUOTO ──────────────────────────────────────────
// Il vecchio sistema (registro profili su Google Apps Script) è stato
// rimosso con la migrazione a Supabase. La tendina resta come punto di
// aggancio per un futuro sistema profili basato su Supabase.
document.getElementById('selectProfilo').addEventListener('change', function() {
  setStatus('ℹ️ Il sistema profili è in aggiornamento — non ancora disponibile.', 'info');
});
// FIX: sostituito l'unico slider "Delay tra carte" (preset fissi) con due
// slider indipendenti min/max in secondi — stessa modifica di popup.js e
// aggiungi_carta_popup.js, stessa chiave di storage condivisa.
const DELAY_SEC_MIN = 1;
const DELAY_SEC_MAX = 60;
// Tabella usata SOLO per migrare il vecchio valore a indice (0–7) salvato
// da chi aggiorna l'estensione da una versione precedente.
const LEGACY_DELAY_RANGES_SEC = [[1,3],[3,7],[5,10],[8,15],[12,20],[20,30],[30,45],[45,60]];
// Valore predefinito per chi installa l'estensione da zero (nessun vecchio
// indice da migrare) — 10–20s è il compromesso più prudente per limitare il
// rischio di blocchi Cloudflare/rate limit fin dal primo utilizzo.
const DEFAULT_DELAY_MIN_SEC = 10;
const DEFAULT_DELAY_MAX_SEC = 20;
// Rallentamento adattivo Cloudflare: con un range continuo si aggiunge un
// margine fisso per gradino invece di spostarsi su un preset più lento.
const CF_ESCALATION_STEP_SEC = 3;
const CF_ESCALATION_MAX_LEVEL = 5;
const PAUSA_OGNI_LABELS = ['25', '50', '75', '100', 'Mai'];
const PAUSA_OGNI_VALUES = [25, 50, 75, 100, Infinity];
const BULK_MAX_RETRY    = 2;
// Ricontrollo prezzo mancante: stessa logica del popup carte — se un
// prodotto viene inserito senza prezzo si aspetta questo delay e si rilegge
// SOLO il prezzo dalla pagina prodotto già risolta.
const RICONTROLLO_LABELS  = ['Disattivato', '10s', '20s', '30s', '60s'];
const RICONTROLLO_SECONDI = [0, 10, 20, 30, 60];
// PAUSA_RATE_LIMIT_MS è già dichiarata in shared.js (caricato prima di questo
// script nella stessa pagina) — ridichiararla qui causa un SyntaxError che
// blocca l'intero script, impedendo la registrazione di ogni event listener.

// ── LINGUA ────────────────────────────────────────────────────────────────────
// Stessa mappa alias usata in aggiungi_carta_popup.js: sigle brevi, sigle lunghe,
// nomi completi in italiano e inglese → codice canonico usato da LINGUA_MAP_SHARED.
const LINGUA_ALIAS_MAP = {
  'IT':'IT','ITA':'IT','ITALIANO':'IT','ITALIAN':'IT',
  'EN':'EN','ENG':'EN','INGLESE':'EN','ENGLISH':'EN',
  'FR':'FR','FRA':'FR','FRANCESE':'FR','FRENCH':'FR',
  'DE':'DE','DEU':'DE','GER':'DE','TEDESCO':'DE','GERMAN':'DE','DEUTSCH':'DE',
  'ES':'ES','ESP':'ES','SPAGNOLO':'ES','SPANISH':'ES','ESPAÑOL':'ES',
  'PT':'PT','POR':'PT','PORTOGHESE':'PT','PORTUGUESE':'PT',
  'JA':'JA','JP':'JA','JAP':'JA','JPN':'JA','GIAPPONESE':'JA','JAPANESE':'JA',
  'KOR':'KOR','KO':'KOR','KR':'KOR','COREANO':'KOR','KOREAN':'KOR',
  'CHN':'CHN','ZH':'CHN','CN':'CHN','CHS':'CHN','CINESE':'CHN','CHINESE':'CHN','CINESE-S':'CHN','CHINESE-S':'CHN',
  'CHN-T':'CHN-T','ZHT':'CHN-T','TW':'CHN-T','CHT':'CHN-T','CINESE-T':'CHN-T','CHINESE-T':'CHN-T',
  'RU':'RU','RUS':'RU','RUSSO':'RU','RUSSIAN':'RU',
  'THAI':'THAI','TH':'THAI','TAILANDESE':'THAI',
  'IND':'IND','ID':'IND','INDONESIANO':'IND','INDONESIAN':'IND',
};

// ── URL RICERCA ───────────────────────────────────────────────────────────────
// Aggiunge il filtro lingua (&language=ID) alla ricerca prodotti, sulla stessa
// pagina di ricerca usata per i sealed. Default IT se non specificata.
function urlRicercaSealed(nome, lingua) {
  const query = nome.trim().replace(/\s+/g, '+');
  let url = `https://www.cardmarket.com/it/Pokemon/Products/Search?searchMode=v2&searchString=${query}`;
  const codiceLingua = (lingua || 'IT').toUpperCase().trim();
  const idLingua = LINGUA_MAP_SHARED[codiceLingua];
  if (idLingua) url += `&language=${idLingua}`;
  return url;
}

// ── TIMEOUT LEGGI_SEALED ─────────────────────────────────────────────────────
// FIX (bug "non rispetta l'attesa Cloudflare configurata"): il timeout del
// messaggio LEGGI_SEALED era hardcoded a 30000ms, del tutto scollegato dallo
// slider "Timeout Cloudflare" (sliderCfTimeout, condiviso col popup
// principale, default 3 min, fino a 10). Anche con background.js ancora
// perfettamente in attesa che l'utente risolva il blocco, questo popup si
// arrendeva sempre dopo soli 30 secondi — un tempo quasi mai sufficiente per
// risolvere davvero un challenge Cloudflare — segnando il prodotto come
// fallito molto prima dei minuti configurati. Stesso fix già applicato al
// flusso carte in aggiungi_carta_popup.js (_timeoutLetturaCarta).
function _timeoutLetturaSealed() {
  return new Promise(function(resolve) {
    chrome.storage.local.get(['sliderCfTimeout'], function(res) {
      var minuti = (typeof res.sliderCfTimeout === 'number' && res.sliderCfTimeout >= 1)
        ? res.sliderCfTimeout
        : 3; // default coerente con background.js
      resolve(minuti * 60 * 1000 + 20000); // + margine per rete/tab
    });
  });
}

// ── INVIO MESSAGGIO RESILIENTE AI RIAVVII DEL SERVICE WORKER ────────────────
// Stesso fix applicato in aggiungi_carta_popup.js (_inviaMessaggioConRetry):
// se il service worker viene terminato da Chrome durante un'attesa Cloudflare
// di alcuni minuti (normale in MV3 per attese così lunghe), il canale del
// messaggio si chiude subito con un errore tipo "The message port closed
// before a response was received." — molto prima che i minuti configurati
// siano trascorsi. Riconosce questo tipo di errore (connessione persa col
// SW, non un vero fallimento) e ritenta l'invio finché resta budget di tempo.
function _erroreConnessioneSW(msg) {
  if (!msg) return false;
  var m = msg.toLowerCase();
  return m.indexOf('message port closed') !== -1
      || m.indexOf('receiving end does not exist') !== -1
      || m.indexOf('context invalidated') !== -1
      || m.indexOf('could not establish connection') !== -1;
}

function _inviaMessaggioConRetry(messaggio, timeoutTotaleMs) {
  var scadenza = Date.now() + timeoutTotaleMs;
  return new Promise(function(resolve, reject) {
    function tenta() {
      var rimanente = scadenza - Date.now();
      if (rimanente <= 0) { reject(new Error('Timeout')); return; }
      var timeoutId = setTimeout(function() {
        reject(new Error('Timeout'));
      }, rimanente);
      chrome.runtime.sendMessage(messaggio, function(r) {
        clearTimeout(timeoutId);
        if (chrome.runtime.lastError) {
          if (_erroreConnessioneSW(chrome.runtime.lastError.message) && Date.now() < scadenza) {
            setTimeout(tenta, 1000);
            return;
          }
          reject(new Error(chrome.runtime.lastError.message));
          return;
        }
        resolve(r);
      });
    }
    tenta();
  });
}

// ── WATCHDOG HEARTBEAT (fix "resta bloccato su un prodotto finché non
// ricarico la pagina") ───────────────────────────────────────────────────
// Stesso fix applicato in aggiungi_carta_popup.js: _inviaMessaggioConRetry
// sopra riconosce solo l'errore "connessione persa" che Chrome a volte
// genera quando il service worker viene terminato a metà di un'attesa
// lunga — ma non sempre lo genera. Se il SW muore mentre background.js sta
// ancora pollando una pagina Cardmarket o aspettando la risoluzione di un
// challenge Cloudflare, la Promise in attesa nel popup non si risolve mai:
// resta bloccato fino al proprio timeout interno (fino a 10 minuti).
//
// Ogni richiesta lunga porta ora un requestId univoco; il background
// aggiorna un heartbeat a ogni ciclo di polling (vedi _richiesteAttive in
// background.js). Il popup, in parallelo, manda un ping leggero
// (PING_RICHIESTA) ogni pochi secondi: se per 3 controlli consecutivi il
// SW risponde "richiesta non trovata" (riavviato, stato perso) o non
// risponde affatto, il popup abbandona l'attesa e considera il prodotto
// fallito invece di restare bloccato — la sessione bulk prosegue da sola,
// senza bisogno di ricaricare la pagina.
function _nuovoRequestId() {
  return 'r' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

function _pingRichiesta(requestId) {
  return new Promise(function(resolve) {
    var timeoutId = setTimeout(function() { resolve(null); }, 5000);
    try {
      chrome.runtime.sendMessage({ type: 'PING_RICHIESTA', requestId: requestId }, function(r) {
        clearTimeout(timeoutId);
        if (chrome.runtime.lastError) { resolve(null); return; }
        resolve(r || null);
      });
    } catch (_) {
      clearTimeout(timeoutId);
      resolve(null);
    }
  });
}

function _inviaMessaggioConWatchdog(messaggio, timeoutTotaleMs) {
  var requestId = _nuovoRequestId();
  var messaggioConId = Object.assign({}, messaggio, { requestId: requestId });

  var risolta = false;
  var mancatiConsecutivi = 0;
  var heartbeatTimer = null;

  var promiseMessaggio = _inviaMessaggioConRetry(messaggioConId, timeoutTotaleMs)
    .then(function(r) { return { orfano: false, risposta: r }; })
    .catch(function(e) { return { orfano: false, errore: e }; })
    .finally(function() { risolta = true; if (heartbeatTimer) clearInterval(heartbeatTimer); });

  var promiseWatchdog = new Promise(function(resolve) {
    heartbeatTimer = setInterval(async function() {
      if (risolta) return;
      var esito = await _pingRichiesta(requestId);
      if (risolta) return;
      if (esito && esito.attiva) {
        mancatiConsecutivi = 0;
        return;
      }
      mancatiConsecutivi++;
      if (mancatiConsecutivi >= 3) {
        if (heartbeatTimer) clearInterval(heartbeatTimer);
        resolve({ orfano: true });
      }
    }, 8000);
  });

  return Promise.race([promiseMessaggio, promiseWatchdog]).then(function(esito) {
    if (heartbeatTimer) clearInterval(heartbeatTimer);
    if (esito.orfano) {
      var err = new Error('service worker riavviato durante l\'attesa — prodotto saltato');
      err.orfano = true;
      throw err;
    }
    if (esito.errore) throw esito.errore;
    return esito.risposta;
  });
}

// ── UTILITY ───────────────────────────────────────────────────────────────────
function formattaDataOra(ts) {
  if (!ts) return null;
  const d   = new Date(ts);
  const pad = n => String(n).padStart(2, '0');
  return `${pad(d.getDate())}/${pad(d.getMonth()+1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

// FIX: rimossa _immagineToBase64() — mandava 'IMMAGINE_TO_BASE64' a
// background.js, mai gestito lì, quindi restituiva sempre l'URL grezzo
// comunque. Ora si usa sempre l'URL grezzo direttamente, coerente col
// resto dell'estensione e col proxy images.weserv.nl già usato da
// sidebar.html.

// ── TEMI ──────────────────────────────────────────────────────────────────────
function applicaTema(nome) {
  LISTA_TEMI.forEach(t => document.body.classList.remove(`theme-${t}`));
  if (nome !== 'purple') document.body.classList.add(`theme-${nome}`);
  document.body.classList.toggle('tema-attivo', nome !== 'purple');
}

// ── STATUS / LOG ──────────────────────────────────────────────────────────────
function setStatus(msg, tipo) {
  const el = document.getElementById('status');
  el.textContent = msg;
  el.className   = msg ? `visible ${tipo || ''}`.trim() : '';
}

let logCount   = 0;
let logEntries = [];

function aggiungiLog(msg, tipo) {
  tipo = tipo || 'ok';
  logCount++;
  logEntries.push({ n: logCount, msg, tipo });
  document.getElementById('logBadge').textContent = logCount;
  const empty = document.querySelector('.log-empty');
  if (empty) empty.remove();
  const entry  = document.createElement('div');
  entry.className = 'log-entry';
  const rigaEl = document.createElement('span');
  rigaEl.className   = 'log-row';
  rigaEl.textContent = '#' + logCount;
  const msgEl = document.createElement('span');
  msgEl.className   = 'log-msg ' + tipo;
  msgEl.textContent = msg;
  entry.appendChild(rigaEl);
  entry.appendChild(msgEl);
  const body = document.getElementById('logBody');
  body.insertBefore(entry, body.firstChild);
  body.classList.add('visible');
  document.getElementById('logHeader').classList.add('open');
}

document.getElementById('logHeader').addEventListener('click', function() {
  document.getElementById('logBody').classList.toggle('visible');
  document.getElementById('logHeader').classList.toggle('open');
});

document.getElementById('logCopy').addEventListener('click', function(e) {
  e.stopPropagation();
  if (logEntries.length === 0) return;
  var testo = logEntries.slice().reverse().map(function(e) { return '#' + e.n + '\t' + e.msg; }).join('\n');
  navigator.clipboard.writeText(testo).then(function() {
    var btn = document.getElementById('logCopy');
    btn.textContent = '✅';
    setTimeout(function() { btn.textContent = '📋'; }, 1500);
  });
});

document.getElementById('logCsv').addEventListener('click', function(e) {
  e.stopPropagation();
  if (logEntries.length === 0) return;
  var righe = ['#,Messaggio,Tipo'];
  logEntries.slice().reverse().forEach(function(e) {
    var msg  = '"' + (e.msg  || '').replace(/"/g, '""') + '"';
    var tipo = '"' + (e.tipo || '').replace(/"/g, '""') + '"';
    righe.push(e.n + ',' + msg + ',' + tipo);
  });
  var blob = new Blob([righe.join('\n')], { type: 'text/csv;charset=utf-8;' });
  var url  = URL.createObjectURL(blob);
  var a    = document.createElement('a');
  a.href     = url;
  a.download = 'cardsync_sealed_' + new Date().toISOString().slice(0, 10) + '.csv';
  a.click();
  URL.revokeObjectURL(url);
});

document.getElementById('logClear').addEventListener('click', function(e) {
  e.stopPropagation();
  logEntries = [];
  logCount   = 0;
  var body = document.getElementById('logBody');
  body.innerHTML = '<div class="log-empty">Nessun prodotto aggiunto ancora.</div>';
  document.getElementById('logBadge').textContent = '0';
});

// ── PARSER INPUT ──────────────────────────────────────────────────────────────
// Formato: nome prodotto, opzionalmente con quantità in fondo.
// Es: "Scarlet & Violet Booster Box" oppure "Twilight Masquerade ETB 2"
//
// Sintassi quantità:
//   1. Esplicita e prioritaria: "xN" in fondo, es. "... Series 2 x3" → qty 3.
//      Non ambigua: separa sempre la quantità dal nome, qualunque esso sia.
//   2. Implicita (compatibilità con l'uso storico): un numero nudo in fondo
//      viene trattato come quantità SOLO SE non è preceduto da una parola che
//      fa tipicamente parte del nome ufficiale di un prodotto sealed (es.
//      "Series 2", "Volume 3", "Set 1"). In quel caso il numero resta nel nome
//      e la quantità di default è 1 — altrimenti prodotti come "First Partner
//      Illustration Collection Series 2" verrebbero cercati senza il "2" e
//      Cardmarket non li troverebbe mai.
var QTY_BLACKLIST_PRECEDENTE = new Set([
  'SERIES', 'VOL', 'VOLUME', 'SET', 'PART', 'WAVE', 'EDITION', 'GEN', 'GENERATION', 'BOX',
]);

function parsaSealedRiga(riga) {
  var tokens = riga.trim().split(/\s+/);
  if (!tokens.length) return null;
  var qty = 1;
  var lingua = 'IT'; // default: sealed italiano

  // ── Estrazione lingua ──
  // Cerca in qualunque posizione della riga un token che corrisponde a un
  // alias lingua conosciuto (es. "EN", "JAP", "Inglese"...) e lo rimuove dal
  // nome. Se non trovato, resta il default IT. Stesso comportamento del
  // parser bulk carte in aggiungi_carta_popup.js.
  var tokensSenzaLingua = [];
  for (var ti = 0; ti < tokens.length; ti++) {
    var upTok = tokens[ti].toUpperCase();
    var linguaTrovata = LINGUA_ALIAS_MAP[upTok];
    if (linguaTrovata) { lingua = linguaTrovata; }
    else { tokensSenzaLingua.push(tokens[ti]); }
  }
  tokens = tokensSenzaLingua;
  if (!tokens.length) return null;

  var ultimo = tokens[tokens.length - 1];

  // 1. Sintassi esplicita "xN" — vince sempre, nessuna ambiguità.
  var matchX = /^x(\d+)$/i.exec(ultimo);
  if (matchX) {
    qty = parseInt(matchX[1], 10) || 1;
    tokens.pop();
  }
  // 2. Numero nudo in fondo — solo se non preceduto da una parola "da nome prodotto".
  else if (/^\d+$/.test(ultimo)) {
    var precedente = (tokens[tokens.length - 2] || '').toUpperCase().replace(/[^A-Z]/g, '');
    if (!QTY_BLACKLIST_PRECEDENTE.has(precedente)) {
      qty = parseInt(tokens.pop(), 10) || 1;
    }
  }

  var nome = tokens.join(' ').trim();
  if (!nome) return null;
  return { nome: nome, qty: qty, lingua: lingua };
}

// ── PROGRESS BAR ──────────────────────────────────────────────────────────────
var progressEl = document.getElementById('bulkProgress');
var bpFill     = document.getElementById('bpFill');
var bpCount    = document.getElementById('bpCount');
var bpCarta    = document.getElementById('bpCarta');
var bpStima    = document.getElementById('bpStima');
var bpTimer    = document.getElementById('bpTimer');
var _bpInizio  = null;
var _bpTimerInterval = null;
// FIX (bug "countdown che sfarfalla"): _aggiornaBp() e _attendiConCountdown()
// scrivevano entrambe, con due setInterval indipendenti e frequenze diverse
// (1000ms vs 500ms), sullo STESSO elemento bpStima — durante l'attesa tra un
// prodotto e il successivo (o durante una pausa anti-quota/rate-limit) i due
// timer si sovrascrivevano a vicenda più volte al secondo, facendo
// sfarfallare il testo tra "~M:SS rimanenti" e "Prossimo tra Ns…". Questo
// flag fa sì che, mentre un countdown esplicito è attivo, l'interval "di
// base" di _aggiornaBp smetta di contendersi bpStima — riprende a scriverci
// non appena il countdown finisce.
var _countdownAttivo = false;

function _aggiornaBp(i, tot, nome, pausa) {
  if (!progressEl) return;
  progressEl.classList.add('visible');
  var pct = tot > 0 ? Math.round((i / tot) * 100) : 0;
  if (bpFill)  bpFill.style.width  = pct + '%';
  if (bpCount) bpCount.textContent = i + ' / ' + tot;
  if (bpCarta) bpCarta.textContent = nome || '—';
  if (i === 0) { _bpInizio = Date.now(); if (_bpTimerInterval) clearInterval(_bpTimerInterval); }
  if (_bpTimerInterval) clearInterval(_bpTimerInterval);
  _bpTimerInterval = setInterval(function() {
    if (!bpTimer) return;
    var sec = Math.floor((Date.now() - (_bpInizio || Date.now())) / 1000);
    var m = Math.floor(sec / 60), s = sec % 60;
    bpTimer.textContent = m + ':' + String(s).padStart(2, '0');
    if (i > 0 && tot > 0 && !_countdownAttivo) {
      var rimanenti = tot - i;
      var msSec = (Date.now() - _bpInizio) / i;
      var rimSec = Math.round((rimanenti * msSec) / 1000);
      var rm = Math.floor(rimSec / 60), rs = rimSec % 60;
      if (bpStima) bpStima.textContent = pausa ? 'in pausa…' : '~' + rm + ':' + String(rs).padStart(2,'0') + ' rimanenti';
    }
  }, 1000);
}

function _attendiConCountdown(ms, label) {
  return new Promise(function(resolve) {
    _countdownAttivo = true;
    var fine = Date.now() + ms;
    var tick = setInterval(function() {
      // FIX (bug "Ferma non interrompe le attese lunghe"): senza questo
      // controllo il countdown ignorava completamente bulkStopRequested e
      // aspettava sempre l'intera durata — nel caso peggiore (pausa
      // rate-limit Error 1015) fino a 30 minuti anche dopo aver premuto
      // "Ferma". Vedi lo stesso controllo già presente nella pagina Carte.
      if (bulkStopRequested) {
        clearInterval(tick);
        _countdownAttivo = false;
        resolve();
        return;
      }
      var rimasto = Math.max(0, fine - Date.now());
      var s = Math.ceil(rimasto / 1000);
      if (bpStima) bpStima.textContent = label + ' ' + s + 's…';
      if (rimasto <= 0) {
        clearInterval(tick);
        _countdownAttivo = false;
        resolve();
      }
    }, 500);
  });
}

async function _attendiDelay(i, offsetLog, totalePiano) {
  // FIX: mancava il controllo di fine lista — a differenza del popup carte
  // (aggiungi_carta_popup.js), questa funzione aspettava SEMPRE, anche dopo
  // l'ultimo prodotto della sessione bulk, sprecando fino a 30s (pausa
  // anti-quota) senza alcun beneficio: non c'è nessuna richiesta successiva
  // da distanziare.
  // Nota: _attendiDelay è dichiarata FUORI da avviaSessioneBulk, quindi non
  // ha accesso per closure a pianoEffettivo (var locale a quella funzione)
  // — la lunghezza va passata esplicitamente come parametro.
  if (i >= totalePiano - 1 || bulkStopRequested) return;
  var saved = await new Promise(function(r) { chrome.storage.local.get(
    ['sliderDelay', 'sliderDelayMinSec', 'sliderDelayMaxSec', 'sliderPausaOgni'], r); });
  var pausaOgniIdx = saved.sliderPausaOgni != null ? saved.sliderPausaOgni : 1;
  var pausaOgniN   = PAUSA_OGNI_VALUES[pausaOgniIdx] != null ? PAUSA_OGNI_VALUES[pausaOgniIdx] : 50;
  // ── Aggiorna il livello di escalation prima di calcolare il delay ──
  // Un nuovo blocco Cloudflare segnalato da background.js alza il livello
  // di un gradino (fino a CF_ESCALATION_MAX_LEVEL); altrimenti, ogni
  // prodotto processato senza blocchi lo abbassa di un gradino, così il
  // ritmo torna gradualmente a quello scelto dall'utente invece di restare
  // rallentato per sempre dopo un solo hit.
  if (_cfHitPendente) {
    _cfEscalationLevel = Math.min(_cfEscalationLevel + 1, CF_ESCALATION_MAX_LEVEL);
    _cfHitPendente = false;
    aggiungiLog('⚠️ Cloudflare rilevato — rallento temporaneamente il ritmo tra i prodotti', '');
  } else if (_cfEscalationLevel > 0) {
    _cfEscalationLevel--;
  }
  // FIX (bug "pausa anti-quota disallineata dopo una ripresa"): i è
  // l'indice nel piano GIÀ TAGLIATO (pianoEffettivo), che a ogni ripresa
  // riparte da 0 — usare (i+1) qui significa "ogni N carte da quando ho
  // ripreso", non "ogni N carte in totale" come atteso. offsetLog+i è la
  // posizione ASSOLUTA nel piano originale (stesso valore già usato per
  // salvare bulkSessione e per i numeri mostrati nel log).
  var posizioneAssoluta = (offsetLog || 0) + i;
  if ((posizioneAssoluta + 1) % pausaOgniN === 0) {
    await _attendiConCountdown(30000, 'Pausa anti-quota —');
  } else {
    // FIX: sostituito l'unico slider a preset con due valori indipendenti
    // (min/max in secondi) — vedi stessa modifica in popup.js. Distingue
    // chi aveva già un vecchio indice salvato (migrazione al range
    // equivalente) da chi installa da zero (valore predefinito prudente).
    var dMinSec = saved.sliderDelayMinSec;
    var dMaxSec = saved.sliderDelayMaxSec;
    if (dMinSec == null || dMaxSec == null) {
      if (typeof saved.sliderDelay === 'number' && LEGACY_DELAY_RANGES_SEC[saved.sliderDelay]) {
        var legacy = LEGACY_DELAY_RANGES_SEC[saved.sliderDelay];
        dMinSec = legacy[0];
        dMaxSec = legacy[1];
      } else {
        dMinSec = DEFAULT_DELAY_MIN_SEC;
        dMaxSec = DEFAULT_DELAY_MAX_SEC;
      }
    }
    var range = [dMinSec * 1000, Math.max(dMaxSec, dMinSec) * 1000];
    // FIX (rate limit più frequente col riuso della worker tab): stesso
    // motivo del popup carte — questo flusso riusa già un'unica tab per
    // tutta la sessione, quindi non c'è più il ritardo "nascosto" che
    // l'apertura/chiusura di una tab per ogni prodotto introduceva
    // naturalmente oltre al delay dello slider. Margine fisso per
    // riportare il ritmo reale vicino a quello storico.
    var MARGINE_RIUSO_TAB_MS = 1200;
    // Rallentamento adattivo Cloudflare: margine fisso per gradino invece
    // di spostarsi su un preset più lento.
    var margineCfMs = _cfEscalationLevel * CF_ESCALATION_STEP_SEC * 1000;
    var delayMs = range[0] + Math.floor(Math.random() * (range[1] - range[0])) + MARGINE_RIUSO_TAB_MS + margineCfMs;
    await _attendiConCountdown(delayMs, _cfEscalationLevel > 0 ? 'Prossimo tra (rallentato)' : 'Prossimo tra');
  }
}

// Ricontrollo prezzo mancante: se il prodotto è stato inserito senza prezzo,
// aspetta il delay configurato e rilegge SOLO il prezzo dalla pagina
// prodotto già risolta (urlProdotto), senza rifare tutta la ricerca.
// FIX (bug "riga con nome vuoto, sovrascritta dal prodotto successivo"):
// stesso discorso del flusso carte in aggiungi_carta_popup.js — la tab
// aperta per il ricontrollo prezzo è comunque già sulla pagina prodotto:
// ne approfittiamo per rileggere ANCHE il nome a costo zero quando
// `nomeMancante` segnala che la riga era stata scritta senza nome.
async function _ricontrollaPrezzoMancanteSealed(riga, urlProdotto, etichetta, nomeMancante) {
  if (!riga || !urlProdotto) return;
  var saved = await new Promise(function(r) { chrome.storage.local.get(['sliderRicontrollo'], r); });
  var idx = saved.sliderRicontrollo != null ? saved.sliderRicontrollo : 2;
  var secondi = RICONTROLLO_SECONDI[idx] != null ? RICONTROLLO_SECONDI[idx] : 20;
  if (secondi <= 0 || bulkStopRequested) return;

  aggiungiLog(etichetta + ' — prezzo mancante, ricontrollo tra ' + secondi + 's…', '');
  await _attendiConCountdown(secondi * 1000, 'Ricontrollo prezzo tra');
  if (bulkStopRequested) return;

  try {
    var timeoutMsRicontrollo = await _timeoutLetturaSealed();
    var ris = await _inviaMessaggioConWatchdog({ type: 'LEGGI_SOLO_PREZZO_SEALED', urlProdotto: urlProdotto, usaWorkerTab: true }, timeoutMsRicontrollo);

    var aggiornamenti = {};
    if (ris && ris.prezzo != null) aggiornamenti.prezzo = ris.prezzo;
    // FIX: colonna M (immagine) rimossa su richiesta — non si traccia più
    // nemmeno qui (era comunque già ignorata da background.js in
    // azione 'aggiornaPrezzo', che scrive solo prezzo/nome).
    if (nomeMancante && ris && ris.nome) aggiornamenti.nome = ris.nome;

    if (Object.keys(aggiornamenti).length > 0) {
      var esitoAgg = await new Promise(function(resolve, reject) {
        chrome.runtime.sendMessage({
          type: 'AGGIUNGI_CARTA',
          azione: 'aggiornaPrezzo', riga: riga,
          prezzo: aggiornamenti.prezzo,
          nome: aggiornamenti.nome || null,
        }, function(r) { if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message)); else resolve(r); });
      });
      if (esitoAgg && esitoAgg.ok) {
        var parti = [];
        if (aggiornamenti.prezzo != null) parti.push('prezzo ' + aggiornamenti.prezzo + '€');
        if (aggiornamenti.nome) parti.push('nome "' + aggiornamenti.nome + '"');
        aggiungiLog(etichetta + ' — ' + parti.join(' e ') + ' recuperat' + (parti.length > 1 ? 'i' : 'o') + ' al ricontrollo (R' + riga + ')', 'ok');
      } else {
        aggiungiLog(etichetta + ' — dati trovati ma scrittura fallita: ' + (esitoAgg && esitoAgg.errore || '?'), 'err');
      }
    } else {
      aggiungiLog(etichetta + ' — prezzo ancora non disponibile dopo il ricontrollo', 'err');
    }
  } catch (e) {
    aggiungiLog(etichetta + ' — errore nel ricontrollo prezzo: ' + e.message, 'err');
  }
}

// ── CODA CORREZIONE ───────────────────────────────────────────────────────────
var _codaCorrezione    = [];
var _codaCorrezioneTot = 0;

function _mostraProssimaCorrezione() {
  var cardCorrezione = document.getElementById('cardCorrezione');
  var pannello       = document.getElementById('pannelloCorrezione');
  if (_codaCorrezione.length === 0) {
    cardCorrezione.style.display = 'none';
    pannello.innerHTML = '';
    pannello.classList.remove('visible');
    _codaCorrezioneTot = 0;
    return;
  }
  cardCorrezione.style.display = 'flex';
  pannello.classList.add('visible');
  pannello.innerHTML = '';

  var item = _codaCorrezione[0];
  var nome = item.nome, qty = item.qty, lingua = item.lingua || 'IT';
  var numeroCorrente = _codaCorrezioneTot - _codaCorrezione.length + 1;

  var div = document.createElement('div');
  div.className = 'correzione-item';

  var header = document.createElement('div');
  header.innerHTML =
    '<div class="correzione-item-label">' + nome + '</div>' +
    '<div class="correzione-item-sub">qty ' + qty + ' · ' + lingua + ' · ' + numeroCorrente + ' di ' + _codaCorrezioneTot + '</div>';
  div.appendChild(header);

  var motivoEl = document.createElement('div');
  motivoEl.className = 'correzione-item-motivo';
  motivoEl.innerHTML = '⚠️ Prodotto non risolto automaticamente — apri la ricerca, trova il prodotto e incolla l\'URL qui sotto.';
  div.appendChild(motivoEl);

  var btnApri = document.createElement('button');
  btnApri.className = 'correzione-btn';
  btnApri.style.cssText = 'width:100%;margin-top:6px;';
  btnApri.textContent = '🔗 Apri ricerca Cardmarket';
  btnApri.addEventListener('click', function() {
    // FIX (troppe tab in sequenza → Cloudflare): riusa la worker tab della
    // sessione bulk invece di aprirne una nuova a ogni prodotto da correggere.
    chrome.runtime.sendMessage({ type: 'APRI_URL_WORKER_TAB', kind: 'sealed', url: urlRicercaSealed(nome, lingua) });
  });
  div.appendChild(btnApri);

  var urlRow = document.createElement('div');
  urlRow.className = 'correzione-url-row';
  urlRow.style.marginTop = '6px';
  var input = document.createElement('input');
  input.type = 'url';
  input.placeholder = 'https://www.cardmarket.com/it/Pokemon/Products/…';
  input.className = 'correzione-url-input';
  urlRow.appendChild(input);
  div.appendChild(urlRow);

  var azioniRow = document.createElement('div');
  azioniRow.className = 'correzione-url-row';
  azioniRow.style.marginTop = '6px';

  var btnAdd = document.createElement('button');
  btnAdd.className = 'correzione-btn';
  btnAdd.style.flex = '1';
  btnAdd.textContent = '➕ Aggiungi';

  var btnSalta = document.createElement('button');
  btnSalta.className = 'correzione-btn-salta';
  btnSalta.title = 'Ignora questo prodotto';
  btnSalta.textContent = '✕ Ignora';

  btnAdd.addEventListener('click', async function() {
    var urlManuale = input.value.trim();
    if (!urlManuale || !urlManuale.includes('/Products/')) {
      input.style.borderColor = 'red'; return;
    }
    input.style.borderColor = '';
    if (!(await verificaAccessoValido())) return; // account bannato/eliminato: overlay già mostrato da auth_ui.js
    btnAdd.disabled   = true;
    btnSalta.disabled = true;
    btnAdd.textContent = '⏳';
    try {
      var timeoutMsManuale = await _timeoutLetturaSealed();
      var risposta = await _inviaMessaggioConWatchdog(
        // FIX (troppe tab in sequenza → Cloudflare): riusa la worker tab
        // della sessione bulk anche per le correzioni manuali.
        { type: 'LEGGI_SEALED', urlNome: urlManuale.split('?')[0], lingua: lingua, usaWorkerTab: true },
        timeoutMsManuale
      );
      var rigaDati = {};
      rigaDati[COL.NOME]     = (risposta && risposta.nome) ? risposta.nome : nome;
      rigaDati[COL.CODICE]   = '';
      rigaDati[COL.LOCATION] = _leggiLocationCorrente();
      rigaDati[COL.QTY]      = qty;
      rigaDati[COL.LINGUA]   = lingua;
      rigaDati[COL.URL]      = urlManuale.split('?')[0];
      rigaDati['I']          = (risposta && risposta.prezzo != null) ? risposta.prezzo : '';
      rigaDati[COL.IMMAGINE] = await _convertiImmagine((risposta && risposta.immagine) || '');
      var data = await new Promise(function(resolve, reject) {
        chrome.runtime.sendMessage({ type: 'AGGIUNGI_CARTA', rigaDati: rigaDati, tipo: 'sealed' },
          function(r) { if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message)); else resolve(r); });
      });
      if (!data.ok) { aggiungiLog(nome + ' — errore: ' + (data.errore || '?'), 'err'); }
      else          { aggiungiLog('R' + data.riga + ' · ' + rigaDati[COL.NOME] + ' (manuale)', 'ok'); }
    } catch(e) {
      aggiungiLog(nome + ' — ' + e.message, 'err');
    }
    _codaCorrezione.shift();
    _mostraProssimaCorrezione();
  });

  btnSalta.addEventListener('click', function() {
    aggiungiLog(nome + ' — ignorato manualmente', 'err');
    _codaCorrezione.shift();
    _mostraProssimaCorrezione();
  });

  azioniRow.appendChild(btnAdd);
  azioniRow.appendChild(btnSalta);
  div.appendChild(azioniRow);
  pannello.appendChild(div);
}

// ── SESSIONE BULK ─────────────────────────────────────────────────────────────
var _bulkAttivo       = false;
var bulkStopRequested = false;

// ── BACKOFF ADATTIVO CLOUDFLARE ──────────────────────────────────────────────
// Stesso meccanismo di aggiungi_carta_popup.js: background.js (vedi
// _suonaEPortaInPrimoPiano) trasmette un evento leggero ogni volta che
// rileva davvero un challenge Cloudflare in questo flusso ('sealed').
// _cfEscalationLevel sale di un gradino a ogni blocco (fino al tetto dei
// range esistenti dello slider Delay) e scende di un gradino a ogni
// prodotto processato senza nuovi blocchi.
var _cfEscalationLevel = 0;
var _cfHitPendente = false;

chrome.runtime.onMessage.addListener(function(message) {
  if (message && message.type === 'CLOUDFLARE_HIT_BULK' && message.kind === 'sealed') {
    _cfHitPendente = true;
  }
});

async function avviaSessioneBulk(riprendi) {
  riprendi = riprendi || 0;

  var listaRaw = document.getElementById('bulkInput').value;
  var prodotti  = listaRaw.split('\n').map(function(r) { return r.trim(); }).filter(Boolean).map(parsaSealedRiga).filter(Boolean);
  if (prodotti.length === 0) { setStatus('⚠️ Nessun prodotto valido nella lista.', 'errore'); return; }

  // FIX (sessione si blocca se la tab va in background per ore, es. lasciata
  // aperta la notte): vedi commento esteso su avviaAudioKeepAlive() in
  // shared.js. Fermato più sotto, dove la sessione termina (_bulkAttivo = false).
  avviaAudioKeepAlive();

  if (!(await verificaAccessoValido())) {
    fermaAudioKeepAlive();
    return; // account bannato/eliminato: overlay già mostrato da auth_ui.js
  }

  await _registraLocationSeNuova();

  var pianoEffettivo = prodotti.slice(riprendi);
  var offsetLog      = riprendi;
  // FIX (bug "rate limit retry non azzerato tra sessioni"): dichiarato qui,
  // locale a ogni chiamata, invece che a livello di modulo — altrimenti
  // l'indice per posizione (i) veniva ereditato da una sessione bulk
  // precedente, facendo scattare "saltato dopo 3 rate limit" già al primo
  // nuovo Error 1015 di una sessione successiva. Vedi stesso pattern già
  // corretto in aggiungi_carta_popup.js.
  var _rateLimitRetries = {};

  _bulkAttivo       = true;
  bulkStopRequested = false;
  _cfEscalationLevel = 0;
  _cfHitPendente = false;

  var btnBulk  = document.getElementById('btnBulkAggiungi');
  var btnReset = document.getElementById('btnReset');
  btnBulk.textContent = '🛑 Ferma';
  btnReset.disabled   = true;

  function stopHandler() {
    bulkStopRequested = true;
    btnBulk.disabled = true;
    btnBulk.textContent = '⏱️ Arresto…';
    setStatus('⏳ Finisco il prodotto attuale e mi fermo…', 'info');
  }
  btnBulk.addEventListener('click', stopHandler);

  var ok = 0, err = 0;
  var daCorreggere = [];

  for (var i = 0; i < pianoEffettivo.length; i++) {
    if (bulkStopRequested) break;
    var item = pianoEffettivo[i];
    var nome = item.nome, qty = item.qty, lingua = item.lingua || 'IT';

    chrome.storage.local.set({ sealedSessione: { listaRaw: listaRaw, indiceFermo: offsetLog + i, totale: prodotti.length } });
    _aggiornaBp(offsetLog + i, prodotti.length, nome, false);
    setStatus('⏳ Processo ' + (offsetLog + i + 1) + '/' + prodotti.length + ': ' + nome + '…', 'info');

    try {
      var urlRic = urlRicercaSealed(nome, lingua);
      var timeoutMsRic = await _timeoutLetturaSealed();
      var risposta = await _inviaMessaggioConWatchdog(
        // FIX (troppe tab in sequenza → Cloudflare): usaWorkerTab dice al
        // background di riusare un'unica tab per tutta la sessione bulk
        // invece di aprirne e chiuderne una per ogni prodotto — vedi
        // _prontaWorkerTabId in background.js.
        { type: 'LEGGI_SEALED', urlNome: urlRic, lingua: lingua, usaWorkerTab: true },
        timeoutMsRic
      );

      if (risposta && risposta.rateLimited) {
        _rateLimitRetries[i] = (_rateLimitRetries[i] || 0) + 1;
        aggiungiLog(nome + ' — Error 1015 (rate limited) → pausa 30 min', 'err');
        setStatus('🚫 Error 1015: troppe richieste. Pausa di 30 minuti…', 'errore');
        progressEl.classList.add('visible');
        if (bpFill)  bpFill.style.width = '100%';
        if (bpCarta) bpCarta.textContent = '☕ Error 1015 — in pausa';
        if (bpStima) bpStima.textContent = 'pausa rate-limit';
        if (bpCount) bpCount.textContent = (offsetLog + i + 1) + ' / ' + prodotti.length;
        await _attendiConCountdown(PAUSA_RATE_LIMIT_MS, 'Riprende tra');
        if (bulkStopRequested) break;
        if (_rateLimitRetries[i] >= 3) {
          aggiungiLog(nome + ' — saltato dopo 3 rate limit consecutivi', 'err');
          daCorreggere.push({ nome: nome, qty: qty, lingua: lingua, tipo: 'fallita' });
          err++;
          await _attendiDelay(i, offsetLog, prodotti.length);
          continue;
        }
        i--;
        continue;
      }

      if (!risposta || !risposta.urlProdotto) {
        var motivoLog;
        if (risposta && risposta.disambiguation) { motivoLog = 'disambiguazione'; }
        else if (!risposta) { motivoLog = 'errore di rete / timeout'; }
        else { motivoLog = 'non trovato su Cardmarket'; }
        aggiungiLog(nome + ' — ' + motivoLog, 'err');
        var tipo = (risposta && risposta.disambiguation) ? 'disambiguation' : 'fallita';
        daCorreggere.push({ nome: nome, qty: qty, lingua: lingua, tipo: tipo });
        err++;
        await _attendiDelay(i, offsetLog, prodotti.length);
        continue;
      }

      var rigaDati = {};
      rigaDati[COL.NOME]     = risposta.nome || nome;
      rigaDati[COL.CODICE]   = '';
      rigaDati[COL.LOCATION] = _leggiLocationCorrente();
      rigaDati[COL.QTY]      = qty;
      rigaDati[COL.LINGUA]   = lingua;
      rigaDati[COL.URL]      = risposta.urlProdotto;
      rigaDati['I']          = risposta.prezzo != null ? risposta.prezzo : '';
      rigaDati[COL.IMMAGINE] = await _convertiImmagine(risposta.immagine || '');

      var data = await new Promise(function(resolve, reject) {
        chrome.runtime.sendMessage({ type: 'AGGIUNGI_CARTA', rigaDati: rigaDati, tipo: 'sealed' },
          function(r) { if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message)); else resolve(r); });
      });

      if (!data.ok) { aggiungiLog(nome + ' — errore: ' + (data.errore || '?'), 'err'); err++; }
      else {
        aggiungiLog('R' + data.riga + ' · ' + rigaDati[COL.NOME] + (lingua !== 'IT' ? ' · ' + lingua : ''), 'ok'); ok++;
        if (rigaDati['I'] === '' || rigaDati['I'] === null || rigaDati['I'] === undefined) {
          var nomeMancante = !rigaDati[COL.NOME];
          await _ricontrollaPrezzoMancanteSealed(data.riga, rigaDati[COL.URL], nome, nomeMancante);
        }
      }

    } catch(e) {
      aggiungiLog(nome + ' — ' + e.message, 'err'); err++;
    }

    await _attendiDelay(i, offsetLog, prodotti.length);
  }

  progressEl.classList.remove('visible');
  // FIX (troppe tab in sequenza → Cloudflare): chiude la worker tab riusata
  // per tutta la sessione bulk — non serve più tenerla aperta ora che il
  // ciclo è finito (o è stato fermato). Se l'utente riprende una sessione
  // interrotta, il background ne creerà una nuova al bisogno.
  chrome.runtime.sendMessage({ type: 'CHIUDI_WORKER_TAB', kind: 'sealed' });
  // FIX: _bpTimerInterval veniva ripulito solo all'inizio del prossimo
  // _aggiornaBp(), mai qui alla fine/interruzione della sessione — l'ultimo
  // intervallo restava attivo a girare ogni secondo indefinitamente finché
  // non si chiudeva la tab.
  if (_bpTimerInterval) { clearInterval(_bpTimerInterval); _bpTimerInterval = null; }
  if (bpFill)  bpFill.style.width = '0%';
  if (bpCount) bpCount.textContent = '0 / 0';
  if (bpCarta) bpCarta.textContent = '—';
  if (bpStima) bpStima.textContent = 'stima —';
  if (bpTimer) bpTimer.textContent = '—';
  // FIX (sessione si blocca se la tab va in background per ore): ferma
  // l'audio silenzioso avviato da avviaAudioKeepAlive() più sopra.
  fermaAudioKeepAlive();
  btnBulk.removeEventListener('click', stopHandler);
  _bulkAttivo         = false;
  btnBulk.disabled    = false;
  btnBulk.textContent = '📦 Aggiungi al foglio';
  btnReset.disabled   = false;

  if (bulkStopRequested) {
    setStatus('🛑 Interrotto. ' + ok + ' aggiunt' + (ok === 1 ? 'o' : 'i') + (err > 0 ? ', ' + err + ' errori' : '') + '. Riapri per riprendere dal prodotto ' + (offsetLog + ok + err + 1) + '.', 'info');
  }

  // ── PANNELLO CORREZIONE ───────────────────────────────────────────────────
  if (daCorreggere.length > 0) {
    daCorreggere.forEach(function(c) {
      _codaCorrezione.push({ nome: c.nome, qty: c.qty, lingua: c.lingua || 'IT' });
      _codaCorrezioneTot++;
    });
    _mostraProssimaCorrezione();
  }

  // ── LISTA FALLITI ─────────────────────────────────────────────────────────
  var carteFallite = daCorreggere.filter(function(c) { return c.tipo === 'fallita'; });
  var cardFallite  = document.getElementById('cardFallite');
  var areaFallite  = document.getElementById('areaFallite');
  var btnCopiaFallite = document.getElementById('btnCopiaFallite');
  if (carteFallite.length > 0 && cardFallite && areaFallite) {
    areaFallite.value = carteFallite.map(function(c) {
      var parti = [c.nome];
      if (c.lingua && c.lingua !== 'IT') parti.push(c.lingua);
      if (c.qty && c.qty > 1) parti.push(String(c.qty));
      return parti.join(' ');
    }).join('\n');
    cardFallite.style.display = 'flex';
    if (btnCopiaFallite) {
      btnCopiaFallite.onclick = function() {
        navigator.clipboard.writeText(areaFallite.value).then(function() {
          btnCopiaFallite.textContent = '✓ Copiato!';
          setTimeout(function() { btnCopiaFallite.textContent = '📋 Copia tutto'; }, 2000);
        });
      };
    }
  } else if (cardFallite) {
    cardFallite.style.display = 'none';
  }

  var tipoStatus = bulkStopRequested ? 'info' : (err === 0 ? 'ok' : (ok === 0 ? 'errore' : 'info'));
  if (!bulkStopRequested) {
    setStatus('✅ ' + ok + ' aggiunt' + (ok === 1 ? 'o' : 'i') + (err > 0 ? ' · ❌ ' + err + ' errori' : '') + '.', tipoStatus);
  }

  // FIX: prima sealedSessione veniva rimossa sempre a fine ciclo, anche dopo
  // uno stop manuale — il banner "Sessione interrotta" non compariva mai e i
  // prodotti non ancora controllati erano di fatto persi. Ora si cancella
  // solo se la sessione è arrivata in fondo senza interruzioni.
  if (!bulkStopRequested) chrome.storage.local.remove('sealedSessione');
  if (ok > 0 && !bulkStopRequested) {
    var ora = Date.now();
    chrome.storage.local.set({ sealedUltimoUtilizzo: { ts: ora, ok: ok } });
    document.getElementById('ultimaCarta').textContent =
      '✔ ' + formattaDataOra(ora) + ' · ' + ok + ' prodott' + (ok === 1 ? 'o aggiunto' : 'i aggiunti');
    document.getElementById('bulkInput').value = '';
  }
}

// ── VERIFICA LOGIN CARDMARKET ────────────────────────────────────────────────
// Il controllo "carrello cliccabile" (rigaCarrelloCliccabile in content.js/
// background.js) richiede di essere loggati su Cardmarket nella worker tab
// che legge i prezzi — senza login ogni riga viene scartata e ogni prodotto
// risulta senza prezzo. Verifica il login vero prima di ogni avvio,
// bloccando per davvero se risulta chiaramente non loggato.
async function _richiediConfermaLogin(onConferma) {
  setStatus('🔍 Verifico il login su Cardmarket...', 'info');
  var risposta;
  try {
    risposta = await new Promise(function(resolve, reject) {
      // FIX (troppe tab in sequenza → Cloudflare): kind:'sealed' fa sì che
      // background.js esegua questo controllo nella STESSA worker tab già
      // usata dalla sessione bulk imminente, invece di aprirne una a parte
      // solo per il login — vedi _verificaLoginSuWorkerTab in background.js.
      chrome.runtime.sendMessage({ type: 'VERIFICA_LOGIN_SILENZIOSA', kind: 'sealed' }, function(r) {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve(r);
      });
    });
  } catch (e) {
    setStatus('⚠️ Impossibile verificare il login (' + e.message + ') — procedo comunque.', 'info');
    onConferma();
    return;
  }

  if (risposta && risposta.loggato === false) {
    setStatus('🔒 Non risulti loggato su Cardmarket — ho aperto una tab per te: accedi e riprova.', 'errore');
    return; // blocca per davvero, non chiama onConferma()
  }
  if (!risposta || risposta.loggato === null) {
    setStatus('⚠️ Non sono riuscito a confermare il login — procedo comunque.', 'info');
  }
  onConferma();
}

document.getElementById('btnBulkAggiungi').addEventListener('click', function() {
  if (_bulkAttivo) return;
  _richiediConfermaLogin(function() { avviaSessioneBulk(0); });
});

// ── IMPOSTAZIONI ──────────────────────────────────────────────────────────────
function toggleSettingsPanel() {
  var panel = document.getElementById('settingsPanel');
  var btn   = document.getElementById('gearBtn');
  var open  = panel.classList.toggle('visible');
  btn.classList.toggle('open', open);
  btn.setAttribute('aria-expanded', String(open));
}

document.getElementById('gearBtn').addEventListener('click', toggleSettingsPanel);

// ── ⚙ INOLTRATO DALL'HUB (app.html) ──────────────────────────────────────────
// Quando questa pagina è dentro l'hub (vedi tab_detect.js/embedded-in-hub),
// il proprio header — e quindi questo stesso gearBtn — è nascosto: l'hub
// mostra un'unica icona ⚙ in cima e, al click, la inoltra qui via postMessage
// così il pannello che si apre resta sempre quello giusto per questa pagina.
window.addEventListener('message', function(e) {
  if (e.data && e.data.type === 'CARDSYNC_TOGGLE_SETTINGS') toggleSettingsPanel();
  // FIX: quando una location viene rinominata/eliminata dal popover 📍
  // dell'hub, questa pagina ricarica la propria datalist — altrimenti
  // resterebbe con l'elenco vecchio finché non si riapre/ricarica.
  if (e.data && e.data.type === 'CARDSYNC_REFRESH_LOCATION') _popolaDatalistLocation();
});

// FIX: sostituito l'unico slider "Delay tra carte" (preset fissi) con due
// slider indipendenti min/max in secondi — stessa modifica di popup.js e
// aggiungi_carta_popup.js, stessa chiave di storage condivisa.
function aggiornaLabelDelayMinMaxSealed() {
  var vMin = document.getElementById('sliderDelayMin').value;
  var vMax = document.getElementById('sliderDelayMax').value;
  document.getElementById('valDelayMin').textContent = vMin + 's';
  document.getElementById('valDelayMax').textContent = vMax + 's';
}

document.getElementById('sliderDelayMin').addEventListener('input', function(e) {
  var vMin = parseInt(e.target.value);
  var sliderMax = document.getElementById('sliderDelayMax');
  if (vMin > parseInt(sliderMax.value)) sliderMax.value = vMin;
  aggiornaLabelDelayMinMaxSealed();
  chrome.storage.local.set({
    sliderDelayMinSec: vMin,
    sliderDelayMaxSec: parseInt(sliderMax.value),
  });
});

document.getElementById('sliderDelayMax').addEventListener('input', function(e) {
  var vMax = parseInt(e.target.value);
  var sliderMin = document.getElementById('sliderDelayMin');
  if (vMax < parseInt(sliderMin.value)) sliderMin.value = vMax;
  aggiornaLabelDelayMinMaxSealed();
  chrome.storage.local.set({
    sliderDelayMinSec: parseInt(sliderMin.value),
    sliderDelayMaxSec: vMax,
  });
});

document.getElementById('sliderPausaOgni').addEventListener('input', function(e) {
  var v = parseInt(e.target.value);
  document.getElementById('valPausaOgni').textContent = PAUSA_OGNI_LABELS[v];
  chrome.storage.local.set({ sliderPausaOgni: v });
});

document.getElementById('sliderRicontrollo').addEventListener('input', function(e) {
  var v = parseInt(e.target.value);
  document.getElementById('valRicontrollo').textContent = RICONTROLLO_LABELS[v];
  chrome.storage.local.set({ sliderRicontrollo: v });
});

document.getElementById('avvisoSonoro').addEventListener('change', function(e) {
  chrome.storage.local.set({ avvisoSonoro: e.target.checked });
});

// ── LOCATION (condivisa con Carte e Wishlist) ────────────────────────────────
// Le location vivono nella scheda dedicata "LOCATION" (colonna B, valori da
// riga 2) — quella collegata alla validazione dati della tendina Location
// nell'Inventario. Il campo qui sotto legge quell'elenco (autocompletamento)
// e, se si scrive un valore nuovo mai visto, lo registra al volo in quella
// scheda all'avvio della sessione bulk (vedi _registraLocationSeNuova) —
// così da quel momento compare anche nella tendina nativa del foglio. Vale
// per tutti i prodotti della sessione bulk corrente, ed è condiviso in
// storage con le altre pagine "aggiungi".
var LOCATION_TAB_NAME = 'LOCATION';
var LOCATION_TAB_COL = 'B';
var LOCATION_TAB_RIGA_INIZIO = 2;
var _locationConosciute = [];

function _leggiLocationCorrente() {
  var el = document.getElementById('inputLocation');
  var val = el ? el.value.trim() : '';
  return val || '?';
}

var _inputLocationEl = document.getElementById('inputLocation');
if (_inputLocationEl) {
  _inputLocationEl.addEventListener('input', function(e) {
    chrome.storage.local.set({ bulkLocation: e.target.value });
  });
}

function _popolaDatalistLocation() {
  var datalist = document.getElementById('locationOptions');
  if (!datalist) return;
  chiamaSupabase('elencaLocationTab', {}).then(function(data) {
    if (!data.ok) return;
    _locationConosciute = data.location || [];
    datalist.innerHTML = '';
    _locationConosciute.forEach(function(loc) {
      var opt = document.createElement('option');
      opt.value = loc;
      datalist.appendChild(opt);
    });
  }).catch(function() {
    // Silenzioso: connessione non ancora configurata/raggiungibile — il
    // campo resta comunque utilizzabile in scrittura libera.
  });
}

// Se il valore scelto non è tra quelli già noti nella scheda LOCATION, lo
// registra lì al volo prima di usarlo per la sessione bulk.
function _registraLocationSeNuova() {
  var nome = _inputLocationEl ? _inputLocationEl.value.trim() : '';
  if (!nome || _locationConosciute.indexOf(nome) !== -1) return Promise.resolve();
  return chiamaSupabase('aggiungiLocationTab', { nome: nome }).then(function(data) {
    if (data.ok) {
      _locationConosciute.push(nome);
      window.parent.postMessage({ type: 'CARDSYNC_LOCATION_ADDED' }, '*');
    }
  }).catch(function() {
    // Silenzioso: se la registrazione fallisce, il prodotto viene comunque
    // scritto con questo valore in Location — solo la tendina nativa del
    // foglio non lo includerà finché non si riprova.
  });
}

// ── BOOT ──────────────────────────────────────────────────────────────────────
chrome.storage.local.get(CAMPI_STORAGE.concat(['sealedSessione', 'sealedUltimoUtilizzo',
  'sliderDelay', 'sliderDelayMinSec', 'sliderDelayMaxSec', 'sliderPausaOgni', 'avvisoSonoro', 'sliderRicontrollo', 'bulkLocation', 'cardsyncDarkMode']), function(saved) {
  applicaTema(saved.selectedTheme || 'purple');
  document.body.classList.toggle('modo-scuro', saved.cardsyncDarkMode === true);
  if (_inputLocationEl && saved.bulkLocation) _inputLocationEl.value = saved.bulkLocation;
  _popolaDatalistLocation();

  if (saved.sealedUltimoUtilizzo) {
    var ts = saved.sealedUltimoUtilizzo.ts, ok2 = saved.sealedUltimoUtilizzo.ok;
    document.getElementById('ultimaCarta').textContent =
      '🕐 ' + formattaDataOra(ts) + ' · ' + ok2 + ' prodott' + (ok2 === 1 ? 'o aggiunto' : 'i aggiunti');
  }

  // FIX: migrazione dal vecchio indice a preset (solo per chi lo aveva già
  // salvato) — altrimenti, per un'installazione nuova, usa il valore
  // predefinito prudente.
  var vDelayMin = saved.sliderDelayMinSec;
  var vDelayMax = saved.sliderDelayMaxSec;
  if (vDelayMin == null || vDelayMax == null) {
    if (typeof saved.sliderDelay === 'number' && LEGACY_DELAY_RANGES_SEC[saved.sliderDelay]) {
      var legacy = LEGACY_DELAY_RANGES_SEC[saved.sliderDelay];
      vDelayMin = legacy[0];
      vDelayMax = legacy[1];
    } else {
      vDelayMin = DEFAULT_DELAY_MIN_SEC;
      vDelayMax = DEFAULT_DELAY_MAX_SEC;
    }
    chrome.storage.local.set({ sliderDelayMinSec: vDelayMin, sliderDelayMaxSec: vDelayMax });
  }
  var vPausa = saved.sliderPausaOgni != null ? saved.sliderPausaOgni : 1;
  var vRicontrollo = saved.sliderRicontrollo != null ? saved.sliderRicontrollo : 2;
  document.getElementById('sliderDelayMin').value  = vDelayMin;
  document.getElementById('sliderDelayMax').value  = vDelayMax;
  document.getElementById('sliderPausaOgni').value = vPausa;
  document.getElementById('sliderRicontrollo').value = vRicontrollo;
  aggiornaLabelDelayMinMaxSealed();
  document.getElementById('valPausaOgni').textContent  = PAUSA_OGNI_LABELS[vPausa];
  document.getElementById('valRicontrollo').textContent = RICONTROLLO_LABELS[vRicontrollo];
  document.getElementById('avvisoSonoro').checked      = saved.avvisoSonoro !== false;

  if (saved.sealedSessione) {
    var listaRaw = saved.sealedSessione.listaRaw;
    var indiceFermo = saved.sealedSessione.indiceFermo;
    var totale = saved.sealedSessione.totale;
    var banner = document.getElementById('bulkRiprendiBanner');
    if (banner) {
      banner.style.display = '';
      banner.querySelector('.bulk-riprendi-info').textContent =
        'Sessione interrotta: ' + indiceFermo + '/' + totale + ' prodotti completati. Riprendi dal prodotto ' + (indiceFermo + 1) + '?';
      banner.querySelector('#btnRiprendi').addEventListener('click', function() {
        banner.style.display = 'none';
        document.getElementById('bulkInput').value = listaRaw;
        _richiediConfermaLogin(function() {
          setTimeout(function() { avviaSessioneBulk(indiceFermo); }, 100);
        });
      });
      banner.querySelector('#btnScartaSessione').addEventListener('click', function() {
        banner.style.display = 'none';
        chrome.storage.local.remove('sealedSessione');
      });
    }
  }
});

chrome.storage.onChanged.addListener(function(changes) {
  if (changes.selectedTheme) location.reload(); // FIX: refresh vero invece di un cambio 'a caldo' incompleto
  if (changes.cardsyncDarkMode) location.reload();
  if (changes.bulkLocation !== undefined && _inputLocationEl && document.activeElement !== _inputLocationEl) {
    _inputLocationEl.value = changes.bulkLocation.newValue || '';
  }
  if (changes.sliderDelayMinSec || changes.sliderDelayMaxSec) {
    if (changes.sliderDelayMinSec) document.getElementById('sliderDelayMin').value = changes.sliderDelayMinSec.newValue != null ? changes.sliderDelayMinSec.newValue : 3;
    if (changes.sliderDelayMaxSec) document.getElementById('sliderDelayMax').value = changes.sliderDelayMaxSec.newValue != null ? changes.sliderDelayMaxSec.newValue : 7;
    aggiornaLabelDelayMinMaxSealed();
  }
  if (changes.sliderPausaOgni) {
    var v2 = changes.sliderPausaOgni.newValue != null ? changes.sliderPausaOgni.newValue : 1;
    document.getElementById('sliderPausaOgni').value    = v2;
    document.getElementById('valPausaOgni').textContent = PAUSA_OGNI_LABELS[v2];
  }
  if (changes.sliderRicontrollo) {
    var v3 = changes.sliderRicontrollo.newValue != null ? changes.sliderRicontrollo.newValue : 2;
    document.getElementById('sliderRicontrollo').value    = v3;
    document.getElementById('valRicontrollo').textContent = RICONTROLLO_LABELS[v3];
  }
  if (changes.avvisoSonoro !== undefined) {
    document.getElementById('avvisoSonoro').checked = changes.avvisoSonoro.newValue !== false;
  }
});

// ── RESET ─────────────────────────────────────────────────────────────────────
// ── BUG REPORT ────────────────────────────────────────────────────────────────
// FIX: stesso fix applicato a popup.js / aggiungi_carta_popup.js — un link
// mailto: aperto direttamente può fallire se la pagina perde il focus nel
// momento del passaggio al client di posta. chrome.tabs.create() apre
// sempre una tab vera e stabile.
document.getElementById('bugReportLink').addEventListener('click', function(e) {
  e.preventDefault();
  chrome.tabs.create({ url: e.currentTarget.href });
});

// ── CHANGELOG ─────────────────────────────────────────────────────────────────
document.getElementById('changelogLink').addEventListener('click', function() {
  chrome.tabs.create({ url: chrome.runtime.getURL('changelog.html') });
});

document.getElementById('btnReset').addEventListener('click', function() {
  setStatus('', '');
  // FIX (troppe tab in sequenza → Cloudflare): se una sessione bulk aveva
  // lasciato la worker tab aperta (es. interrotta e poi scartata dal
  // reset), chiudila qui invece di lasciarla in giro indefinitamente.
  chrome.runtime.sendMessage({ type: 'CHIUDI_WORKER_TAB', kind: 'sealed' });
  var cardCorr = document.getElementById('cardCorrezione');
  if (cardCorr) { cardCorr.style.display = 'none'; var p = document.getElementById('pannelloCorrezione'); p.innerHTML = ''; p.classList.remove('visible'); }
  var cardFalliteReset = document.getElementById('cardFallite');
  if (cardFalliteReset) { cardFalliteReset.style.display = 'none'; var a = document.getElementById('areaFallite'); if (a) a.value = ''; }
  _codaCorrezione    = [];
  _codaCorrezioneTot = 0;
  var bulkProg = document.getElementById('bulkProgress');
  if (bulkProg) {
    bulkProg.classList.remove('visible');
    if (_bpTimerInterval) { clearInterval(_bpTimerInterval); _bpTimerInterval = null; }
    var _f = document.getElementById('bpFill');  if (_f) _f.style.width = '0%';
    var _c = document.getElementById('bpCount'); if (_c) _c.textContent = '0 / 0';
    var _n = document.getElementById('bpCarta'); if (_n) _n.textContent = '—';
    var _s = document.getElementById('bpStima'); if (_s) _s.textContent = 'stima —';
    var _t = document.getElementById('bpTimer'); if (_t) _t.textContent = '—';
  }
  document.getElementById('bulkInput').value = '';
  logEntries = [];
  logCount   = 0;
  var logBody = document.getElementById('logBody');
  if (logBody) { logBody.innerHTML = '<div class="log-empty">Nessun prodotto aggiunto ancora.</div>'; }
  document.getElementById('logBadge').textContent = '0';
  chrome.storage.local.remove('sealedSessione');
});

// ── EASTER EGG ────────────────────────────────────────────────────────────────
(function () {
  var clicks = 0;
  var timer = null;
  var footer = document.getElementById('footer-credit');
  if (!footer) return;
  footer.addEventListener('click', function() {
    clicks++;
    clearTimeout(timer);
    timer = setTimeout(function() { clicks = 0; }, 600);
    if (clicks >= 3) {
      clicks = 0;
      chrome.tabs.create({ url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', active: true });
    }
  });
})();

// ── AUTO-MAIUSCOLO ───────────────────────────────────────────────────────────
// Come nel popup carte: converte il testo in maiuscolo mentre si digita,
// preservando la posizione del cursore.
document.getElementById('bulkInput').addEventListener('input', function(e) {
  var el = e.target;
  var start = el.selectionStart;
  var end = el.selectionEnd;
  el.value = el.value.toUpperCase();
  el.setSelectionRange(start, end);
});