// Service worker dell'estensione
importScripts('shared.js'); // LINGUA_MAP_SHARED, COND_NUM_MAP_SHARED, costruisciUrlFiltrato
importScripts('supabase.bundle.js', 'supabase_adapter.js'); // chiamaSupabase — vedi handler AGGIUNGI_CARTA più sotto

// ── APERTURA APP ──────────────────────────────────────────────────────────────
// Non creiamo più preferiti automatici né apriamo tab da soli all'avvio di
// Chrome: l'apertura dell'app è ora decisa dal sito (pulsanti "Apri l'app" e
// "Apri sempre l'app all'apertura del sito da questo dispositivo", vedi
// index.html + auth_ui.js). Qui teniamo solo l'apertura al click sull'icona
// dell'estensione, dato che non esiste più il mini-popup (default_popup
// rimosso dal manifest): se una tab con l'app è già aperta la richiama in
// primo piano, altrimenti ne apre una nuova.
async function _apriOFocalizzaTabApp() {
  const url = chrome.runtime.getURL('app.html');
  const esistenti = await chrome.tabs.query({ url: url + '*' });
  if (esistenti && esistenti.length > 0) {
    const tab = esistenti[0];
    await chrome.tabs.update(tab.id, { active: true });
    await chrome.windows.update(tab.windowId, { focused: true });
  } else {
    await chrome.tabs.create({ url: url + '#prezzi' });
  }
}
chrome.action.onClicked.addListener(_apriOFocalizzaTabApp);

// "Mantieni acceso" (stesso concetto del sito): se disattivato, esce da
// solo quando il service worker viene sospeso — il segnale più vicino a
// "il browser si sta chiudendo" disponibile per un'estensione MV3 (non e'
// garantito al 100% per via di come Chrome gestisce i service worker, ma
// e' il meglio disponibile).
chrome.runtime.onSuspend.addListener(async () => {
  const { cardsyncMantieniAccessoEstensione } = await chrome.storage.local.get('cardsyncMantieniAccessoEstensione');
  if (cardsyncMantieniAccessoEstensione === false) {
    await supabaseClient.auth.signOut();
  }
});

// ── COMUNICAZIONE COL SITO (externally_connectable) ───────────────────────────
// Il sito, ad ogni apertura, chiede qui la versione installata per sapere
// se mostrare "sei aggiornato" o il popup di aggiornamento — vedi
// manifest.json → externally_connectable (solo il dominio del sito può
// mandare messaggi qui, nessun altro sito). Risponde SOLO con il numero di
// versione, nessun dato personale o della collezione.
// Un sito web normale NON può aprire da solo una pagina chrome-extension://
// (bloccato dal browser per sicurezza) — per questo il pulsante "Apri l'app"
// del sito manda un messaggio qui invece di provare ad aprirla direttamente.
// Lo stesso messaggio porta anche il token di sessione già ottenuto dal
// login sul sito: così l'estensione entra già autenticata con lo stesso
// account, senza chiedere un secondo login separato.
chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  if (message && message.type === 'CARDSYNC_GET_VERSION') {
    sendResponse({ versione: chrome.runtime.getManifest().version });
    return true;
  }
  if (message && message.type === 'CARDSYNC_GET_AIUTA_GRUPPO') {
    // Letta e scritta SOLO in chrome.storage.local — è una preferenza legata
    // a QUESTO dispositivo/installazione dell'estensione, non all'account
    // Supabase: due dispositivi diversi con lo stesso login possono avere
    // valori diversi, di proposito (es. il PC sempre acceso la tiene su, il
    // portatile no).
    chrome.storage.local.get('aiutaGruppo').then(({ aiutaGruppo }) => {
      sendResponse({ ok: true, aiutaGruppo: aiutaGruppo ?? false });
    }).catch((e) => sendResponse({ ok: false, errore: e.message }));
    return true;
  }
  if (message && message.type === 'CARDSYNC_SET_AIUTA_GRUPPO') {
    chrome.storage.local.set({ aiutaGruppo: !!message.valore }).then(() => {
      sendResponse({ ok: true, aiutaGruppo: !!message.valore });
    }).catch((e) => sendResponse({ ok: false, errore: e.message }));
    return true;
  }
  if (message && message.type === 'CARDSYNC_SET_TEMA') {
    // Come la parte "tema" di CARDSYNC_OPEN_APP, ma SENZA aprire/focalizzare
    // nessuna tab: qui il sito sta solo tenendo l'estensione allineata mentre
    // l'utente cambia tema, non chiedendo di aprire l'app. Le pagine
    // dell'estensione già aperte (se ce ne sono) si aggiornano da sole
    // tramite il loro chrome.storage.onChanged su 'selectedTheme'.
    const daScrivere = {};
    if (typeof message.tema === 'string') daScrivere.selectedTheme = message.tema;
    if (typeof message.temaScuro === 'boolean') daScrivere.cardsyncDarkMode = message.temaScuro;
    chrome.storage.local.set(daScrivere).then(() => {
      sendResponse({ ok: true });
    }).catch((e) => sendResponse({ ok: false, errore: e.message }));
    return true;
  }
  if (message && message.type === 'CARDSYNC_OPEN_APP') {
    (async () => {
      try {
        if (message.access_token && message.refresh_token) {
          await supabaseClient.auth.setSession({
            access_token: message.access_token,
            refresh_token: message.refresh_token,
          });
        }
        // Tema e tema scuro arrivano dal sito (stessa scelta già fatta lì) e
        // vengono scritti nello stesso storage che ogni pagina dell'estensione
        // già legge (selectedTheme, cardsyncDarkMode) — nessuna nuova UI per
        // sceglierli qui dentro, l'estensione si allinea e basta.
        const daScrivere = {};
        if (typeof message.tema === 'string') daScrivere.selectedTheme = message.tema;
        if (typeof message.temaScuro === 'boolean') daScrivere.cardsyncDarkMode = message.temaScuro;
        if (Object.keys(daScrivere).length > 0) await chrome.storage.local.set(daScrivere);

        await _apriOFocalizzaTabApp();
        sendResponse({ ok: true });
      } catch (e) {
        sendResponse({ ok: false, errore: e.message });
      }
    })();
    return true; // risposta asincrona
  }
  return true;
});

// ── FIX (immagini sempre 403 Forbidden) ──────────────────────────────────────
// Cardmarket controlla l'intestazione "Referer" delle richieste alle proprie
// immagini e rifiuta (403) qualunque richiesta che non arrivi da una loro
// pagina — anche il fetch fatto da qui (background.js), che pure ha il
// privilegio di ignorare il CORS, viene comunque rifiutato perché il
// Referer è vuoto/sbagliato. JavaScript NON PUÒ impostare manualmente
// l'intestazione Referer su un fetch (è "protetta" dal browser per motivi
// di sicurezza) — serve intervenire a livello di rete PRIMA che la
// richiesta parta, con l'API declarativeNetRequest: questa regola dice al
// browser "per ogni richiesta verso le immagini prodotto di Cardmarket,
// riscrivi il Referer come se venisse da cardmarket.com stesso".
chrome.declarativeNetRequest.updateDynamicRules({
  removeRuleIds: [1],
  addRules: [{
    id: 1,
    priority: 1,
    action: {
      type: 'modifyHeaders',
      requestHeaders: [
        { header: 'Referer', operation: 'set', value: 'https://www.cardmarket.com/' },
      ],
    },
    condition: {
      urlFilter: '||product-images.s3.cardmarket.com',
      resourceTypes: ['xmlhttprequest'],
    },
  }],
}).catch((e) => console.error('[immagine] impossibile impostare la regola Referer:', e.message));

// ── KEEPALIVE: evita che Chrome MV3 termini il SW durante sessioni bulk lunghe ──
// Un alarm ogni 20s è sufficiente — Chrome non stoppa un SW che ha un alarm pending.
function _avviaKeepAlive() {
  chrome.alarms.create('sw-keepalive', { periodInMinutes: 20 / 60 });
}
function _fermaKeepAlive() {
  chrome.alarms.clear('sw-keepalive');
}
// Avvia subito al caricamento del SW (costo zero se non ci sono sessioni attive)
_avviaKeepAlive();

// ── POLLING ORDINI (arrivano dal sito pubblico GitHub Pages) ────────────────
// Il sito, quando l'utente preme "Controlla prezzi", scrive una riga nella
// tabella Supabase 'ordini' con stato 'pending'. Qui, ogni ~20s (stesso
// periodo del keepalive sopra — chrome.alarms non ha bisogno di più alarm
// distinti troppo ravvicinati), controlliamo se c'è un ordine in attesa e lo
// "prendiamo in carico": lo marchiamo 'in_corso' e apriamo/portiamo in primo
// piano la tab app.html sulla sezione Prezzi. La sessione vera e propria
// (eseguiSessione in popup.js, dentro l'iframe di quella sezione) e la
// scrittura dello stato finale 'completato'/'errore' sono una FASE
// SUCCESSIVA, non ancora collegata a questo polling.
function _avviaPollingOrdini() {
  chrome.alarms.create('ordini-poll', { periodInMinutes: 20 / 60 });
}
_avviaPollingOrdini();

async function _controllaOrdini() {
  try {
    const { data: sessionData } = await supabaseClient.auth.getSession();
    const userId = sessionData?.session?.user?.id;
    if (!userId) return; // non loggato — niente da fare

    const { data: pendenti, error: errLettura } = await supabaseClient
      .from('ordini')
      .select('id, tipo, parametri, creato_da')
      .eq('stato', 'pending')
      .order('creato_il', { ascending: true })
      .limit(1);
    if (errLettura) { console.error('[ordini] errore lettura:', errLettura.message); return; }
    if (!pendenti || pendenti.length === 0) return;

    const ordine = pendenti[0];

    // Claim ottimistico: la condizione .eq('stato','pending') nella UPDATE fa
    // sì che, se un altro dispositivo/sessione lo ha già preso un istante
    // prima, questa update non tocchi nessuna riga (claimato.length === 0) —
    // evita che due dispositivi partano sullo stesso ordine in parallelo.
    const { data: claimato, error: errClaim } = await supabaseClient
      .from('ordini')
      .update({ stato: 'in_corso', preso_in_carico_da: userId, preso_in_carico_il: new Date().toISOString() })
      .eq('id', ordine.id)
      .eq('stato', 'pending')
      .select();
    if (errClaim) { console.error('[ordini] errore claim:', errClaim.message); return; }
    if (!claimato || claimato.length === 0) return; // già preso da un altro dispositivo

    if (ordine.tipo === 'controlla_prezzi') {
      // Salvato in storage (non nell'URL) così sopravvive anche se la tab
      // era già aperta su un'altra sezione e va solo "spostata" — vedi FASE
      // SUCCESSIVA per come popup.js/app.js leggeranno questo valore.
      // FIX (controllo prezzi "solo le mie" controllava le carte sbagliate):
      // serve anche creato_da — chi ha effettivamente creato la richiesta
      // dal sito — non solo i parametri. Senza questo, "solo le mie" veniva
      // interpretato come "le carte di chi esegue l'ordine", non di chi
      // l'ha chiesto (vedi uso in popup.js → leggiDatiSheet → 'leggi').
      await chrome.storage.local.set({ ordinePendenteAutorun: { id: ordine.id, tipo: ordine.tipo, parametri: ordine.parametri || {}, creatoDa: ordine.creato_da } });
      await _apriOFocalizzaAppSuPrezzi(ordine.id);
    } else if (ordine.tipo === 'controlla_prezzi_wishlist') {
      // Stesso schema di 'controlla_prezzi' ma per la sezione Wishlist —
      // vedi _avviaAutorunPrezziWishlistSeRichiesto in aggiungi_wishlist_popup.js.
      await chrome.storage.local.set({ ordinePendenteAutorunWishlist: { id: ordine.id } });
      await _apriOFocalizzaAppSuSezione('wishlist', ordine.id);
    } else if (ordine.tipo === 'aggiungi_carte') {
      // FIX (tab che continuava a riaprirsi da sola): tutti i tentativi
      // precedenti (contare le righe pending, poi un "campanello" one-shot)
      // finivano comunque per riaprire la tab in automatico prima o poi. Su
      // richiesta esplicita: l'estensione NON apre più nulla da sola per
      // questo tipo di ordine. Le carte restano semplicemente in attesa in
      // 'coda_carte' (persistente, non si perdono) finché qualcuno non apre
      // DAVVERO la sezione "Aggiungi Carte" — a quel punto (vedi
      // aggiungi_carta_popup.js) parte una lettura pulita dal database, mai
      // da uno stato locale salvato. Qui ci limitiamo a marcare l'ordine
      // come completato, senza alcuna azione sulle tab.
      await supabaseClient.from('ordini').update({
        stato: 'completato', completato_il: new Date().toISOString(),
      }).eq('id', ordine.id);
    } else if (ordine.tipo === 'aggiungi_wishlist') {
      // Stesso comportamento di 'aggiungi_carte' e per lo stesso motivo:
      // nessuna tab aperta in automatico. Le carte restano in attesa in
      // 'coda_wishlist' finché qualcuno non apre la sezione Wishlist (che la
      // legge da sola, vedi _recuperaAltreRigheDaDbWishlist in
      // aggiungi_wishlist_popup.js) o finché una tab già aperta altrove non
      // la pesca al proprio giro periodico di ~20s.
      await supabaseClient.from('ordini').update({
        stato: 'completato', completato_il: new Date().toISOString(),
      }).eq('id', ordine.id);
    } else {
      await supabaseClient.from('ordini').update({
        stato: 'errore',
        errore_msg: `Tipo ordine "${ordine.tipo}" non ancora supportato dall'estensione.`,
        completato_il: new Date().toISOString(),
      }).eq('id', ordine.id);
    }
  } catch (e) {
    console.error('[ordini] errore imprevisto nel polling:', e);
  }
}

// Apre/aggiorna in SILENZIO (senza rubare il focus) una tab già aperta
// sull'estensione (qualunque sezione), navigandola sulla sezione richiesta,
// oppure ne apre una nuova in background. Usata SOLO dal polling ordini
// (automatico): l'utente sul sito non deve accorgersi che qualcosa si è
// aperto — l'apertura MANUALE (icona estensione, bottone "Apri l'app" del
// sito) resta invece a fuoco, vedi _apriOFocalizzaTabApp più sopra.
async function _apriOFocalizzaAppSuPrezzi(ordineId) {
  return _apriOFocalizzaAppSuSezione('prezzi', ordineId);
}

async function _apriOFocalizzaAppSuSezione(sezione, ordineId) {
  const urlApp = chrome.runtime.getURL('app.html');
  // FIX: la versione precedente faceva chrome.tabs.update({url: '...#prezzi'})
  // seguito da un chrome.tabs.reload() separato, per forzare un vero
  // caricamento (un cambio di solo hash non ricarica la pagina — comportamento
  // normale dei browser). Ma le due chiamate sono asincrone e indipendenti:
  // se il reload partiva prima che il cambio di hash fosse "commesso" dal
  // browser, la tab si ricaricava sulla URL VECCHIA (altra sezione), non su
  // #<sezione> — la tab "lampeggiava" (il reload si vedeva) ma la pagina
  // giusta non partiva mai in automatico, finché non si cambiava sezione a
  // mano. Aggiungere un parametro di QUERY (non solo l'hash), diverso ad
  // ogni ordine, risolve alla radice: un cambio di query string è sempre
  // trattato dal browser come una navigazione vera, quindi un SOLO
  // chrome.tabs.update con questa URL basta — nessuna doppia chiamata,
  // nessuna race condition.
  // SILENZIOSA (v4.1): active:false ovunque, e NESSUN chrome.windows.update
  // — prima questa funzione portava la tab/finestra in primo piano, "rubando"
  // lo schermo a chi stava semplicemente guardando il sito. La sessione di
  // controllo prezzi (dentro l'iframe di app.html) gira comunque anche a
  // tab non attiva: Chrome rallenta leggermente i timer delle tab in
  // background ma non le sospende, e c'è già il keepalive con chrome.alarms.
  const urlDestinazione = `${urlApp}?ordine=${encodeURIComponent(ordineId || Date.now())}#${sezione}`;
  const tabs = await chrome.tabs.query({ url: urlApp + '*' });
  if (tabs.length > 0) {
    const tab = tabs[0];
    await chrome.tabs.update(tab.id, { active: false, url: urlDestinazione });
  } else {
    await chrome.tabs.create({ url: urlDestinazione, active: false });
  }
}

// ── WORKER TAB PERSISTENTE PER SESSIONE BULK ─────────────────────────────────
// FIX (troppe tab aperte in sequenza → trigger Cloudflare): il percorso
// "felice" (nessun blocco Cloudflare) apriva comunque UNA TAB NUOVA per ogni
// singola carta/prodotto, solo per leggere il prezzo (le .article-row sono
// iniettate via JS, serve sempre una tab vera per quello). Su una lista bulk
// di N carte questo significa N cicli apri→leggi→chiudi in sequenza, un
// pattern di navigazione molto più "meccanico" di un utente reale — un
// segnale forte per l'anti-bot di Cloudflare, indipendentemente dal ritardo
// configurato tra una richiesta e l'altra.
//
// Soluzione: un'unica tab "worker" viene creata la prima volta che serve e
// poi RIUSATA (chrome.tabs.update invece di tabs.create) per tutte le carte
// o i prodotti successivi della stessa sessione bulk — stesso pattern già
// usato per i singoli fallback Cloudflare (_risolviNomeEPrezzoUnicaTab), qui
// esteso a TUTTA la sessione invece che a una sola carta. L'id della tab
// worker è salvato in chrome.storage.local (sopravvive a un eventuale
// riavvio del service worker) e viene chiusa esplicitamente dal popup a fine
// sessione bulk (messaggio CHIUDI_WORKER_TAB) o ricreata al bisogno se nel
// frattempo non esiste più (es. l'utente l'ha chiusa a mano).
//
// Due worker tab separate — 'carte' e 'sealed' — così le due pagine bulk
// possono restare aperte e in uso contemporaneamente senza interferire.
function _chiaveWorkerTab(kind) { return 'workerTab_' + kind; }

async function _getWorkerTabId(kind) {
  const key = _chiaveWorkerTab(kind);
  const saved = await new Promise(r => chrome.storage.local.get([key], r));
  const tabId = saved[key];
  if (tabId == null) return null;
  const esiste = await new Promise(r => {
    chrome.tabs.get(tabId, (tab) => {
      if (chrome.runtime.lastError || !tab) r(false); else r(true);
    });
  });
  if (!esiste) {
    await new Promise(r => chrome.storage.local.remove([key], r));
    return null;
  }
  return tabId;
}

async function _salvaWorkerTabId(kind, tabId) {
  await new Promise(r => chrome.storage.local.set({ [_chiaveWorkerTab(kind)]: tabId }, r));
}

// Restituisce l'id di una tab pronta da riusare (creandone una vuota se
// nessuna sessione l'ha ancora registrata): chi la userà davvero ci naviga
// sopra con chrome.tabs.update, quindi non serve un URL reale qui.
async function _prontaWorkerTabId(kind) {
  const esistente = await _getWorkerTabId(kind);
  if (esistente != null) return esistente;
  const tab = await new Promise(r => chrome.tabs.create({ url: 'about:blank', active: false }, r));
  await _salvaWorkerTabId(kind, tab.id);
  return tab.id;
}

async function _chiudiWorkerTab(kind) {
  const key = _chiaveWorkerTab(kind);
  const saved = await new Promise(r => chrome.storage.local.get([key], r));
  const tabId = saved[key];
  if (tabId != null) {
    chrome.tabs.remove(tabId, () => { void chrome.runtime.lastError; });
    await new Promise(r => chrome.storage.local.remove([key], r));
  }
}

// ── LOCK PER KIND (evita che due flussi condividano la worker tab in contemporanea) ──
// FIX (race condition worker tab): _prontaWorkerTabId restituisce lo stesso
// tabId a qualunque chiamante lo richieda, senza alcun mutex. Se una carta
// nel pannello di correzione manuale viene aggiunta MENTRE una nuova sessione
// bulk è già partita (entrambe con usaWorkerTab:true, stesso kind), i due
// flussi eseguono chrome.tabs.update sulla stessa tab quasi in contemporanea:
// uno dei due può finire per leggere la pagina navigata dall'altro, con
// rischio di assegnare prezzo/nome sbagliati alla carta sbagliata — in modo
// silenzioso, senza errore visibile. Questa coda serializza per kind: ogni
// task che vuole usare la worker tab si accoda alla precedente e parte solo
// quando quella ha finito (con la tab libera per il task successivo).
const _codaWorkerTab = { carte: Promise.resolve(), sealed: Promise.resolve() };

function _accodaSuWorkerTab(kind, taskFn) {
  const k = kind === 'sealed' ? 'sealed' : 'carte';
  const esecuzione = _codaWorkerTab[k].then(taskFn, taskFn);
  // La coda avanza sempre, anche se il task corrente fallisce — un errore
  // isolato non deve bloccare per sempre le richieste successive per lo
  // stesso kind.
  _codaWorkerTab[k] = esecuzione.then(() => {}, () => {});
  return esecuzione;
}

// Numero massimo di retry per carta (timeout Cardmarket o errore di rete)
const BULK_MAX_RETRY = 2;

// ── HEARTBEAT RICHIESTE LUNGHE (fix "resta bloccato su una carta finché non
// ricarico la pagina") ────────────────────────────────────────────────────
// FIX: le operazioni lunghe (attesa Cloudflare, polling prezzo) vivono
// dentro Promise con setTimeout/setInterval "normali" nel service worker.
// L'alarm sw-keepalive impedisce a Chrome di terminare il SW MENTRE è
// inattivo, ma NON protegge questi timer se Chrome decide comunque di
// terminare il SW a metà di un'attesa lunga (evento raro ma non escluso in
// MV3, soprattutto con tab in background). Quando succede, tutta la catena
// di callback/Promise relativa a quella carta sparisce col SW: il popup
// resta in attesa di una risposta che non arriverà mai, bloccato fino al
// proprio timeout (dimensionato su sliderCfTimeout, fino a 10 minuti) — e a
// volte nemmeno quello lo sblocca perché il canale del messaggio non genera
// sempre un errore "port closed" in questo scenario.
//
// Soluzione: ogni richiesta lunga porta un requestId generato dal popup.
// Il background aggiorna un timestamp "ultima attività" per quel requestId
// a ogni tick del polling (ogni 600ms-2s a seconda della fase). Il popup,
// in parallelo all'attesa della risposta vera, manda un ping leggero
// (PING_RICHIESTA) ogni pochi secondi: se il SW risponde "richiesta non
// trovata" (= è stato riavviato e ha perso lo stato) o non risponde affatto
// per un paio di controlli consecutivi, il popup abbandona l'attesa e passa
// alla carta successiva invece di restare bloccato fino al timeout lungo.
const _richiesteAttive = new Map(); // requestId -> { tabId, ultimaAttivita }

function _touchRichiesta(requestId, tabId) {
  if (!requestId) return;
  const esistente = _richiesteAttive.get(requestId);
  _richiesteAttive.set(requestId, {
    tabId: tabId != null ? tabId : (esistente ? esistente.tabId : null),
    ultimaAttivita: Date.now(),
  });
}

function _rimuoviRichiesta(requestId) {
  if (!requestId) return;
  _richiesteAttive.delete(requestId);
}

// Pulizia periodica di eventuali richieste "orfane" dimenticate in mappa
// (non dovrebbe succedere: rimosse esplicitamente a fine richiesta — questo
// è solo un anti-leak di sicurezza), agganciata all'alarm già esistente.
function _pulisciRichiesteVecchie() {
  const LIMITE_MS = 20 * 60 * 1000; // 20 minuti
  const ora = Date.now();
  for (const [id, info] of _richiesteAttive.entries()) {
    if (ora - info.ultimaAttivita > LIMITE_MS) _richiesteAttive.delete(id);
  }
}

// Legge le opzioni Cloudflare configurate dall'utente, condivise con popup.js:
//   sliderCfTimeout → minuti di attesa (1–10, default 3)
//   avvisoSonoro    → suona quando Cloudflare viene rilevato (default true)
// Un'unica fonte di verità: cambiare le impostazioni in popup.js vale anche
// per il flusso bulk, senza configurazioni duplicate.
function _leggiOpzioniCf() {
  return new Promise((resolve) => {
    chrome.storage.local.get(['sliderCfTimeout', 'avvisoSonoro'], (res) => {
      const minuti = (typeof res.sliderCfTimeout === 'number' && res.sliderCfTimeout >= 1)
        ? res.sliderCfTimeout
        : 3; // default coerente con DEFAULTS.sliderCfTimeout in popup.js
      const avvisoSonoro = res.avvisoSonoro !== false; // default true
      resolve({ cfTimeoutMs: minuti * 60 * 1000, avvisoSonoro });
    });
  });
}

let cloudflareAlarmTabId = null;
let cloudflareAlarmActive = false;

// ── WATCHDOG PERSISTENTE PER L'ATTESA CLOUDFLARE ─────────────────────────────
// FIX (bug "non rispetta l'attesa configurata"): il countdown di Cloudflare
// (sia il suono ripetuto sia la chiusura forzata dopo N minuti) viveva SOLO
// nelle variabili di modulo qui sopra (cloudflareAlarmTabId ecc.) più un
// singolo alarm one-shot 'cloudflare-timeout'. In MV3 il service worker può
// essere terminato e riavviato da Chrome in QUALSIASI momento durante
// un'attesa di più minuti (è la norma, non l'eccezione, per attese così
// lunghe) — quando succede, quelle variabili tornano a null e l'eventuale
// alarm 'cloudflare-timeout' si risveglia senza più trovare nulla da fare:
// la tab resta aperta indefinitamente, o il countdown mostrato all'utente
// smette di corrispondere a quello che succede davvero.
//
// Fix: la scadenza di ogni attesa Cloudflare attiva viene salvata in
// chrome.storage.local (sopravvive ai riavvii del SW, a differenza delle
// variabili JS), e un alarm dedicato 'cf-watchdog' — con periodo di 1 minuto,
// il minimo concesso da chrome.alarms per le estensioni pacchettizzate — la
// controlla a ogni risveglio: se una scadenza è superata, chiude la tab e
// pulisce lo stato, indipendentemente dal fatto che le variabili di modulo
// originali siano ancora vive o siano già sparite con un riavvio del SW.
// Così il tempo configurato resta un limite massimo affidabile in ogni caso.
async function _registraAttesaCf(tabId, minuti) {
  const scadenza = Date.now() + minuti * 60 * 1000;
  const saved = await new Promise(r => chrome.storage.local.get(['cfAttiveAttese'], r));
  const attese = saved.cfAttiveAttese || {};
  attese[tabId] = scadenza;
  await new Promise(r => chrome.storage.local.set({ cfAttiveAttese: attese }, r));
  // periodInMinutes: 1 è il minimo affidabile — richiederne meno (es. 20s)
  // verrebbe comunque arrotondato per eccesso da Chrome nelle estensioni
  // pacchettizzate, quindi tanto vale dichiararlo esplicitamente a 1 minuto.
  chrome.alarms.create('cf-watchdog', { periodInMinutes: 1 });
}

async function _rimuoviAttesaCf(tabId) {
  if (tabId === null || tabId === undefined) return;
  const saved = await new Promise(r => chrome.storage.local.get(['cfAttiveAttese'], r));
  const attese = saved.cfAttiveAttese || {};
  if (attese[tabId] !== undefined) {
    delete attese[tabId];
    await new Promise(r => chrome.storage.local.set({ cfAttiveAttese: attese }, r));
  }
}

async function _controllaWatchdogCf() {
  const saved = await new Promise(r => chrome.storage.local.get(['cfAttiveAttese'], r));
  const attese = saved.cfAttiveAttese || {};
  const ora = Date.now();
  let cambiato = false;
  for (const [tabIdStr, scadenza] of Object.entries(attese)) {
    if (ora > scadenza) {
      const tabId = parseInt(tabIdStr, 10);
      chrome.tabs.remove(tabId, () => { void chrome.runtime.lastError; });
      // Notifica il popup (flusso "Avvia") esattamente come faceva prima
      // l'alarm 'cloudflare-timeout' — nessuna modifica richiesta lato
      // popup.js, che ha già un listener per questo messaggio.
      chrome.runtime.sendMessage({ type: 'CLOUDFLARE_TIMEOUT', tabId }).catch(() => {});
      delete attese[tabIdStr];
      cambiato = true;
    }
  }
  if (cambiato) await new Promise(r => chrome.storage.local.set({ cfAttiveAttese: attese }, r));
  // Nessuna attesa attiva rimasta → l'alarm periodico non serve più finché
  // non ne riparte una nuova (_registraAttesaCf lo ricrea al bisogno).
  if (Object.keys(attese).length === 0) chrome.alarms.clear('cf-watchdog');
}

// FIX (migrazione Supabase): con il vecchio Google Apps Script serviva un
// intero sistema di verifica/tracking anti-duplicato (vedi CHANGELOG per la
// storia completa) perché un fallimento di rete lato client non garantiva
// che la scrittura non fosse comunque avvenuta lato server. Supabase
// (PostgREST) non ha questa ambiguità — vedi _aggiungiConVerifica più sotto,
// ora molto più semplice.

// FIX (migrazione Supabase): con il vecchio Google Apps Script, un timeout
// di rete lasciava un dubbio legittimo — "la scrittura è avvenuta o no?" —
// da qui tutta la logica di verifica/anti-duplicato qui sotto. Supabase
// (PostgREST) risponde in modo affidabile: o la scrittura riesce (e lo sai
// subito), o fallisce con un errore chiaro, senza stati ambigui. Questa
// funzione resta con lo stesso nome/firma (per non toccare i chiamanti) ma
// il suo corpo è ora un semplice inserimento con un paio di ritentativi in
// caso di problemi di rete transitori — niente più ricerca/dedup a valle.
// destinazione: 'wishlist' instrada alla tabella wishlist (azione
// 'aggiungiWishlist') invece che alla collezione — coda UNICA (coda_carte),
// non più due code separate, vedi coda_unificata.sql.
// ── IMMAGINE → DATA URI (bypassa CORS) ───────────────────────────────────────
// FIX (immagine mai visibile sul sito, tentativo precedente fallito): un
// primo tentativo scaricava l'immagine DENTRO la pagina Cardmarket (via
// chrome.scripting.executeScript) sperando che il referer corretto bastasse
// — ma il bucket S3 di Cardmarket non manda le intestazioni CORS, quindi
// anche da lì il download veniva bloccato dal browser (JS di pagina, CORS
// pieno). Le estensioni Chrome però hanno un privilegio speciale: un fetch
// fatto da background.js (qui, non dentro la pagina) IGNORA il CORS, a patto
// che il dominio sia dichiarato in host_permissions nel manifest — l'ho
// aggiunto (product-images.s3.cardmarket.com). Nota: i Service Worker (dove
// gira questo file in Manifest V3) non hanno FileReader — la conversione in
// base64 si fa a mano con btoa() a blocchi, per non superare il limite di
// argomenti di String.fromCharCode su immagini più pesanti.
// Nome file deterministico basato sull'URL originale (hash) — così la
// STESSA immagine (es. "Charizard ex" cercata da due persone diverse in
// momenti diversi) riusa lo stesso file su Storage invece di duplicarlo
// ogni volta.
async function _hashUrl(url) {
  const dati = new TextEncoder().encode(url);
  const buffer = await crypto.subtle.digest('SHA-256', dati);
  return Array.from(new Uint8Array(buffer)).map((b) => b.toString(16).padStart(2, '0')).join('').slice(0, 24);
}

async function _immagineAUrlDati(url) {
  if (!url) { console.log('[DEBUG immagine] nessun URL ricevuto, salto.'); return null; }
  console.log('[DEBUG immagine] avvio conversione per:', url);
  try {
    const resp = await fetch(url);
    console.log('[DEBUG immagine] fetch completato, status:', resp.status, 'ok:', resp.ok);
    if (!resp.ok) { console.warn('[immagine] risposta non ok (' + resp.status + '), tengo URL originale'); return url; }
    const buffer = await resp.arrayBuffer();
    console.log('[DEBUG immagine] bytes ricevuti:', buffer.byteLength);
    // .split(';')[0]: ripulisce eventuali parametri extra (es.
    // "image/jpeg;charset=...") che Supabase Storage rifiuta con "Invalid
    // Content-Type header" se lasciati nel valore.
    let tipo = (resp.headers.get('content-type') || '').split(';')[0].trim();
    // FIX (upload che falliva sempre su un sottoinsieme di immagini più
    // vecchie del catalogo Cardmarket): per alcune immagini Cardmarket
    // manda un header Content-Type spazzatura — es. la stringa letterale
    // "multerS3.AUTO_CONTENT_TYPE", un residuo interno del loro sistema —
    // invece di un vero tipo MIME come "image/jpeg". Supabase Storage
    // rifiutava l'upload con "Invalid Content-Type header" e il codice
    // faceva fallback silenzioso all'URL Cardmarket grezzo, che Cardmarket
    // poi blocca in hotlinking da altri domini: l'immagine non si vedeva
    // mai. Ora, se l'header ricevuto non è un vero tipo immagine (non
    // inizia per "image/"), lo ignoriamo e ricaviamo il tipo dall'
    // estensione del file nell'URL, con image/jpeg come default.
    if (!tipo.startsWith('image/')) {
      const estensioneUrl = (url.split('?')[0].split('.').pop() || '').toLowerCase();
      tipo = estensioneUrl === 'png' ? 'image/png' : (estensioneUrl === 'webp' ? 'image/webp' : 'image/jpeg');
      console.log('[DEBUG immagine] Content-Type non valido da Cardmarket, uso fallback dedotto dall\'estensione:', tipo);
    }
    const estensione = tipo.includes('png') ? 'png' : (tipo.includes('webp') ? 'webp' : 'jpg');
    const nomeFile = (await _hashUrl(url)) + '.' + estensione;
    console.log('[DEBUG immagine] tipo:', tipo, '— nomeFile:', nomeFile);

    // FIX (database appesantito): prima l'immagine veniva convertita in
    // base64 e infilata direttamente nella colonna 'immagine' — con
    // 1300+ carte, decine di MB di puro testo dentro il database. Ora
    // viene caricata su Supabase Storage (fatto apposta per i file) e
    // nella colonna resta solo un link leggero.
    const { data: sessCheck } = await supabaseClient.auth.getSession();
    console.log('[DEBUG immagine] sessione autenticata?', !!sessCheck?.session, '— utente:', sessCheck?.session?.user?.email);
    const { error: errUpload } = await supabaseClient.storage
      .from('immagini-carte')
      .upload(nomeFile, buffer, { contentType: tipo, upsert: true });
    if (errUpload) { console.error('[immagine] errore upload su Storage:', errUpload.message, errUpload); return url; }
    console.log('[DEBUG immagine] upload riuscito.');

    const { data: pub } = supabaseClient.storage.from('immagini-carte').getPublicUrl(nomeFile);
    console.log('[DEBUG immagine] URL pubblico:', pub.publicUrl);
    return pub.publicUrl;
  } catch (e) {
    console.error('[immagine] errore nella conversione:', e.message, e);
    return url; // fallback silenzioso: tiene l'URL esterno originale
  }
}

async function _aggiungiConVerifica(rigaDati, tentativiMax = 3, tipo, destinazione, dbRigaId) {
  let ultimoErrore;
  for (let tentativo = 0; tentativo < tentativiMax; tentativo++) {
    try {
      const data = destinazione === 'wishlist'
        ? await chiamaSupabase('aggiungiWishlist', { rigaDati, tipo, dbRigaId })
        : await chiamaSupabase('aggiungi', { rigaDati, tipoOverride: tipo, destinazione, dbRigaId });
      return data; // successo o errore applicativo — in entrambi i casi non si ritenta
    } catch (e) {
      ultimoErrore = e;
      if (tentativo < tentativiMax - 1) await new Promise(r => setTimeout(r, 1000 * (tentativo + 1)));
    }
  }
  return { ok: false, errore: 'Impossibile aggiungere la carta dopo ' + tentativiMax + ' tentativi: ' + (ultimoErrore ? ultimoErrore.message : '?') };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'AVVIA_AVVISO_CLOUDFLARE') {
    cloudflareAlarmTabId = message.tabId;
    cloudflareAlarmActive = true;
    _suonaEPortaInPrimoPiano(message.tabId, message.avvisoSonoro);
    // Avviso sonoro ogni 8 secondi (best-effort: se il SW si riavvia nel
    // frattempo il suono può saltare qualche ripetizione, ma non è critico
    // — a differenza della scadenza, gestita ora dal watchdog persistente
    // qui sotto, che non dipende da queste variabili di modulo).
    chrome.alarms.create('cloudflare-avviso', { periodInMinutes: 8 / 60 });
    // Timeout configurabile dall'utente (default 3 min se non specificato)
    const timeoutMinuti = (typeof message.timeoutMinuti === 'number' && message.timeoutMinuti >= 1)
      ? message.timeoutMinuti
      : 3;
    // FIX: sostituisce il vecchio alarm one-shot 'cloudflare-timeout' (perdeva
    // lo stato se il SW si riavviava prima di scattare) con il watchdog
    // persistente — vedi commento su _registraAttesaCf più sopra.
    _registraAttesaCf(message.tabId, timeoutMinuti);
    return false;
  }

  if (message.type === 'FERMA_AVVISO_CLOUDFLARE') {
    _fermaAvvisi();
    return false;
  }

  if (message.type === 'PING_RICHIESTA') {
    // FIX (bug "resta bloccato su una carta"): risposta leggera e immediata
    // — nessuna attesa di rete o tab. Se il SW è stato riavviato dopo la
    // registrazione di questa richiesta, _richiesteAttive è vuota (la mappa
    // è in memoria, non sopravvive al riavvio) e "attiva" torna false: è il
    // segnale che il popup usa per capire che la carta è da considerare
    // orfana, anche se il SW stesso ora risponde regolarmente.
    const info = _richiesteAttive.get(message.requestId);
    sendResponse({ attiva: !!info, ultimaAttivita: info ? info.ultimaAttivita : null });
    return false;
  }

  if (message.type === 'CHIUDI_WORKER_TAB') {
    // FIX (troppe tab in sequenza → Cloudflare): chiude la tab worker
    // riusata per una sessione bulk (carte o sealed), inviato dal popup a
    // fine sessione o al reset — vedi _prontaWorkerTabId più sopra.
    _chiudiWorkerTab(message.kind || 'carte').then(() => sendResponse({ ok: true }));
    return true;
  }

  if (message.type === 'APRI_URL_WORKER_TAB') {
    // FIX (troppe tab in sequenza → Cloudflare): il bottone 🔗 "Apri ricerca
    // Cardmarket" nel pannello di correzione manuale apriva sempre una tab
    // NUOVA con chrome.tabs.create — su una sessione con più carte/prodotti
    // da correggere a mano, ognuna apriva la propria tab in aggiunta a
    // quella già usata per la lettura automatica, accumulandone diverse in
    // sequenza: lo stesso pattern di navigazione "meccanico" che altrove in
    // questo file è già stato identificato come segnale per l'anti-bot di
    // Cloudflare. Ora riusa la STESSA worker tab della sessione bulk
    // (_prontaWorkerTabId), portandola semplicemente in primo piano con
    // l'URL di ricerca — stesso comportamento per l'utente (vede la pagina
    // di ricerca), una tab in meno da gestire.
    // FIX (race condition worker tab): questo ramo navigava la worker tab
    // con chrome.tabs.update SENZA passare dalla coda _accodaSuWorkerTab —
    // l'unico punto in tutto il file che bypassava la serializzazione per
    // kind introdotta apposta per evitare che due flussi si contendano la
    // stessa tab in contemporanea (vedi commento esteso su
    // _accodaSuWorkerTab più sopra). Un click su 🔗 mentre un'altra
    // operazione sulla stessa worker tab è ancora in corso (es. un
    // ricontrollo prezzo mancante, o un "➕ Aggiungi" di un'altra carta in
    // correzione) poteva quindi navigare la tab a metà di quella lettura,
    // facendo leggere all'altro task la pagina di ricerca sbagliata invece
    // della propria — lo stesso tipo di bug che la coda era stata introdotta
    // per prevenire. Ora anche questo ramo si accoda, come tutti gli altri
    // usi di usaWorkerTab.
    (async () => {
      const kind = message.kind || 'carte';
      await _accodaSuWorkerTab(kind, async () => {
        const tabId = await _prontaWorkerTabId(kind);
        await new Promise((resolve) => {
          chrome.tabs.update(tabId, { url: message.url, active: true }, (tab) => {
            if (chrome.runtime.lastError || !tab) {
              chrome.tabs.create({ url: message.url, active: true }, (nuovaTab) => {
                _salvaWorkerTabId(kind, nuovaTab.id).then(() => { sendResponse({ ok: true }); resolve(); });
              });
              return;
            }
            chrome.windows.update(tab.windowId, { focused: true }, () => { sendResponse({ ok: true }); resolve(); });
          });
        });
      });
    })();
    return true;
  }

  if (message.type === 'APRI_TAB_CONTROLLO_LOGIN') {
    // Usato dal bottone "🔌 Controlla connessione" nel popup principale.
    // Apre una tab ATTIVA sulla home Pokémon di Cardmarket e legge lo stato
    // di login dal DOM — vedi _controllaLoginCardmarket più sotto per i
    // dettagli verificati.
    _controllaLoginCardmarket()
      .then(esito => sendResponse(esito))
      .catch(() => sendResponse({ loggato: null }));
    return true;
  }

  if (message.type === 'VERIFICA_LOGIN_SILENZIOSA') {
    // Usato automaticamente prima di avviare una sessione (dopo la conferma
    // sul modale "Team Rocket") — vedi _verificaLoginSilenziosa più sotto.
    // FIX (troppe tab in sequenza → Cloudflare): se il chiamante passa un
    // kind ('carte'/'sealed'), il controllo login riusa la worker tab della
    // sessione bulk invece di aprirne una a parte — una tab in meno prima
    // di ogni sessione. Il popup principale (controllo prezzi) non ha un
    // kind/worker tab dedicato in background.js, quindi continua a passare
    // undefined e a usare il vecchio percorso "tab a sé stante".
    _verificaLoginSilenziosa(message.kind || null)
      .then(esito => sendResponse(esito))
      .catch(() => sendResponse({ loggato: null }));
    return true;
  }

  // FIX (immagine mai visibile dal controllo prezzi): content.js gira
  // DENTRO la pagina Cardmarket — stesso limite di CORS di qualunque script
  // di pagina, non può scaricare l'immagine da sé (vedi _immagineAUrlDati
  // più sopra per il perché). Manda quindi solo l'URL grezzo qui, e QUI
  // (background.js, privilegio di estensione, CORS bypassato sui domini in
  // host_permissions) lo convertiamo davvero prima di scrivere sul database.
  if (message.type === 'CONVERTI_IMMAGINE') {
    _immagineAUrlDati(message.url || null).then((dataUri) => sendResponse({ immagine: dataUri }));
    return true;
  }

  if (message.type === 'AGGIUNGI_CARTA') {
    const { rigaDati, azione, codice, lingua, condizione, riga, qty, prezzo, immagine, nome, tipo, destinazione, dbRigaId } = message;

    // Nessuna azione specificata → è una nuova carta/prodotto da aggiungere.
    if (!azione) {
      _aggiungiConVerifica(rigaDati, 3, tipo, destinazione, dbRigaId)
        .then(data => sendResponse(data))
        .catch(err => sendResponse({ ok: false, errore: err.message }));
      return true;
    }

    let promessa;
    if (azione === 'cerca') {
      promessa = chiamaSupabase('cerca', { codice, lingua, condizione });
    } else if (azione === 'cercaBulk') {
      promessa = chiamaSupabase('cercaBulk', { richieste: message.richieste });
    } else if (azione === 'aggiornaQty') {
      promessa = chiamaSupabase('aggiornaQty', { riga, qty });
    } else if (azione === 'aggiornaPrezzo') {
      // Ricontrollo automatico quando il prezzo risultava mancante al primo
      // inserimento — scrive solo i campi effettivamente presenti (prezzo
      // se trovato, nome/codice come rete di sicurezza per righe salvate
      // senza nome). L'azione 'aggiornaPrezzo' dell'adapter gestisce già
      // esattamente questo caso.
      promessa = chiamaSupabase('aggiornaPrezzo', { riga, prezzo, nome, codice });
    } else {
      promessa = chiamaSupabase('aggiungi', { rigaDati });
    }
    promessa
      .then(data => sendResponse(data))
      .catch(err => sendResponse({ ok: false, errore: err.message }));
    return true;
  }

  // FIX (pulizia codice morto): rimossi gli handler 'FETCH_IMMAGINE' e
  // 'LEGGI_NOME_SEALED' — nessun punto del progetto (nessuno dei tre popup)
  // invia più questi due tipi di messaggio, superati rispettivamente da:
  // l'estrazione immagine inline nelle funzioni di lettura già esistenti
  // (_estraiImmagineDaHtml chiamata direttamente dove serve), e da
  // 'LEGGI_SEALED' (stessa logica ma completa del wiring requestId/
  // heartbeat per il watchdog anti-blocco — vedi _touchRichiesta/
  // _rimuoviRichiesta). Tenerli in giro come codice morto era un rischio
  // silenzioso: 'LEGGI_NOME_SEALED' in particolare non passava mai
  // requestId a _leggiNomeSealedDaCardmarket, quindi se richiamato per
  // errore in futuro (es. codice copiato dal punto sbagliato) avrebbe
  // fallito silenziosamente la protezione watchdog già corretta altrove,
  // lasciando una sessione bloccata su un prodotto senza alcun avviso.

  if (message.type === 'LEGGI_NOME_CARTA') {
    // FIX (troppe tab in sequenza → Cloudflare): durante una sessione bulk
    // riusiamo un'unica tab worker per leggere il prezzo di tutte le carte
    // (message.usaWorkerTab, impostato solo dal ciclo bulk) invece di aprirne
    // e chiuderne una per ciascuna — vedi _prontaWorkerTabId più sopra.
    (async () => {
      const eseguiTask = async () => {
        const tabIdWorker = message.usaWorkerTab ? await _prontaWorkerTabId('carte') : null;
        // FIX (bug "resta bloccato su una carta"): registra la richiesta
        // nell'heartbeat — vedi commento esteso su _richiesteAttive più sopra.
        const requestId = message.requestId || null;
        _touchRichiesta(requestId, tabIdWorker);
        try {
          const r = await _leggiNomeDaCardmarket(message.urlNome, message.lingua, message.condizione, message.oloType || '', !!message.firstEd, 0, tabIdWorker, requestId);
          _rimuoviRichiesta(requestId);
          sendResponse({ nome: r.nome, codice: r.codice, prezzo: r.prezzo, urlSingles: r.urlSingles, disambiguation: !!r.disambiguation, varianteNonTrovata: !!r.varianteNonTrovata, opzioni: r.opzioni || [], immagine: r.immagine || null, rateLimited: !!r.rateLimited });
        } catch (_) {
          _rimuoviRichiesta(requestId);
          sendResponse({ nome: null, codice: null, prezzo: null, urlSingles: null, disambiguation: false, varianteNonTrovata: false, rateLimited: false });
        }
      };
      if (message.usaWorkerTab) await _accodaSuWorkerTab('carte', eseguiTask);
      else await eseguiTask();
    })();
    return true;
  }

  if (message.type === 'LEGGI_SEALED') {
    (async () => {
      const eseguiTask = async () => {
        const tabIdWorker = message.usaWorkerTab ? await _prontaWorkerTabId('sealed') : null;
        const requestId = message.requestId || null;
        _touchRichiesta(requestId, tabIdWorker);
        try {
          const r = await _leggiNomeSealedDaCardmarket(message.urlNome, message.lingua, 0, tabIdWorker, requestId);
          _rimuoviRichiesta(requestId);
          sendResponse({ nome: r.nome, urlProdotto: r.urlProdotto, prezzo: r.prezzo, immagine: r.immagine || null, disambiguation: !!r.disambiguation, opzioni: r.opzioni || [], rateLimited: !!r.rateLimited });
        } catch (_) {
          _rimuoviRichiesta(requestId);
          sendResponse({ nome: null, urlProdotto: null, prezzo: null, immagine: null, disambiguation: false, rateLimited: false });
        }
      };
      if (message.usaWorkerTab) await _accodaSuWorkerTab('sealed', eseguiTask);
      else await eseguiTask();
    })();
    return true;
  }

  // ── RICONTROLLO PREZZO MANCANTE ──────────────────────────────────────────
  // Usati dal bulk (carte/sealed) quando la carta/prodotto è stato inserito
  // nel foglio ma senza prezzo: dopo un delay configurabile si rilegge SOLO
  // il prezzo dalla pagina già nota (urlSingles/urlProdotto), senza rifare
  // tutta la risoluzione nome/codice.
  if (message.type === 'LEGGI_SOLO_PREZZO') {
    (async () => {
      const eseguiTask = async () => {
        const tabIdWorker = message.usaWorkerTab ? await _prontaWorkerTabId('carte') : null;
        const requestId = message.requestId || null;
        _touchRichiesta(requestId, tabIdWorker);
        try {
          const { prezzo, immagine, nome, codice, tabId } = await _leggiPrezzoDaSingles(message.urlConFiltri, tabIdWorker, requestId);
          _rimuoviRichiesta(requestId);
          // FIX: se la worker tab passata non era più valida, ne è stata
          // aperta una nuova al volo — aggiorna subito lo storage così la
          // prossima chiamata della sessione la trova e la riusa.
          if (tabIdWorker != null && tabId && tabId !== tabIdWorker) await _salvaWorkerTabId('carte', tabId);
          sendResponse({
            prezzo: (prezzo === 'RateLimit' ? null : prezzo) ?? null,
            immagine: immagine || null,
            // FIX: propaga nome/codice riletti dalla stessa tab del
            // ricontrollo prezzo — usati dal chiamante come rete di sicurezza
            // per le righe salvate a suo tempo senza nome (vedi background.js,
            // commento su _leggiPrezzoDaSingles/chiudi()).
            nome: nome || null,
            codice: codice || null,
          });
        } catch (_) {
          _rimuoviRichiesta(requestId);
          sendResponse({ prezzo: null, immagine: null, nome: null, codice: null });
        }
      };
      if (message.usaWorkerTab) await _accodaSuWorkerTab('carte', eseguiTask);
      else await eseguiTask();
    })();
    return true;
  }

  if (message.type === 'LEGGI_SOLO_PREZZO_SEALED') {
    (async () => {
      const eseguiTask = async () => {
        const tabIdWorker = message.usaWorkerTab ? await _prontaWorkerTabId('sealed') : null;
        const requestId = message.requestId || null;
        _touchRichiesta(requestId, tabIdWorker);
        try {
          const ris = await _leggiPrezzoSealed(message.urlProdotto, tabIdWorker, requestId);
          _rimuoviRichiesta(requestId);
          if (tabIdWorker != null && ris && ris.tabId && ris.tabId !== tabIdWorker) await _salvaWorkerTabId('sealed', ris.tabId);
          sendResponse({
            prezzo: (ris && !ris.rateLimited) ? (ris.prezzo ?? null) : null,
            immagine: (ris && ris.immagine) || null,
            // FIX: propaga il nome riletto dalla stessa tab del ricontrollo
            // prezzo — rete di sicurezza per i prodotti sealed salvati a suo
            // tempo senza nome.
            nome: (ris && ris.nome) || null,
          });
        } catch (_) {
          _rimuoviRichiesta(requestId);
          sendResponse({ prezzo: null, immagine: null, nome: null });
        }
      };
      if (message.usaWorkerTab) await _accodaSuWorkerTab('sealed', eseguiTask);
      else await eseguiTask();
    })();
    return true;
  }

  return false;
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'sw-keepalive') { _pulisciRichiesteVecchie(); return; }

  if (alarm.name === 'ordini-poll') { _controllaOrdini(); return; }

  if (alarm.name === 'cloudflare-avviso' && cloudflareAlarmActive && cloudflareAlarmTabId !== null) {
    _suonaEPortaInPrimoPiano(cloudflareAlarmTabId, true);
  }

  // FIX: il vecchio alarm one-shot 'cloudflare-timeout' è stato sostituito
  // dal watchdog persistente (_controllaWatchdogCf) — vedi commento esteso
  // su _registraAttesaCf più sopra. Copre sia il flusso "Avvia" (popup.js)
  // sia le attese Cloudflare interne al flusso bulk aggiungi carta/sealed,
  // in modo uniforme e resistente ai riavvii del service worker.
  if (alarm.name === 'cf-watchdog') {
    _controllaWatchdogCf();
  }
});

function _fermaAvvisi() {
  // FIX: prima di azzerare cloudflareAlarmTabId, ripulisce anche la sua voce
  // nel watchdog persistente — altrimenti resterebbe lì fino alla propria
  // scadenza naturale anche se l'attesa è già stata risolta con successo
  // (es. prezzo trovato prima del timeout), chiudendo inutilmente una tab
  // che nel frattempo potrebbe essere già stata riusata per altro.
  if (cloudflareAlarmTabId !== null) _rimuoviAttesaCf(cloudflareAlarmTabId);
  cloudflareAlarmActive = false;
  cloudflareAlarmTabId = null;
  chrome.alarms.clear('cloudflare-avviso');
}

async function _suonaEPortaInPrimoPiano(tabId, avvisoSonoro, kind = null) {
  chrome.tabs.get(tabId, (tab) => {
    if (chrome.runtime.lastError || !tab) {
      _fermaAvvisi();
      return;
    }
    // Porta la finestra in primo piano, poi attiva la tab
    chrome.windows.update(tab.windowId, { focused: true }, () => {
      setTimeout(() => chrome.tabs.update(tabId, { active: true }), 150);
    });
  });

  // FIX (backoff adattivo): notifica i popup bulk ('carte'/'sealed') che un
  // blocco Cloudflare è appena scattato durante la sessione — usato per
  // allungare temporaneamente il delay tra una carta e la successiva invece
  // di mantenere sempre lo stesso ritmo fisso per tutta la lista. Solo un
  // broadcast leggero (nessuna risposta attesa): se nessun popup bulk è
  // aperto ad ascoltarlo, il messaggio viene semplicemente ignorato.
  if (kind) {
    chrome.runtime.sendMessage({ type: 'CLOUDFLARE_HIT_BULK', kind }).catch(() => {});
  }

  if (avvisoSonoro) {
    await _suonaDaOffscreen();
  }
}

async function _suonaDaOffscreen() {
  // Crea l'offscreen document se non esiste già
  const existingContexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
  });

  if (existingContexts.length === 0) {
    await chrome.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['AUDIO_PLAYBACK'],
      justification: 'Riproduce il suono di avviso Cloudflare',
    });
  }

  const audioUrl = chrome.runtime.getURL('avviso.mp3');
  chrome.runtime.sendMessage({ type: 'SUONA', url: audioUrl }).catch(() => {});
}

// Titoli Cloudflare — unica fonte di verità, passata come arg a executeScript.
// 'patikrinimas' = lituano; mancava nelle copie inline precedenti.
const CF_TITLES = [
  'just a moment', 'un attimo', 'ci siamo quasi', 'almost there',
  'checking your', 'einen moment', 'por favor', 'verifique', 'patikrinimas',
];

// ── CONTROLLO LOGIN CARDMARKET (verificato dal DOM reale, 2026-07) ───────────
// Usato dal bottone "🔌 Controlla connessione" nel popup principale. Apre una
// tab ATTIVA sulla home Pokémon di Cardmarket e legge nell'header un segnale
// affidabile, verificato dal DOM reale in ENTRAMBI gli stati:
//   - Loggato:     <a id="account-dropdown" ...> presente (mostra username,
//                   credito account, menu utente)
//   - Non loggato: <div id="login-signup"> presente (form Username/Password
//                   inline + bottoni "Login"/"Registrarsi")
// Nessuno dei due elementi non è ambiguo: sono mutuamente esclusivi, sempre
// uno dei due presente nell'header su qualunque pagina Cardmarket. La tab
// resta comunque attiva/in primo piano dopo il controllo, così l'utente può
// accedere subito se il risultato è "non loggato".
// Helper condiviso: legge il segnale di login dal DOM di una tab già aperta
// su Cardmarket (polling con timeout). Usato sia dalla variante "attiva"
// (bottone Controlla connessione, azione esplicita dell'utente) sia dalla
// variante "silenziosa" (verifica automatica prima di avviare una sessione).
function _leggiStatoLoginCardmarket(tabId) {
  return new Promise((resolve) => {
    let risolto = false;
    let pollTimer = null;
    let timeout = null;

    function concludi(valore) {
      if (risolto) return;
      risolto = true;
      if (pollTimer) clearInterval(pollTimer);
      if (timeout) clearTimeout(timeout);
      chrome.tabs.onUpdated.removeListener(onLoad);
      resolve(valore);
    }

    function tentaLettura() {
      chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          if (document.getElementById('account-dropdown')) return { loggato: true };
          if (document.getElementById('login-signup')) return { loggato: false };
          return undefined; // pagina non ancora renderizzata → il polling riprova
        },
      }, (results) => {
        if (chrome.runtime.lastError) { concludi({ loggato: null }); return; }
        const val = results?.[0]?.result;
        if (val === undefined || val === null) return; // non pronto, riprova
        concludi(val);
      });
    }

    function onLoad(id, info) {
      if (id !== tabId || info.status !== 'complete') return;
      chrome.tabs.onUpdated.removeListener(onLoad);
      pollTimer = setInterval(tentaLettura, 400);
      timeout = setTimeout(() => concludi({ loggato: null }), 10000);
    }
    chrome.tabs.onUpdated.addListener(onLoad);
  });
}

// Usata dal bottone "🔌 Controlla connessione": azione esplicita dell'utente,
// quindi la tab si apre sempre attiva/in primo piano.
function _controllaLoginCardmarket() {
  return new Promise((resolve) => {
    chrome.tabs.create({ url: 'https://www.cardmarket.com/it/Pokemon', active: true }, (tab) => {
      _leggiStatoLoginCardmarket(tab.id).then(resolve);
    });
  });
}

// Usata PRIMA di avviare una sessione (▶ Avvia / 📋 Aggiungi tutte / 📦
// Aggiungi al foglio), subito dopo la conferma sul modale "Team Rocket": il
// modale resta un promemoria proattivo, ma da solo non basta più a sbloccare
// l'avvio — c'è sempre questo riscontro oggettivo dietro. Controllo
// silenzioso: la tab si apre in background (nessun furto di focus dal
// popup se l'utente è già loggato) e viene chiusa subito senza disturbare;
// solo se risulta NON loggato viene portata in primo piano, così l'utente
// può accedere subito invece di scoprirlo a sessione già iniziata.
// FIX (troppe tab in sequenza → Cloudflare): se il chiamante passa un kind
// ('carte'/'sealed' — Wishlist riusa 'carte', stesso kind della sua worker
// tab per LEGGI_NOME_CARTA/LEGGI_SOLO_PREZZO), il controllo login avviene
// nella STESSA worker tab già usata dalla sessione bulk imminente, invece
// di aprirne una a parte solo per questo controllo — una tab in meno prima
// di ogni sessione "📋 Aggiungi tutte"/"📦 Aggiungi al foglio"/"🗂️ Aggiungi
// alla wishlist"/"🔄 Aggiorna prezzi". Nessun kind (popup principale, che
// non ha un pool worker tab qui in background.js) → comportamento
// invariato: tab dedicata, aperta in background e chiusa subito se il
// login risulta ok.
function _verificaLoginSilenziosa(kind) {
  if (kind) {
    // Accodata come ogni altro uso della worker tab (vedi
    // _accodaSuWorkerTab più in alto) — senza questo, un click su "Aggiungi
    // tutte" subito dopo l'apertura pagina potrebbe far navigare la tab a
    // metà di questo controllo, facendo leggere alla prima carta la pagina
    // sbagliata (stesso tipo di race condition già risolto per
    // APRI_URL_WORKER_TAB in v2.10).
    return _accodaSuWorkerTab(kind, () => _verificaLoginSuWorkerTab(kind));
  }
  return new Promise((resolve) => {
    chrome.tabs.create({ url: 'https://www.cardmarket.com/it/Pokemon', active: false }, (tab) => {
      _leggiStatoLoginCardmarket(tab.id).then((esito) => {
        if (esito && esito.loggato === false) {
          chrome.tabs.update(tab.id, { active: true }, () => {
            chrome.windows.update(tab.windowId, { focused: true }, () => resolve(esito));
          });
        } else {
          chrome.tabs.remove(tab.id, () => { void chrome.runtime.lastError; });
          resolve(esito);
        }
      });
    });
  });
}

function _verificaLoginSuWorkerTab(kind) {
  return new Promise(async (resolve) => {
    const tabId = await _prontaWorkerTabId(kind);

    function suTabPronta(idTab, windowIdFallback) {
      _leggiStatoLoginCardmarket(idTab).then((esito) => {
        if (esito && esito.loggato === false) {
          chrome.tabs.update(idTab, { active: true }, (tabAgg) => {
            const windowId = (tabAgg && tabAgg.windowId) || windowIdFallback;
            chrome.windows.update(windowId, { focused: true }, () => resolve(esito));
          });
        } else {
          // Login ok (o non determinabile): la tab NON viene chiusa — resta
          // pronta per essere navigata dalla prima carta/prodotto della
          // sessione bulk imminente, stesso principio del resto della
          // worker tab.
          resolve(esito);
        }
      });
    }

    chrome.tabs.update(tabId, { url: 'https://www.cardmarket.com/it/Pokemon' }, (tab) => {
      if (chrome.runtime.lastError || !tab) {
        // La worker tab registrata non esiste più (es. chiusa a mano
        // dall'utente) — ne apriamo una nuova al volo e la registriamo,
        // stesso fallback già usato altrove per il riuso della worker tab.
        chrome.tabs.create({ url: 'https://www.cardmarket.com/it/Pokemon', active: false }, (nuovaTab) => {
          _salvaWorkerTabId(kind, nuovaTab.id).then(() => suTabPronta(nuovaTab.id, nuovaTab.windowId));
        });
        return;
      }
      suTabPronta(tabId, tab.windowId);
    });
  });
}

// ── LEGGI NOME E PREZZO DA CARDMARKET ─────────────────────────────────────────
//
// Flusso:
//   1. Apre urlNome (può essere /Search? oppure /Singles/).
//      - Se è /Search?: aspetta con polling che Cardmarket carichi i risultati,
//        poi prende il primo link /Singles/ dalla lista.
//      - Se è /Singles/ o redirect diretto: legge il nome dall'h1.
//   2. Se il nome non è ancora disponibile (caso /Search?→link), apre il /Singles/
//      in un'altra tab per leggere l'h1.
//   3. Apre il /Singles/ con filtri lingua+condizione e legge il prezzo con polling
//      (le .article-row vengono iniettate via JS dopo il caricamento).
//
// Restituisce: { nome, prezzo, urlSingles }
//   urlSingles = URL /Singles/ pulito (senza query) da salvare nella colonna H.

// FIX (bug "prezzo RH/1ED mostra il prezzo della stampa normale"): la pagina
// filtra le righe d'offerta in base a isReverseHolo=Y / isFirstEd=Y letti
// dalla query string (vedi rigaOk in _leggiPrezzoDaSingles / tentaLetturaPrezzo
// in _risolviNomeEPrezzoUnicaTab). Se l'URL usato per LEGGERE IL PREZZO non
// porta questi parametri, isReverseHolo/isFirstEd valgono false lato pagina,
// e la logica "!isReverseHolo && rigaERH(riga) → escludi" finisce per
// scartare proprio le righe RH/1ED, lasciando come prezzo quello della
// stampa normale. L'URL salvato nel foglio (colonna H) li aveva già —
// mancavano solo su questo URL "di lettura", usato SOLO in memoria per la
// prima chiamata a _leggiPrezzoDaSingles/_risolviNomeEPrezzoUnicaTab.
// Ricava un nome leggibile dallo slug di un URL /Singles/ quando l'estrazione
// dall'h1 non ha prodotto nulla (fallback ultimo, usato sia dal percorso
// fetch statico sia — FIX — dal percorso di fallback via tab, che prima ne
// era sprovvisto: vedi commento esteso su _leggiNomeDaCardmarket più sotto).
// Es. ".../Arcanine-SVP-EN-011" → "ARCANINE".
//
// FIX (bug "YVELTAL 046" → nome vuoto): il test dev'essere case-sensitive
// (niente /i) — i codici set reali nello slug sono SEMPRE in maiuscolo
// letterale, mentre un nome in Title Case (es. "Yveltal") non deve mai
// essere scambiato per un codice togliendo il flag case-insensitive.
function _nomeDaSlugUrlSingles(urlSingles) {
  if (!urlSingles) return null;
  const slug = urlSingles.split('/').pop() || '';
  const parti = slug.split('-');
  let endIdx = parti.length;
  for (let i = parti.length - 1; i >= 0; i--) {
    if (/^\d+$/.test(parti[i]) || /^[A-Z]{2,}\d+$/.test(parti[i]) || /^[A-Z]{2,}$/.test(parti[i])) {
      endIdx = i;
    } else { break; }
  }
  return parti.slice(0, endIdx).join(' ').toUpperCase() || null;
}

function _appendVariantParams(url, oloType, firstEd) {
  if (!url) return url;
  let u = url;
  if (oloType === 'RH') u += (u.includes('?') ? '&' : '?') + 'isReverseHolo=Y';
  if (firstEd) u += (u.includes('?') ? '&' : '?') + 'isFirstEd=Y';
  return u;
}

async function _leggiNomeDaCardmarket(urlNome, lingua, condizione, oloType = '', firstEd = false, _tentativo = 0, tabIdEsterno = null, requestId = null) {
  // ── FASE 1: fetch HTML statico (nessuna tab aperta) ──────────────────────────
  // Cardmarket serve nome, codice e link /Singles/ nell'HTML server-side.
  // Solo il prezzo richiede JS rendering → unica tab aperta, solo per quello.
  const fase1 = await _risolviSinglesENomeFetch(urlNome, oloType);
  console.log('[CardSync] esito fase1 (fetch statico):', fase1);

  // Error 1015: nessun fallback con tab — riprovare con una tab non risolve
  // il rate limit (anzi peggiora la situazione). Propaga subito al chiamante,
  // che metterà in pausa 30 minuti prima di ritentare.
  if (fase1.rateLimited) {
    return { nome: null, codice: null, prezzo: null, urlSingles: null, rateLimited: true };
  }

  // Fallback solo se Cloudflare blocca il fetch o fetch fallisce per rete.
  // Usa UNA SOLA tab per risoluzione + lettura prezzo (_risolviNomeEPrezzoUnicaTab),
  // invece delle due tab sequenziali usate in precedenza.
  if (fase1.cloudflare || fase1.fetchFailed) {
    console.log('[CardSync] passo al fallback via tab (motivo:', fase1.cloudflare ? 'cloudflare' : 'fetch fallita', ')');
    const fusa = await _risolviNomeEPrezzoUnicaTab(urlNome, lingua, condizione, oloType, firstEd, tabIdEsterno, requestId);
    // FIX (worker tab about:blank mai usata): se la worker tab passata non
    // era più valida, _risolviNomeEPrezzoUnicaTab ne ha aperta una nuova al
    // volo — aggiorniamo subito lo storage così le carte successive della
    // stessa sessione bulk la trovano e la riusano.
    if (tabIdEsterno != null && fusa && fusa.tabId && fusa.tabId !== tabIdEsterno) {
      await _salvaWorkerTabId('carte', fusa.tabId);
      tabIdEsterno = fusa.tabId;
    }
    console.log('[CardSync] esito fallback via tab:', fusa);
    if (fusa && fusa.rateLimited)
      return { nome: null, codice: null, prezzo: null, urlSingles: null, rateLimited: true };
    if (fusa && fusa.disambiguation)
      return { nome: null, codice: null, prezzo: null, urlSingles: null, disambiguation: true, opzioni: fusa.opzioni || [] };
    if (fusa && fusa.varianteNonTrovata)
      return { nome: null, codice: null, prezzo: null, urlSingles: null, varianteNonTrovata: true };
    if (!fusa?.urlSingles) {
      if (_tentativo < BULK_MAX_RETRY) {
        await new Promise(r => setTimeout(r, 2000 * (_tentativo + 1)));
        return _leggiNomeDaCardmarket(urlNome, lingua, condizione, oloType, firstEd, _tentativo + 1, tabIdEsterno, requestId);
      }
      return { nome: null, codice: null, prezzo: null, urlSingles: null };
    }

    // FIX (bug "riga con nome vuoto, sovrascritta dalla carta successiva"):
    // questo percorso (fallback via tab) restituiva fusa.nome anche quando
    // era null — a differenza del percorso fetch statico più sotto, che ha
    // sempre applicato un fallback (nome dallo slug URL) e, se anche quello
    // falliva, si rifiutava di restituire una carta senza nome. Qui quel
    // controllo mancava del tutto: bastava che l'h1 non venisse letto bene
    // nella fase-prezzo di _risolviNomeEPrezzoUnicaTab (caso raro ma reale,
    // tipicamente quando si parte da /Search? con risultati multipli) perché
    // la carta finisse scritta nel foglio con COL.NOME vuoto pur avendo un
    // urlSingles valido — una riga così può essere scambiata da script a
    // valle per "riga ancora libera" e finire sovrascritta dalla carta
    // successiva. Stesso trattamento del percorso fetch: prova il fallback
    // dallo slug, se anche quello fallisce ritenta o va in correzione
    // manuale invece di scrivere una riga senza nome. Nessuna tab aggiuntiva:
    // si riusano solo i dati già ottenuti da _risolviNomeEPrezzoUnicaTab.
    const nomeFusa = fusa.nome || _nomeDaSlugUrlSingles(fusa.urlSingles);
    if (!nomeFusa) {
      if (_tentativo < BULK_MAX_RETRY) {
        await new Promise(r => setTimeout(r, 2000 * (_tentativo + 1)));
        return _leggiNomeDaCardmarket(urlNome, lingua, condizione, oloType, firstEd, _tentativo + 1, tabIdEsterno, requestId);
      }
      return { nome: null, codice: null, prezzo: null, urlSingles: null };
    }
    return { nome: nomeFusa, codice: fusa.codice, prezzo: fusa.prezzo, urlSingles: fusa.urlSingles, immagine: fusa.immagine || null };
  }

  if (fase1.disambiguation)
    return { nome: null, codice: null, prezzo: null, urlSingles: null, disambiguation: true, opzioni: fase1.opzioni || [] };
  if (fase1.varianteNonTrovata)
    return { nome: null, codice: null, prezzo: null, urlSingles: null, varianteNonTrovata: true };

  const { urlSingles, nome, codice } = fase1;

  if (!urlSingles) {
    if (_tentativo < BULK_MAX_RETRY) {
      await new Promise(r => setTimeout(r, 2000 * (_tentativo + 1)));
      return _leggiNomeDaCardmarket(urlNome, lingua, condizione, oloType, firstEd, _tentativo + 1, tabIdEsterno, requestId);
    }
    return { nome: null, codice: null, prezzo: null, urlSingles: null };
  }

  // ── FASE 2: leggi prezzo con filtri — unica tab aperta per carta ─────────────
  // FIX: qui mancava l'applicazione di isReverseHolo/isFirstEd — vedi
  // commento su _appendVariantParams più sopra. Senza questo, il prezzo letto
  // era sempre quello della stampa normale per le carte RH/1ED.
  const urlConFiltri = _appendVariantParams(costruisciUrlFiltrato(urlSingles, lingua, condizione), oloType, firstEd);
  let risPrez = await _leggiPrezzoDaSingles(urlConFiltri, tabIdEsterno, requestId);
  // FIX (troppe tab in sequenza → Cloudflare): se la worker tab passata non
  // era più valida (chiusa manualmente dall'utente, o mai creata prima),
  // _leggiPrezzoDaSingles ne ha aperta una nuova al volo — aggiorniamo
  // subito lo storage così le carte successive della stessa sessione bulk
  // la trovano e la riusano, invece di aprirne una diversa ogni volta.
  if (tabIdEsterno != null && risPrez.tabId && risPrez.tabId !== tabIdEsterno) {
    await _salvaWorkerTabId('carte', risPrez.tabId);
    tabIdEsterno = risPrez.tabId;
  }

  // FIX (carte cinesi e altre espansioni "RH di base", senza stampa normale
  // separata): isReverseHolo=Y/isFirstEd=Y sono filtri NATIVI di Cardmarket
  // che presuppongono l'esistenza di una stampa non-RH da escludere. Quando
  // la variante richiesta È l'unica stampa esistente, Cardmarket può non
  // taggare nessuna riga come tale e il filtro nativo restituisce zero
  // offerte — anche se il prezzo, essendoci un'unica stampa, sarebbe
  // comunque corretto senza quel filtro. Se la lettura filtrata non trova
  // nulla, ritentiamo SENZA isReverseHolo/isFirstEd prima di arrenderci:
  // si parte sempre dal più specifico, questo è solo un fallback di
  // sicurezza per non perdere il prezzo di carte che prima (senza questo
  // fix) venivano lette correttamente proprio perché il filtro non c'era.
  if ((risPrez.prezzo === null || risPrez.prezzo === undefined) && (oloType === 'RH' || firstEd)) {
    const urlSenzaVarianti = costruisciUrlFiltrato(urlSingles, lingua, condizione);
    const risPrezFallback = await _leggiPrezzoDaSingles(urlSenzaVarianti, tabIdEsterno, requestId);
    if (risPrezFallback.prezzo !== null && risPrezFallback.prezzo !== undefined) risPrez = risPrezFallback;
  }

  if (risPrez.prezzo === 'RateLimit') {
    return { nome: null, codice: null, prezzo: null, urlSingles: null, rateLimited: true };
  }

  // Fallback ultimo: se il nome non è stato estratto dall'HTML (raro per alcune promo SVP),
  // ricavalo dallo slug dell'URL /Singles/ (es. ".../Arcanine-SVP-EN-011" → "ARCANINE").
  //
  // FIX (bug "YVELTAL 046" → riga salvata con nome vuoto e codice = query
  // grezza): i due controlli avevano il flag /i su /^[A-Z]{2,}\d+$/ e,
  // soprattutto, su /^[A-Z]{2,}$/. Con case-insensitive attivo, anche un nome
  // scritto in Title Case come "Yveltal" soddisfa /^[A-Z]{2,}$/i (equivale a
  // testare "YVELTAL"), venendo scambiato per un codice set. Il loop, che
  // scorre lo slug a ritroso "mangiandosi" i segmenti che sembrano codice,
  // finiva quindi per inghiottire anche il nome vero (non solo il suffisso
  // codice), lasciando nomefinale = '' → null. I codici set reali nell'URL
  // sono SEMPRE scritti in maiuscolo letterale (es. "PAR", "SVP", "TEF") —
  // un nome in Title Case (prima lettera maiuscola, resto minuscolo) non li
  // soddisfa più togliendo il flag /i, quindi ora resta correttamente intatto.
  let nomefinale = nome || _nomeDaSlugUrlSingles(urlSingles);

  // FIX (stesso bug, parte 2): se anche dopo il fallback il nome resta
  // sconosciuto, NON scrivere comunque la riga nel foglio. Prima veniva
  // scritta lo stesso con COL.NOME vuoto e COL.CODICE forzato alla query
  // grezza digitata dall'utente (es. "YVELTAL 046" invece di un vero codice
  // set) — una riga con nome vuoto può essere scambiata da script a valle
  // per "riga ancora libera" e finire sovrascritta dalla carta successiva.
  // Meglio trattare l'estrazione fallita come le altre risoluzioni fallite:
  // qualche retry, poi instradamento al pannello di correzione manuale.
  if (!nomefinale) {
    if (_tentativo < BULK_MAX_RETRY) {
      await new Promise(r => setTimeout(r, 2000 * (_tentativo + 1)));
      return _leggiNomeDaCardmarket(urlNome, lingua, condizione, oloType, firstEd, _tentativo + 1, tabIdEsterno, requestId);
    }
    return { nome: null, codice: null, prezzo: null, urlSingles: null };
  }

  return { nome: nomefinale, codice, prezzo: risPrez.prezzo, urlSingles, immagine: fase1.immagine || risPrez.immagine || null };
}


// ── FETCH HTML STATICO ────────────────────────────────────────────────────────
// Scarica l'HTML grezzo di url senza aprire tab (niente JS/CSS/immagini).
async function _fetchHtml(url) {
  try {
    const r = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml',
        'Accept-Language': 'it-IT,it;q=0.9,en;q=0.8',
      },
      // FIX: era 'omit' — niente cookie mandati MAI, nemmeno cf_clearance.
      // Cloudflare imposta cf_clearance quando risolvi manualmente la sfida
      // in una tab reale (fallback), ma con 'omit' quel cookie non veniva
      // mai riusato dalle fetch statiche successive: ogni nuova carta del
      // bulk ripartiva "anonima" agli occhi di Cloudflare e veniva
      // ribloccata da capo, costringendo ad aprire una tab e risolvere di
      // nuovo per OGNI carta invece che una volta sola per sessione.
      // 'include' fa sì che, una volta risolta la sfida, cf_clearance venga
      // inviato anche dalle fetch statiche successive — niente più sfide
      // ripetute a raffica. Richiede host_permissions su cardmarket.com,
      // già presente in manifest.json.
      credentials: 'include',
    });
    if (!r.ok) return null;
    return await r.text();
  } catch (_) { return null; }
}

// Estrae i link /Products/ (escluso /Singles/) dall'HTML grezzo di una pagina /Search?.
// I prodotti sealed stanno sotto percorsi come /Products/Sealed/, /Products/Displays/,
// /Products/Tins/, ecc. — tutti sotto /Products/ ma non /Singles/.
// FIX "non trova più risultati": Cardmarket può servire gli href sia assoluti
// (https://www.cardmarket.com/it/...) sia relativi (/it/...) — prima la regex
// richiedeva SEMPRE il dominio completo, quindi se il sito passava (anche solo
// in alcune pagine/varianti) a link relativi, l'estrazione trovava zero
// risultati pur essendo la pagina piena di prodotti. Ora il dominio è opzionale
// e viene riaggiunto in normalizzazione.
function _estraiLinkSealed(html) {
  const re = /href="(?:https:\/\/www\.cardmarket\.com)?(\/[a-z]{2}\/[^/]+\/Products\/(?!Singles\/)[^"?]+)"/gi;
  const trovati = new Set();
  let m;
  while ((m = re.exec(html)) !== null) {
    // Esclude pagine di categoria (solo 2 segmenti dopo /Products/): teniamo solo le pagine prodotto
    const path = m[1].split('/Products/')[1] || '';
    if (path.split('/').length >= 2) trovati.add('https://www.cardmarket.com' + m[1]);
  }
  return Array.from(trovati);
}

// FIX disambiguazione sealed troppo aggressiva: prima, appena la ricerca
// restituiva più di un link prodotto, si finiva SEMPRE nel pannello di
// correzione manuale — anche quando uno dei risultati corrispondeva
// chiaramente al nome cercato (es. "First Partner Illustration Collection
// Series 2", che su Cardmarket può comparire insieme a prodotti correlati
// con nomi simili). A differenza delle carte singole (che hanno un codice
// set univoco da matchare), i prodotti sealed vanno confrontati solo per
// nome — la condizione non si applica (Cardmarket ha solo "Mint" per i
// sealed) e la lingua viene già gestita a parte da _aggiungiLinguaSealed.
// Questa funzione prova un match esatto (o quasi) dello slug sul testo
// cercato prima di arrendersi alla disambiguazione manuale.
function _trovaMatchSealed(links, searchString) {
  if (links.length <= 1) return links[0] || null;
  if (!searchString) return null; // nessun testo su cui basare la scelta

  const norm = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, '');
  const qNorm = norm(searchString);
  if (!qNorm) return null;
  const slugNorm = (u) => norm((u.split('/').pop() || '').replace(/-/g, ' '));

  // 1. Match esatto: slug normalizzato identico alla query normalizzata.
  let candidati = links.filter(u => slugNorm(u) === qNorm);
  if (candidati.length === 1) return candidati[0];

  // 2. Match "contiene": lo slug include per intero il testo cercato
  //    (capita quando Cardmarket aggiunge suffissi tipo edizione/lingua).
  candidati = links.filter(u => slugNorm(u).includes(qNorm));
  if (candidati.length === 1) return candidati[0];

  return null; // ambiguità reale, nessun match univoco
}

// Distingue "codice" (nessuno spazio, es. "SV01006") da "nome + numero" (con
// spazio, es. "Eevee 55" o "Mew 8") e verifica SEMPRE la corrispondenza dello
// slug con la query, anche quando c'è un solo link candidato.
// FIX (bug "MEW 8" → apriva Wartortle): prima, se Cardmarket restituiva UN
// SOLO link (anche del tutto estraneo alla query cercata, per via della
// ricerca full-text lato sito), veniva accettato senza alcun controllo — un
// singolo risultato bastava per "vincere" a prescindere da cosa fosse
// davvero. Ora un risultato singolo viene accettato solo se la sua slug
// corrisponde realmente alla query (codice esatto, oppure nome+numero
// combinati); altrimenti si va in correzione manuale invece di salvare la
// carta sbagliata.
function _trovaMatchCartaSingola(links, searchString) {
  console.log('[CardSync] match check:', { query: searchString, links });
  const slugNorm = (u) => (u.split('/').pop() || '').toLowerCase().replace(/\s/g, '');

  // FIX (bug "MEW 8" → apriva Wartortle): l'ULTIMO segmento dello slug è
  // sempre {codiceSet}{numero} incollati (es. "MEW008" per il set "Pokémon
  // 151", che su Cardmarket usa proprio "MEW" come sigla ufficiale — non ha
  // niente a che fare col nome carta "Mew"). Confrontare il testo cercato
  // contro l'INTERO slug faceva sì che il codice-set stesso "contenesse" per
  // pura coincidenza il nome cercato (qui "mew" dentro "...-MEW008"),
  // producendo falsi positivi su carte completamente diverse. Ora il
  // confronto testo avviene SOLO sulla parte "nome" dello slug (tutti i
  // segmenti tranne l'ultimo — che può includere anche un marcatore
  // variante tipo "-V1-"), mai sul codice-set+numero finale. Il numero
  // atteso viene letto SOLO dalle cifre finali dell'ultimo segmento.
  const nomePortion = (u) => {
    const segs = (u.split('/').pop() || '').split('-');
    return (segs.length > 1 ? segs.slice(0, -1).join('') : segs[0] || '').toLowerCase();
  };
  const ultimoSegmento = (u) => {
    const segs = (u.split('/').pop() || '').split('-');
    return segs[segs.length - 1] || '';
  };

  const q = (searchString || '').trim();

  if (!q) {
    if (links.length === 1) return { match: links[0] };
    if (links.length > 1)   return { disambiguation: true, opzioni: links };
    return { match: null };
  }

  const isCodice = !/\s/.test(q); // nessuno spazio → codice set
  const qNorm = q.replace(/\s/g, '').toLowerCase();

  if (isCodice) {
    const exact = links.filter(u => slugNorm(u).endsWith(qNorm));
    if (exact.length === 1) return { match: exact[0] };
    if (exact.length > 1)   return { disambiguation: true, opzioni: exact };
    if (links.length > 1)   return { disambiguation: true, opzioni: links };
    // FIX (bug "carte vecchie non trovate", es. FST095 → Cardmarket
    // restituisce .../Singles/Fusion-Strike/Tynamo, SENZA alcun codice set
    // o numero nello slug): alcune espansioni più datate non includono
    // affatto il codice nello slug URL — solo il nome carta. In quel caso
    // lo slug non potrà MAI corrispondere al codice cercato, indipendente-
    // mente da quanto sia corretto il link, e il controllo sopra scarterebbe
    // sempre una carta perfettamente valida. Se Cardmarket ha restituito
    // UN SOLO risultato per la ricerca, invece di arrenderci alla cieca
    // segnaliamo al chiamante un "candidato da verificare sulla pagina
    // reale": il chiamante lo apre e conferma leggendo il codice EFFETTIVO
    // dall'h1 della pagina prodotto (fonte più affidabile dello slug),
    // accettandolo solo se il codice combacia davvero.
    if (links.length === 1) {
      return { verificaCandidato: links[0], tipoVerifica: 'codice', qNorm };
    }
    return { match: null }; // nessun link trovato
  }

  // ── formato "nome + numero" ──
  const parts = q.split(/\s+/);
  const numPart = parts.find(p => /^\d+$/.test(p));
  const textParts = parts.filter(p => !/^\d+$/.test(p)).map(p => p.toLowerCase());
  if (numPart && textParts.length > 0) {
    const numNorm = numPart.replace(/^0+/, '') || numPart;
    const textNorm = textParts.join('');
    const byNameAndNum = links.filter(u => {
      const hasText = nomePortion(u).includes(textNorm);
      const numMatch = ultimoSegmento(u).match(/(\d+)$/);
      const hasNum = numMatch && numMatch[1].replace(/^0+/, '') === numNorm;
      return hasText && hasNum;
    });
    if (byNameAndNum.length === 1) return { match: byNameAndNum[0] };
    if (byNameAndNum.length > 1)   return { disambiguation: true, opzioni: byNameAndNum };
  }
  if (links.length > 1) return { disambiguation: true, opzioni: links };
  // Stesso fallback di verifica-su-pagina-reale del ramo "codice" sopra,
  // per carte vecchie in formato "nome + numero" il cui slug non contiene
  // affatto il numero (o non nel formato atteso).
  if (links.length === 1 && numPart && textParts.length > 0) {
    return { verificaCandidato: links[0], tipoVerifica: 'nomeNumero', numNorm: numPart.replace(/^0+/, '') || numPart, textNorm: textParts.join('') };
  }
  return { match: null }; // un solo link ma nome+numero non confermati → NON accettarlo
}

// Verifica un candidato "incerto" (slug senza codice/numero riconoscibile,
// tipico di espansioni datate) leggendo il CODICE reale dall'h1 della sua
// pagina prodotto — molto più affidabile di qualunque euristica sullo slug.
// Restituisce true solo se il codice/numero trovato sulla pagina combacia
// davvero con quello cercato; false in ogni altro caso (pagina irraggiungibile,
// nessun codice estratto, o codice diverso) — mai un'accettazione "al buio".
async function _verificaCandidatoSuPagina(url, tipoVerifica, dati) {
  const html = await _fetchHtml(url);
  if (!html) return { ok: false };
  const { nome, codice } = _estraiNomeDaHtml(html);
  if (tipoVerifica === 'codice') {
    const codiceNorm = (codice || '').toUpperCase().replace(/\s+/g, '');
    if (!codiceNorm) return { ok: false };
    const match = codiceNorm === dati.qNorm.toUpperCase()
      || codiceNorm.endsWith(dati.qNorm.toUpperCase())
      || dati.qNorm.toUpperCase().endsWith(codiceNorm);
    return { ok: match, html, nome, codice };
  }
  // tipoVerifica === 'nomeNumero'
  const nomeNorm = (nome || '').toUpperCase().replace(/\s+/g, '');
  const codiceNorm = (codice || '').toUpperCase().replace(/\s+/g, '');
  const numMatch = codiceNorm.match(/(\d+)$/);
  const numPagina = numMatch ? numMatch[1].replace(/^0+/, '') || numMatch[1] : null;
  const hasNum = numPagina !== null && numPagina === dati.numNorm;
  const hasText = nomeNorm.includes(dati.textNorm.toUpperCase());
  return { ok: hasNum && hasText, html, nome, codice };
}

// Legge il prezzo dalla pagina prodotto sealed (tab aperta con polling).
// Cardmarket mostra il prezzo minimo dei venditori nella sezione .price-container.
function _leggiPrezzoSealed(urlProdotto, tabIdEsterno, requestId = null) {
  return new Promise(async (resolve) => {
    const { cfTimeoutMs, avvisoSonoro: _avvisoSonoro } = await _leggiOpzioniCf();
    // FIX (troppe tab in sequenza → Cloudflare): se il chiamante passa
    // tabIdEsterno (worker tab della sessione bulk), la navighiamo con
    // tabs.update invece di aprirne una nuova — vedi _prontaWorkerTabId in
    // testa al file. Se quella tab non esiste più (chiusa a mano), ne
    // apriamo una nuova al volo: il chiamante la registrerà come nuova
    // worker tab guardando il tabId nel risultato.
    const vogliamoRiusare = tabIdEsterno != null;

    function avviaCon(tab) {
      const tabId = tab.id;
      let caricata = false;
      let pollTimer, timeout;

      function chiudi(risultato) {
        clearInterval(pollTimer);
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(onLoad);
        // FIX: rimuove subito la voce dal watchdog persistente quando
        // l'attesa si risolve normalmente (prima della scadenza) — altrimenti
        // resterebbe li' fino alla sua scadenza naturale, tentando poi di
        // richiudere una tab gia' rimossa o riusata per qualcos'altro.
        _rimuoviAttesaCf(tabId);
        // FIX (troppe tab in sequenza → Cloudflare): se il chiamante vuole
        // riusare questa tab per tutta la sessione bulk, non la chiudiamo —
        // resta pronta per il prodotto successivo. Si chiude solo per le
        // chiamate "una tantum" (nessuna worker tab richiesta) o
        // esplicitamente a fine sessione (messaggio CHIUDI_WORKER_TAB).
        if (!vogliamoRiusare) chrome.tabs.remove(tabId, () => {});
        resolve({ ...risultato, tabId });
      }

      function tentaLettura() {
        if (!caricata) return;
        _touchRichiesta(requestId, tabId);
        chrome.scripting.executeScript({
          target: { tabId },
          args: [RATE_LIMIT_MARKERS, CF_TITLES],
          func: async (RATE_LIMIT_MARKERS, CF_TITLES) => {
            const testo = (document.title + ' ' + (document.body?.innerText?.slice(0, 2000) || '')).toLowerCase();
            if (RATE_LIMIT_MARKERS.some(m => testo.includes(m))) return { rateLimited: true };
            const title = document.title.toLowerCase();
            if (CF_TITLES.some(t => title.includes(t)) || document.querySelector('.cf-turnstile,#challenge-running'))
              return { cloudflare: true };
            // FIX: questa tab è già sulla pagina prodotto (ci arriviamo apposta
            // per leggere il prezzo) — è il punto giusto per estrarre anche
            // l'immagine, che prima non veniva mai letta qui.
            const metaImg = document.querySelector('meta[property="og:image"]');
            let immagine = metaImg ? metaImg.getAttribute('content') : null;
            // FIX: og:image per i sealed è spesso il logo generico del sito
            // invece della foto del prodotto. Le foto vere sono sempre su
            // product-images.s3.cardmarket.com — qualunque altro dominio
            // (es. static.cardmarket.com, dove vive il logo) va scartato a
            // prescindere dal path esatto. Se scartiamo, cerchiamo un <img>
            // reale nella pagina come fallback.
            if (immagine && !immagine.includes('product-images')) immagine = null;
            if (!immagine) {
              const imgReale = Array.from(document.querySelectorAll('img'))
                .map(i => i.src)
                .find(src => src && src.includes('product-images'));
              immagine = imgReale || null;
            }
            // FIX (bug "riga con nome vuoto sovrascritta dal prodotto
            // successivo"): questa tab è già sulla pagina prodotto — costo
            // zero per rileggere anche il nome, usato come rete di
            // sicurezza dal ricontrollo prezzo mancante (vedi chiamanti in
            // aggiungi_sealed_popup.js).
            let nomeDom = null;
            const h1 = document.querySelector('h1');
            if (h1) {
              const clone = h1.cloneNode(true);
              clone.querySelectorAll('span').forEach(s => s.remove());
              nomeDom = clone.textContent.trim() || null;
            }
            const selettori = ['.price-container .fw-bold', '.col-offer-price .fw-bold', '[class*="price"] .fw-bold', '.color-primary.fw-bold'];
            for (const sel of selettori) {
              const el = document.querySelector(sel);
              if (el && el.textContent.includes('€')) {
                const m = el.textContent.trim().match(/([\d,.]+)\s*€/);
                if (m) {
                  const p = parseFloat(m[1].replace(/\./g, '').replace(',', '.'));
                  return { prezzo: isNaN(p) ? null : p, immagine, nomeDom };
                }
              }
            }
            const rows = document.querySelectorAll('.article-row');
            if (rows.length === 0) return null; // non ancora caricato
            return { prezzo: null, immagine, nomeDom }; // caricato ma nessun prezzo
          },
        }, async (res) => {
          if (chrome.runtime.lastError) return;
          const val = res?.[0]?.result;
          if (val === null || val === undefined) return;
          if (val.rateLimited) { chiudi({ prezzo: null, rateLimited: true }); return; }
          if (val.cloudflare) {
            clearInterval(pollTimer);
            clearTimeout(timeout);
            chrome.tabs.onUpdated.removeListener(onLoad);
            _suonaEPortaInPrimoPiano(tabId, _avvisoSonoro, 'sealed');
            // FIX: registra questa attesa nel watchdog persistente (vedi
            // _registraAttesaCf) — garantisce che la tab venga chiusa entro
            // il tempo configurato anche se il service worker si riavvia a
            // meta' dell'attesa e perde lo stato/i timer locali qui sotto.
            _registraAttesaCf(tabId, cfTimeoutMs / 60000);
            const _cfDeadline = Date.now() + cfTimeoutMs;
            function aspettaRisoluzione() {
              // FIX (bug "resta bloccato su una carta"): aggiorna l'heartbeat
              // a ogni ciclo dell'attesa Cloudflare — è qui che le sessioni
              // restano bloccate più a lungo (fino a 10 minuti configurabili).
              _touchRichiesta(requestId, tabId);
              if (Date.now() > _cfDeadline) { chiudi({ prezzo: null, cloudflareTimeout: true }); return; }
              chrome.scripting.executeScript({
                target: { tabId }, args: [CF_TITLES],
                func: (CF_TITLES) => {
                  const title = document.title.toLowerCase();
                  return (CF_TITLES.some(t => title.includes(t)) || !!document.querySelector('.cf-turnstile,#challenge-running')) ? 'cf' : 'ok';
                },
              }, (res) => {
                if (chrome.runtime.lastError) { chiudi({ prezzo: null, cloudflareTimeout: true }); return; }
                if (res?.[0]?.result === 'ok') {
                  caricata = true;
                  pollTimer = setInterval(tentaLettura, 600);
                  timeout = setTimeout(() => chiudi({ prezzo: null, immagine: null }), 15000);
                  chrome.tabs.onUpdated.addListener(onLoad);
                } else { setTimeout(aspettaRisoluzione, 1500); }
              });
            }
            setTimeout(aspettaRisoluzione, 2000);
            return;
          }
          chiudi({ prezzo: val.prezzo ?? null, immagine: await _immagineAUrlDati(val.immagine || null), nome: val.nomeDom || null });
        });
      }

      function onLoad(id, info) {
        if (id === tabId && info.status === 'complete') { caricata = true; }
      }

      chrome.tabs.onUpdated.addListener(onLoad);
      pollTimer = setInterval(tentaLettura, 600);
      timeout = setTimeout(() => chiudi({ prezzo: null, immagine: null }), 15000);
    }

    if (vogliamoRiusare) {
      chrome.tabs.update(tabIdEsterno, { url: urlProdotto }, (tab) => {
        if (chrome.runtime.lastError || !tab) {
          chrome.tabs.create({ url: urlProdotto, active: false }, avviaCon);
        } else {
          avviaCon(tab);
        }
      });
    } else {
      chrome.tabs.create({ url: urlProdotto, active: false }, avviaCon);
    }
  });
}

// Fetch + estrazione per un prodotto sealed: cerca link /Products/ (non /Singles/)
// nell'HTML della pagina di ricerca, poi legge nome dall'h1 della pagina prodotto.
async function _leggiNomeSealedFetch(urlNome, lingua) {
  const html = await _fetchHtml(urlNome);
  if (!html) return { urlProdotto: null, nome: null, fetchFailed: true };
  const lower = html.toLowerCase();
  if (isPaginaRateLimit(lower)) return { urlProdotto: null, nome: null, rateLimited: true };
  const isCF = CF_TITLES.some(t => lower.includes(t)) || lower.includes('cf-turnstile') || lower.includes('challenge-running');
  if (isCF) return { urlProdotto: null, nome: null, cloudflare: true };

  // Se l'URL è già una pagina prodotto (non una ricerca), estrai subito il nome
  if (!urlNome.includes('/Search')) {
    const { nome } = _estraiNomeDaHtml(html);
    const immagine = await _estraiImmagineDaHtml(html);
    // FIX: prima si faceva .split('?')[0] scartando anche un eventuale
    // ?language= già presente nell'URL passato — ora si riapplica sempre
    // in modo esplicito con la lingua richiesta.
    const urlProdotto = _aggiungiLinguaSealed(urlNome.split('?')[0], lingua);
    return { urlProdotto, nome: _rimuoviCategoriaDalNome(nome, urlProdotto), immagine };
  }

  const links = _estraiLinkSealed(html);
  if (links.length === 0) return { urlProdotto: null, nome: null };

  let urlProdottoBase;
  if (links.length === 1) {
    urlProdottoBase = links[0];
  } else {
    const searchString = (() => {
      try { return new URL(urlNome).searchParams.get('searchString') || ''; } catch (_) { return ''; }
    })();
    const match = _trovaMatchSealed(links, searchString);
    if (!match) {
      const slugLabel = (u) => (u.split('/').pop() || '').replace(/-/g, ' ').trim();
      return { urlProdotto: null, nome: null, disambiguation: true, opzioni: links.map(u => ({ urlSingles: u, label: slugLabel(u) })) };
    }
    urlProdottoBase = match;
  }

  const htmlProd = await _fetchHtml(urlProdottoBase);
  const { nome } = htmlProd ? _estraiNomeDaHtml(htmlProd) : { nome: null };
  const immagine = htmlProd ? await _estraiImmagineDaHtml(htmlProd) : null;
  // FIX: qui prima urlProdotto restava "nudo" (senza ?language=), quindi la
  // pagina del prodotto veniva aperta senza alcun filtro lingua.
  const urlProdotto = _aggiungiLinguaSealed(urlProdottoBase, lingua);
  return { urlProdotto, nome: _rimuoviCategoriaDalNome(nome, urlProdotto), immagine };
}

// Cardmarket a volte include nell'<h1> della pagina prodotto anche la
// categoria (es. "Box Sets", "Boosters", "Tins") insieme al nome vero e
// proprio — sia che venga letta col span-stripping del fetch statico, sia
// (soprattutto) leggendo il textContent grezzo dell'h1 via tab. Questa
// funzione ricava la categoria dallo slug URL (es. /Products/Box-Sets/...
// → "BOX SETS") e la toglie dal nome ovunque compaia (prefisso o suffisso),
// così il fix vale per qualsiasi categoria, non solo "Box Sets".
function _rimuoviCategoriaDalNome(nome, urlProdotto) {
  if (!nome || !urlProdotto) return nome;
  let path;
  try { path = new URL(urlProdotto).pathname; } catch (_) { return nome; }
  const segmentoCategoria = (path.split('/Products/')[1] || '').split('/')[0] || '';
  const categoriaLabel = segmentoCategoria.replace(/-/g, ' ').trim().toUpperCase();
  if (!categoriaLabel) return nome;
  const escaped = categoriaLabel.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re = new RegExp('(^|\\s)' + escaped + '(\\s|$)', 'i');
  return nome.replace(re, ' ').replace(/\s+/g, ' ').trim() || nome;
}

// Aggiunge (o sostituisce) il parametro ?language=ID sulla URL di un PRODOTTO
// sealed già risolto — MAI sulla URL di ricerca (/Products/Search), che lo
// ignora sempre. A differenza delle Singles, i sealed non hanno minCondition
// (esiste solo "Mint"), quindi qui filtriamo solo la lingua.
// FIX: prima la lingua veniva messa solo sull'URL di ricerca (ignorato da
// Cardmarket) e mai riapplicata all'URL del prodotto trovato → il filtro
// spariva nel passaggio ricerca→prodotto.
function _aggiungiLinguaSealed(urlProdotto, lingua) {
  if (!urlProdotto) return urlProdotto;
  let url = urlProdotto
    .replace(/[?&]language=[^&]*/g, '')
    .replace(/[?&]idLanguage=[^&]*/g, '')
    .replace(/\?&/, '?').replace(/&&+/g, '&').replace(/[?&]$/, '');
  const idLingua = LINGUA_MAP_SHARED[(lingua || 'IT').toUpperCase().trim()];
  if (!idLingua) return url;
  return url + (url.includes('?') ? '&' : '?') + 'language=' + idLingua;
}

// Orchestratore sealed: fetch → prezzo via tab → fallback tab se Cloudflare
// O SE il fetch statico restituisce zero risultati. Quest'ultimo caso è
// gestito a parte perché, a differenza della ricerca Singles (i cui risultati
// sono renderizzati server-side), la pagina di ricerca prodotti Sealed sembra
// iniettare i risultati via JS: un fetch senza rendering JS può quindi
// legittimamente vedere "zero link" anche quando il prodotto esiste davvero.
// Senza questo fallback, quei prodotti risultavano sempre "non trovati".
async function _leggiNomeSealedDaCardmarket(urlNome, lingua, _tentativo = 0, tabIdEsterno = null, requestId = null) {
  const fase1 = await _leggiNomeSealedFetch(urlNome, lingua);

  if (fase1.rateLimited) return { nome: null, urlProdotto: null, prezzo: null, immagine: null, rateLimited: true };
  if (fase1.disambiguation) return { nome: null, urlProdotto: null, prezzo: null, immagine: null, disambiguation: true, opzioni: fase1.opzioni || [] };

  const zeroRisultatiDaFetch = !fase1.cloudflare && !fase1.fetchFailed && !fase1.urlProdotto;

  if (fase1.cloudflare || fase1.fetchFailed || zeroRisultatiDaFetch) {
    const viaTab = await _risolviProdottoSealedTab(urlNome, lingua, tabIdEsterno, requestId);
    // FIX (worker tab about:blank mai usata): se la worker tab passata non
    // era più valida, _risolviProdottoSealedTab ne ha aperta una nuova al
    // volo — aggiorniamo subito lo storage così i prodotti successivi della
    // stessa sessione bulk la trovano e la riusano.
    if (tabIdEsterno != null && viaTab && viaTab.tabId && viaTab.tabId !== tabIdEsterno) {
      await _salvaWorkerTabId('sealed', viaTab.tabId);
      tabIdEsterno = viaTab.tabId;
    }

    if (viaTab.rateLimited) return { nome: null, urlProdotto: null, prezzo: null, immagine: null, rateLimited: true };
    if (viaTab.disambiguation) return { nome: null, urlProdotto: null, prezzo: null, immagine: null, disambiguation: true, opzioni: viaTab.opzioni || [] };

    if (viaTab.urlProdotto) {
      const risPrez = await _leggiPrezzoSealed(viaTab.urlProdotto, tabIdEsterno, requestId);
      if (tabIdEsterno != null && risPrez.tabId && risPrez.tabId !== tabIdEsterno) {
        await _salvaWorkerTabId('sealed', risPrez.tabId);
        tabIdEsterno = risPrez.tabId;
      }
      if (risPrez.rateLimited) return { nome: null, urlProdotto: null, prezzo: null, immagine: null, rateLimited: true };
      // FIX: quando la scelta del prodotto avviene dalla pagina di ricerca
      // (risultati iniettati via JS — il caso più comune), viaTab.immagine è
      // sempre null perché quella tab non naviga fino alla pagina prodotto.
      // La tab aperta da _leggiPrezzoSealed invece ci arriva davvero: usiamo
      // la sua immagine come fallback.
      // FIX (bug "riga con nome vuoto sovrascritta dal prodotto successivo"):
      // stesso discorso per il nome — se viaTab non l'ha ottenuto (capita
      // quando si parte dalla lista risultati, senza mai navigare alla
      // pagina prodotto), usiamo quello riletto da _leggiPrezzoSealed, che
      // quella pagina la visita per forza. Nessuna tab in più: è la stessa
      // già aperta per il prezzo.
      const nomeFinale = _rimuoviCategoriaDalNome(viaTab.nome || risPrez.nome, viaTab.urlProdotto);
      return { nome: nomeFinale, urlProdotto: viaTab.urlProdotto, prezzo: risPrez.prezzo ?? null, immagine: viaTab.immagine || risPrez.immagine || null };
    }

    // Anche la tab reale non ha trovato nulla: qui è davvero "non trovato",
    // ma concediamo ancora un paio di retry per coprire lentezza di rete/rendering.
    if (_tentativo < BULK_MAX_RETRY) {
      await new Promise(r => setTimeout(r, 3000 * (_tentativo + 1)));
      return _leggiNomeSealedDaCardmarket(urlNome, lingua, _tentativo + 1, tabIdEsterno, requestId);
    }
    return { nome: null, urlProdotto: null, prezzo: null, immagine: null };
  }

  // Leggi il prezzo dalla pagina prodotto (tab) — urlProdotto già noto dal fetch statico
  const risPrez = await _leggiPrezzoSealed(fase1.urlProdotto, tabIdEsterno, requestId);
  if (tabIdEsterno != null && risPrez.tabId && risPrez.tabId !== tabIdEsterno) {
    await _salvaWorkerTabId('sealed', risPrez.tabId);
  }
  if (risPrez.rateLimited) return { nome: null, urlProdotto: null, prezzo: null, immagine: null, rateLimited: true };

  // FIX: stessa rete di sicurezza del ramo via-tab qui sopra — se il fetch
  // statico non è riuscito a estrarre il nome, usa quello riletto dalla tab
  // già aperta per il prezzo invece di lasciare la riga senza nome.
  const nomeFinale = _rimuoviCategoriaDalNome(fase1.nome || risPrez.nome, fase1.urlProdotto);
  return { nome: nomeFinale, urlProdotto: fase1.urlProdotto, prezzo: risPrez.prezzo ?? null, immagine: fase1.immagine || risPrez.immagine || null };
}

// Risolve il link prodotto sealed aprendo una tab REALE (con rendering JS),
// usata come fallback quando il fetch statico non basta (Cloudflare, errore
// di rete, o pagina di ricerca coi risultati iniettati via JS).
function _risolviProdottoSealedTab(urlNome, lingua, tabIdEsterno = null, requestId = null) {
  return new Promise(async (resolve) => {
    const { cfTimeoutMs, avvisoSonoro: _avvisoSonoro } = await _leggiOpzioniCf();
    // FIX (worker tab about:blank mai usata): stesso fix di
    // _risolviNomeEPrezzoUnicaTab — questo fallback apriva sempre una tab
    // nuova, ignorando la worker tab della sessione bulk passata dal
    // chiamante.
    const vogliamoRiusare = tabIdEsterno != null;

    function avviaCon(tab) {
      const tabId = tab.id;
      let caricata = false;
      let pollTimer, timeout;

      function chiudi(risultato) {
        clearInterval(pollTimer);
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(onLoad);
        // FIX: rimuove subito la voce dal watchdog persistente quando
        // l'attesa si risolve normalmente (prima della scadenza) — altrimenti
        // resterebbe li' fino alla sua scadenza naturale, tentando poi di
        // richiudere una tab gia' rimossa o riusata per qualcos'altro.
        _rimuoviAttesaCf(tabId);
        // FIX (worker tab about:blank mai usata): non chiudere la tab se va
        // riusata per il resto della sessione bulk.
        if (!vogliamoRiusare) chrome.tabs.remove(tabId, () => {});
        resolve({ ...risultato, tabId });
      }

      function tentaLettura() {
        if (!caricata) return;
        _touchRichiesta(requestId, tabId);
        chrome.scripting.executeScript({
          target: { tabId },
          args: [CF_TITLES],
          func: async (CF_TITLES) => {
            const testo = (document.title + ' ' + (document.body?.innerText?.slice(0, 2000) || '')).toLowerCase();
            if (testo.includes('error 1015') || testo.includes('you are being rate limited')) return { rateLimited: true };

            const title = document.title.toLowerCase();
            const isCloudflare = CF_TITLES.some(t => title.includes(t))
              || !!document.querySelector('.cf-turnstile, #challenge-running, #challenge-form, #cf-challenge-running');
            if (isCloudflare) return { cloudflare: true };

            const path = window.location.pathname;

            // Caso A: redirect diretto a una pagina prodotto (risultato unico)
            if (path.includes('/Products/') && !path.includes('/Products/Search')) {
              const h1 = document.querySelector('h1');
              let nome = null;
              if (h1) {
                // Come nel fetch statico: rimuove eventuali span (badge/etichette)
                // annidati nell'h1 prima di leggere il testo.
                const clone = h1.cloneNode(true);
                clone.querySelectorAll('span').forEach(s => s.remove());
                nome = clone.textContent.trim();
              }
              const metaImg = document.querySelector('meta[property="og:image"]');
              let immagine = metaImg ? metaImg.getAttribute('content') : null;
              // FIX: vedi commento analogo in _leggiPrezzoSealed — og:image per
              // i sealed è spesso il logo generico, non la foto del prodotto.
              // Accettiamo solo URL dal dominio delle foto reali; altrimenti
              // proviamo a pescare un <img> reale dalla pagina.
              if (immagine && !immagine.includes('product-images')) immagine = null;
              if (!immagine) {
                const imgReale = Array.from(document.querySelectorAll('img'))
                  .map(i => i.src)
                  .find(src => src && src.includes('product-images'));
                immagine = imgReale || null;
              }
              // Ripulisce comunque l'eventuale categoria residua (es. "Box Sets")
              // non racchiusa in uno <span>, ricavandola dallo slug dell'URL.
              return { urlProdotto: location.origin + path, nome, immagine, _path: path };
            }

            // Caso B: pagina di ricerca → estrai i link a prodotti (esclude /Singles/)
            const tuttiLink = Array.from(document.querySelectorAll('a[href*="/Products/"]'))
              .filter(a => !a.pathname.includes('/Products/Singles/'))
              .filter(a => (a.pathname.split('/Products/')[1] || '').split('/').filter(Boolean).length >= 2);
            const unici = Array.from(new Set(tuttiLink.map(a => a.origin + a.pathname)));

            if (unici.length === 0) return undefined; // non ancora renderizzato → il polling riprova

            // FIX disambiguazione troppo aggressiva: come nel percorso fetch
            // statico (_trovaMatchSealed in background.js — qui reimplementato
            // inline perché executeScript non può referenziare funzioni esterne),
            // prova prima un match per nome sul testo cercato prima di arrendersi
            // alla disambiguazione manuale.
            let scelto;
            if (unici.length === 1) {
              scelto = unici[0];
            } else {
              const norm = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, '');
              const slugNorm = (u) => norm((u.split('/').pop() || '').replace(/-/g, ' '));
              const searchString = new URLSearchParams(window.location.search).get('searchString') || '';
              const qNorm = norm(searchString);
              if (qNorm) {
                let candidati = unici.filter(u => slugNorm(u) === qNorm);
                if (candidati.length === 1) scelto = candidati[0];
                else {
                  candidati = unici.filter(u => slugNorm(u).includes(qNorm));
                  if (candidati.length === 1) scelto = candidati[0];
                }
              }
            }

            if (!scelto) {
              const slugLabel = (u) => (u.split('/').pop() || '').replace(/-/g, ' ').trim();
              return { disambiguation: true, opzioni: unici.map(u => ({ urlSingles: u, label: slugLabel(u) })) };
            }

            return { urlProdotto: scelto, nome: null };
          },
        }, async (results) => {
          if (chrome.runtime.lastError) return;
          const val = results?.[0]?.result;
          // FIX: chrome.scripting.executeScript puo' restituire result:null
          // (invece di undefined) quando lo script viene iniettato proprio mentre
          // la pagina sta navigando/reindirizzando (race condition nota di Chrome).
          // Con il solo controllo su undefined, un null passava indenne e il
          // successivo accesso a val.rateLimited andava in crash ("Cannot read
          // properties of null"). Ora si tratta null e undefined allo stesso modo:
          // 'non ancora pronto, il polling riprova'.
          if (val === undefined || val === null) return; // non pronto → riprova

          if (val.rateLimited) { chiudi({ urlProdotto: null, nome: null, rateLimited: true }); return; }

          if (val.cloudflare) {
            clearInterval(pollTimer);
            clearTimeout(timeout);
            chrome.tabs.onUpdated.removeListener(onLoad);
            _suonaEPortaInPrimoPiano(tabId, _avvisoSonoro, 'sealed');
            // FIX: registra questa attesa nel watchdog persistente (vedi
            // _registraAttesaCf) — garantisce che la tab venga chiusa entro
            // il tempo configurato anche se il service worker si riavvia a
            // meta' dell'attesa e perde lo stato/i timer locali qui sotto.
            _registraAttesaCf(tabId, cfTimeoutMs / 60000);
            const _cfDeadline = Date.now() + cfTimeoutMs;
            function aspettaRisoluzione() {
              // FIX (bug "resta bloccato su una carta"): vedi commento
              // analogo in _leggiPrezzoSealed.
              _touchRichiesta(requestId, tabId);
              if (Date.now() > _cfDeadline) { chiudi({ urlProdotto: null, nome: null, cloudflareTimeout: true }); return; }
              chrome.scripting.executeScript({
                target: { tabId }, args: [CF_TITLES],
                func: (CF_TITLES) => {
                  const title = document.title.toLowerCase();
                  return (CF_TITLES.some(t => title.includes(t)) || !!document.querySelector('.cf-turnstile,#challenge-running,#challenge-form,#cf-challenge-running')) ? 'cf' : 'ok';
                },
              }, (res) => {
                if (chrome.runtime.lastError) { chiudi({ urlProdotto: null, nome: null, cloudflareTimeout: true }); return; }
                if (res?.[0]?.result === 'ok') {
                  caricata = true;
                  pollTimer = setInterval(tentaLettura, 600);
                  timeout = setTimeout(() => chiudi({ urlProdotto: null, nome: null }), 15000);
                  chrome.tabs.onUpdated.addListener(onLoad);
                } else { setTimeout(aspettaRisoluzione, 1500); }
              });
            }
            setTimeout(aspettaRisoluzione, 2000);
            return;
          }

          if (val.disambiguation) { chiudi({ urlProdotto: null, nome: null, disambiguation: true, opzioni: val.opzioni }); return; }

          // FIX: come nel percorso fetch statico, la lingua va applicata qui
          // sull'URL del prodotto risolto — mai su quello di ricerca.
          const urlConLingua = _aggiungiLinguaSealed(val.urlProdotto, lingua);
          chiudi({
            urlProdotto: urlConLingua,
            nome: _rimuoviCategoriaDalNome(val.nome, urlConLingua),
            immagine: await _immagineAUrlDati(val.immagine || null),
          });
        });
      }

      function onLoad(id, info) { if (id === tabId && info.status === 'complete') caricata = true; }

      chrome.tabs.onUpdated.addListener(onLoad);
      pollTimer = setInterval(tentaLettura, 600);
      timeout = setTimeout(() => chiudi({ urlProdotto: null, nome: null }), 15000);
    }

    // FIX (worker tab about:blank mai usata): riusa la worker tab della
    // sessione, se passata — vedi commento analogo in
    // _risolviNomeEPrezzoUnicaTab più sopra.
    if (vogliamoRiusare) {
      chrome.tabs.update(tabIdEsterno, { url: urlNome }, (tab) => {
        if (chrome.runtime.lastError || !tab) {
          chrome.tabs.create({ url: urlNome, active: false }, avviaCon);
        } else {
          avviaCon(tab);
        }
      });
    } else {
      chrome.tabs.create({ url: urlNome, active: false }, avviaCon);
    }
  });
}


// FIX "non trova più risultati": stesso motivo di _estraiLinkSealed sopra —
// il dominio nell'href ora è opzionale, e viene riaggiunto qui in normalizzazione.
// Questa è la funzione usata dal flusso "aggiungi carta" (ricerca singole).
function _estraiLinkSingles(html) {
  const re = /href="(?:https:\/\/www\.cardmarket\.com)?(\/[a-z]{2}\/[^/]+\/Products\/Singles\/[^"?]+)"/gi;
  const trovati = new Set();
  let m;
  while ((m = re.exec(html)) !== null) {
    // FIX (bug "Dedenne-V1-DAA78" → apre .../Singles/Darkness-Ablaze troncato):
    // la pagina di ricerca include anche link "di sola espansione" tipo
    // .../Singles/Darkness-Ablaze (senza il nome carta) — stesso problema già
    // risolto per _estraiLinkSealed più sotto. Un link a una carta VERA ha
    // sempre almeno 2 segmenti dopo /Singles/: {Espansione}/{Nome-Carta-Numero}.
    // Senza questo filtro, il link spurio dell'espansione (che non contiene mai
    // "-Vn-") sopravvive al filtro "senzaVariante" più in basso ed esclude il
    // fallback che dovrebbe recuperare il vero link della carta.
    const path = m[1].split('/Products/Singles/')[1] || '';
    if (path.split('/').filter(Boolean).length >= 2) {
      trovati.add('https://www.cardmarket.com' + m[1]);
    }
  }
  return Array.from(trovati);
}

// Estrae l'URL dell'immagine principale della carta dall'HTML statico di /Singles/.
// Cardmarket inserisce l'immagine nel tag <meta property="og:image"> nell'<head>,
// presente nellHTML server-side (verificato dal DOM reale 2025-06).
// Esempio: https://product-images.s3.cardmarket.com/51/CBB3C/850277/850277.jpg
// Logo generico usato da Cardmarket come og:image quando il prodotto non ha
// ancora una foto reale caricata, o — caso frequente per i SEALED — quando
// og:image punta semplicemente al logo del sito invece che alla foto del
// prodotto. Va escluso, altrimenti finisce salvato come se fosse la foto
// del prodotto.
//
// FIX: prima si escludeva solo un path specifico del logo
// ('static.cardmarket.com/img/logos/'). Se Cardmarket serve il logo da un
// path leggermente diverso il controllo non lo intercetta e passa comunque
// (bug osservato sui sealed: veniva salvato il logo al posto della foto).
// Regola più robusta: le foto REALI dei prodotti sono sempre servite dal
// dominio product-images.s3.cardmarket.com — qualunque altro dominio
// (incluso static.cardmarket.com, dove vive il logo) non è mai una foto
// prodotto vera, indipendentemente dal path esatto.
const PLACEHOLDER_IMG_MARKERS = ['static.cardmarket.com/img/logos/'];

function _eImmagineSegnaposto(url) {
  if (!url) return true;
  if (!url.includes('product-images')) return true;
  return PLACEHOLDER_IMG_MARKERS.some(m => url.includes(m));
}

async function _estraiImmagineDaHtml(html) {
  const m =
    html.match(/property="og:image"\s+content="(https:\/\/[^"]*cardmarket[^"]*\.(?:jpg|png|webp|jpeg))"/) ||
    html.match(/content="(https:\/\/[^"]*cardmarket[^"]*\.(?:jpg|png|webp|jpeg))"\s+property="og:image"/) ||
    html.match(/property="og:image"\s+content="(https:\/\/product-images[^"]+)"/) ||
    html.match(/content="(https:\/\/product-images[^"]+)"\s+property="og:image"/);
  let url = m ? (m[1] || m[3] || null) : null;

  if (_eImmagineSegnaposto(url)) {
    // FIX sealed: og:image spesso è il logo generico invece della foto del
    // prodotto. La foto vera, quando esiste, compare comunque altrove
    // nell'HTML (galleria prodotto) servita da product-images.s3.cardmarket.com
    // — la cerchiamo direttamente lì come fallback.
    const fallback = html.match(/https:\/\/product-images\.s3\.cardmarket\.com\/[^"'\s)]+\.(?:jpg|png|webp|jpeg)/i);
    url = fallback ? fallback[0] : null;
  }

  if (_eImmagineSegnaposto(url)) return null;
  // FIX (immagine mai visibile sul sito): un URL esterno viene bloccato da
  // Cardmarket se richiesto da un dominio diverso (referer sbagliato) — qui
  // però il fetch di questa pagina è già partito da background.js, che ha
  // il privilegio di ignorare il CORS sui domini in host_permissions. Un
  // solo punto di conversione invece di ripeterlo nei 5 punti che chiamano
  // questa funzione.
  return _immagineAUrlDati(url);
}

// Estrae nome e codice dall'HTML statico di una pagina /Singles/.
// Cardmarket struttura il titolo come "Nome Carta (CodiceSet)" dove il codice
// è SEMPRE nell'ULTIMA coppia di parentesi. Carte come "Unown (V) (MEW 186)"
// devono restituire nome="UNOWN (V)" e codice="MEW 186".
//
// Eccezione: le Black Star Promo SV (SVP) hanno il codice ALL'INIZIO, es:
//   "(SVP en 011) Arcanine" → nome="ARCANINE", codice="SVP EN 011"
// In quel caso lastIndexOf('(') restituisce 0, la slice prima è vuota → nome null.
// Gestiamo questo fallback cercando la prima parentesi e usando il testo DOPO di essa.
function _estraiNomeDaHtml(html) {
  const m = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
  if (!m) return { nome: null, codice: null };
  const testo = m[1].replace(/<span[^>]*>[\s\S]*?<\/span>/gi, '').replace(/<[^>]+>/g, '').trim();
  // Trova l'ULTIMA coppia di parentesi → è sempre il codice set su Cardmarket
  const ultimaParentesiIdx = testo.lastIndexOf('(');
  if (ultimaParentesiIdx === -1) return { nome: testo.trim(), codice: null };
  const codiceRaw = testo.slice(ultimaParentesiIdx + 1, testo.lastIndexOf(')'));
  const codice = codiceRaw ? codiceRaw.trim().toUpperCase() : null;
  const nomePre = testo.slice(0, ultimaParentesiIdx).trim();
  // Caso promo: codice in testa → la parte prima è vuota, il nome è dopo la parentesi chiusa
  // Es: "(SVP EN 011) Arcanine" → nomePre='', nomePost='Arcanine'
  // Fallback aggiuntivo: se il nome dopo ')' è vuoto (raro ma possibile per alcune SVP),
  // estrai il testo dall'URL della pagina tramite il chiamante (qui restituiamo null
  // e il chiamante usa lo slug come fallback).
  if (!nomePre) {
    const chiusaIdx = testo.lastIndexOf(')');
    const nomePost = chiusaIdx !== -1 ? testo.slice(chiusaIdx + 1).trim() : null;
    // Se anche nomePost è vuoto, prova a prendere il testo PRIMA della prima '('
    // (caso estremo: titolo malformato tipo "(SVP EN 011)")
    if (!nomePost) {
      const primaParentesiIdx = testo.indexOf('(');
      const nomeAnte = primaParentesiIdx > 0 ? testo.slice(0, primaParentesiIdx).trim() : null;
      return { nome: nomeAnte || null, codice };
    }
    return { nome: nomePost, codice };
  }
  return { nome: nomePre, codice };
}

// Risolve urlSingles e nome via fetch puro (nessuna tab aperta).
//
// FIX (bug Dedenne-V1-DAA78 e simili): rimossa TUTTA la logica di
// esclusione/selezione basata sullo slug -V1-/-V2-/-V3- (OLO_SLUG_CHECK,
// OLO_SLUG, ramo 'ST'). Era pensata per distinguere varianti speciali
// (Pokéball/Masterball/Stamped) ma il parametro oloType, nel flusso reale
// dell'estensione, vale SEMPRE '' oppure 'RH' — mai 'PB'/'MB'/'ST'/'PR' —
// quindi quei rami non venivano mai eseguiti. L'unico effetto pratico era il
// filtro "senzaVariante" nel ramo else, che escludeva a priori qualunque link
// con "-Vn-" nello slug: quando quello slug corrispondeva all'UNICA stampa
// esistente della carta (es. Dedenne-V1-DAA78, Floragato-V2-CBB1C02), il link
// giusto veniva scartato e, se nella pagina restava un altro link innocuo
// (es. quello di sola espansione), l'estensione finiva per aprire quello
// sbagliato. La Reverse Holo non c'entra: viene riconosciuta a valle, sulla
// pagina prodotto, tramite il badge aria-label="Reverse Holo" sulla riga
// d'offerta (vedi rigaERH/rigaEd più sotto) — non tramite lo slug dell'URL.
// Ora si sceglie sempre tra TUTTI i link trovati, con lo stesso match esatto
// su codice/nome; se restano ambiguità reali si va in disambiguazione manuale.
async function _risolviSinglesENomeFetch(urlNome, oloType) {
  const html = await _fetchHtml(urlNome);
  console.log('[CardSync] fetch statico:', { urlNome, htmlRicevuto: !!html, lunghezza: html ? html.length : 0 });
  if (!html) return { urlSingles: null, nome: null, codice: null, fetchFailed: true };

  const lower = html.toLowerCase();
  if (isPaginaRateLimit(lower)) return { urlSingles: null, nome: null, codice: null, rateLimited: true };
  const isCF = CF_TITLES.some(t => lower.includes(t))
    || lower.includes('cf-turnstile') || lower.includes('challenge-running');
  console.log('[CardSync] cloudflare rilevato su fetch statico?', isCF);
  if (isCF) return { urlSingles: null, nome: null, codice: null, cloudflare: true };

  if (urlNome.includes('/Singles/')) {
    const { nome, codice } = _estraiNomeDaHtml(html);
    const immagine = await _estraiImmagineDaHtml(html);
    return { urlSingles: urlNome.split('?')[0], nome, codice, immagine };
  }

  const links = _estraiLinkSingles(html);
  console.log('[CardSync] link estratti dalla pagina di ricerca:', links);
  if (links.length === 0) return { urlSingles: null, nome: null, codice: null };

  const slugLabel = (u) => (u.split('/').pop() || '')
    .replace(/-V(\d+)-/gi, ' ★V$1 ').replace(/-/g,' ').trim();
  const toOpzione = (u) => ({ urlSingles: u, label: slugLabel(u) });

  // FIX (bug "MEW 8" → apriva Wartortle): vedi commento su
  // _trovaMatchCartaSingola. Non si accetta più un singolo link "a scatola
  // chiusa" — viene sempre verificato contro la query (codice esatto se
  // senza spazi, nome+numero combinati se con spazio).
  const searchString = (() => { try { return new URL(urlNome).searchParams.get('searchString') || ''; } catch(_) { return ''; } })();
  const esito = _trovaMatchCartaSingola(links, searchString);
  if (esito.disambiguation) {
    return { urlSingles: null, nome: null, codice: null, disambiguation: true, opzioni: esito.opzioni.map(toOpzione) };
  }

  // FIX (bug "carte vecchie non trovate", es. FST095 su Fusion Strike):
  // lo slug da solo non basta a confermare/negare questo candidato — l'unico
  // modo per saperlo davvero è leggere il codice dalla sua pagina prodotto
  // reale. La pagina viene comunque fetchata qui sotto (serve comunque per
  // nome/codice/immagine), quindi il costo è zero: nessuna richiesta extra
  // rispetto al percorso normale, solo una verifica in più prima di
  // accettare il link invece di scartarlo alla cieca in base al solo slug.
  if (esito.verificaCandidato) {
    const verifica = await _verificaCandidatoSuPagina(esito.verificaCandidato, esito.tipoVerifica, esito);
    if (!verifica.ok) {
      return { urlSingles: null, nome: null, codice: null };
    }
    const immagine = verifica.html ? await _estraiImmagineDaHtml(verifica.html) : null;
    return { urlSingles: esito.verificaCandidato, nome: verifica.nome, codice: verifica.codice, immagine };
  }

  if (!esito.match) {
    return { urlSingles: null, nome: null, codice: null };
  }
  const urlSingles = esito.match;

  const htmlSingles = await _fetchHtml(urlSingles);
  const { nome, codice } = htmlSingles ? _estraiNomeDaHtml(htmlSingles) : { nome: null, codice: null };
  const immagine = htmlSingles ? await _estraiImmagineDaHtml(htmlSingles) : null;
  return { urlSingles, nome, codice, immagine };
}

// FIX (pulizia codice morto): rimosse due funzioni intere mai chiamate
// da nessun punto del file — _risolviSinglesENome() (fallback via tab per
// sola risoluzione nome, senza prezzo) e _leggiNomeDaSingles() (apriva una
// tab a parte solo per leggere l'h1) — entrambe superate rispettivamente
// da _risolviNomeEPrezzoUnicaTab() (versione "fusa" risoluzione+prezzo in
// una sola tab, usata davvero dal fallback Cloudflare) e dalla lettura
// nome integrata direttamente nelle funzioni di risoluzione esistenti.
// Ognuna apriva una propria tab bypassando del tutto il riuso della
// worker tab — codice morto che, se mai richiamato per errore, avrebbe
// riportato il vecchio problema "troppe tab in sequenza" già risolto.

// ── RISOLUZIONE + PREZZO IN UN'UNICA TAB ──────────────────────────────────────
// Versione "fusa" del fallback: invece di aprire due tab sequenziali
// (_risolviSinglesENome poi _leggiPrezzoDaSingles), usa LA STESSA tab per
// entrambe le fasi. Dopo aver risolto nome/codice/urlSingles, naviga la tab
// già aperta (chrome.tabs.update) verso l'URL filtrato e fa polling per il prezzo.
// Dimezza il numero di navigazioni/tab aperte per carta nel caso di fallback.
function _risolviNomeEPrezzoUnicaTab(urlNome, lingua, condizione, oloType = '', firstEd = false, tabIdEsterno = null, requestId = null) {
  // Letta PRIMA della navigazione: se Cardmarket reindirizza subito a un
  // singolo risultato, window.location.search sulla pagina di arrivo può non
  // contenere più ?searchString= — serve il valore originale per poter
  // validare il redirect (vedi FIX "MEW 8" più sotto in tentaLetturaRisoluzione).
  const _searchStringOriginale = (() => {
    try { return new URL(urlNome).searchParams.get('searchString') || ''; } catch (_) { return ''; }
  })();
  const _eraRicerca = urlNome.includes('/Search');

  return new Promise(async (resolve) => {
    const { cfTimeoutMs, avvisoSonoro: _avvisoSonoro } = await _leggiOpzioniCf();
    // FIX (worker tab about:blank mai usata): questo fallback (Cloudflare o
    // fetch statico fallito) apriva SEMPRE una tab nuova con tabs.create,
    // ignorando del tutto la worker tab della sessione bulk passata dal
    // chiamante — la tab about:blank pre-creata restava inutilizzata e se
    // ne apriva una in più ogni volta che scattava questo fallback. Stesso
    // pattern di riuso già applicato a _leggiPrezzoDaSingles/_leggiPrezzoSealed.
    const vogliamoRiusare = tabIdEsterno != null;

    function avviaCon(tab) {
      const tabId = tab.id;
      let fase = 'risoluzione'; // 'risoluzione' → 'prezzo'
      let caricata = false;
      let pollTimer, timeout;
      let risolto = {}; // { nome, codice, urlSingles } una volta nota la fase 1
      let variantiRitentateSenzaFiltro = false; // evita loop: un solo retry senza filtro RH/1ED

      function chiudi(risultato) {
        clearInterval(pollTimer);
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(onLoad);
        // FIX: rimuove subito la voce dal watchdog persistente quando
        // l'attesa si risolve normalmente (prima della scadenza) — altrimenti
        // resterebbe li' fino alla sua scadenza naturale, tentando poi di
        // richiudere una tab gia' rimossa o riusata per qualcos'altro.
        _rimuoviAttesaCf(tabId);
        // FIX (worker tab about:blank mai usata): se il chiamante vuole
        // riusare questa tab per tutta la sessione bulk, non la chiudiamo —
        // resta pronta per la carta successiva. Si chiude solo per le
        // chiamate "una tantum" o esplicitamente a fine sessione
        // (messaggio CHIUDI_WORKER_TAB).
        if (!vogliamoRiusare) chrome.tabs.remove(tabId, () => {});
        resolve({ ...risultato, tabId });
      }

      function passaAFasePrezzo(urlSingles, ignoraVarianti) {
        // FIX: stesso bug del percorso fetch statico — senza applicare qui
        // isReverseHolo/isFirstEd, il polling prezzo su questa tab leggeva
        // sempre l'offerta della stampa normale per carte RH/1ED.
        // ignoraVarianti=true è usato dal fallback più sotto per le carte
        // "RH di base" (es. molte cinesi) dove il filtro nativo troverebbe
        // zero offerte perché non esiste una stampa normale da escludere.
        const base = costruisciUrlFiltrato(urlSingles, lingua, condizione);
        const urlConFiltri = ignoraVarianti ? base : _appendVariantParams(base, oloType, firstEd);
        fase = 'prezzo';
        caricata = false;
        clearTimeout(timeout);
        chrome.tabs.update(tabId, { url: urlConFiltri }, () => {
          if (chrome.runtime.lastError) {
            chiudi({ ...risolto, prezzo: null, immagine: null });
          }
        });
        timeout = setTimeout(() => chiudi({ ...risolto, prezzo: null, immagine: null }), 15000);
      }

      function tentaLetturaRisoluzione() {
        if (!caricata) return;
        _touchRichiesta(requestId, tabId);
        chrome.scripting.executeScript({
          target: { tabId },
          args: [oloType, CF_TITLES, _searchStringOriginale, _eraRicerca],
          func: (oloType, CF_TITLES, searchStringOriginale, eraRicerca) => {
            const title = document.title.toLowerCase();
            const corpoTesto = (title + ' ' + (document.body ? document.body.innerText.slice(0, 2000) : '')).toLowerCase();
            if (corpoTesto.includes('error 1015') || corpoTesto.includes('you are being rate limited')) {
              return { rateLimited: true };
            }
            const isCloudflare = CF_TITLES.some(t => title.includes(t))
              || !!document.querySelector('.cf-turnstile, #challenge-running, #challenge-form, #cf-challenge-running');
            if (isCloudflare) return { cloudflare: true };

            const path = window.location.pathname;

            if (path.includes('/Singles/')) {
              const h1 = document.querySelector('h1');
              if (!h1) return undefined;
              const clone = h1.cloneNode(true);
              clone.querySelectorAll('span').forEach(s => s.remove());
              const testo = clone.textContent.trim();
              const ultimaParentesiIdx = testo.lastIndexOf('(');
              let nome, codice;
              if (ultimaParentesiIdx === -1) {
                nome = testo; codice = null;
              } else {
                const codiceRaw = testo.slice(ultimaParentesiIdx + 1, testo.lastIndexOf(')')).trim().toUpperCase();
                codice = codiceRaw || null;
                const nomePre = testo.slice(0, ultimaParentesiIdx).trim();
                if (!nomePre) {
                  const chiusaIdx = testo.lastIndexOf(')');
                  const nomeDopoP = chiusaIdx !== -1 ? testo.slice(chiusaIdx + 1).trim() || null : null;
                  if (!nomeDopoP) {
                    const primaP = testo.indexOf('(');
                    nome = primaP > 0 ? testo.slice(0, primaP).trim() || null : null;
                  } else { nome = nomeDopoP; }
                } else { nome = nomePre; }
              }
              const urlSingles = location.origin + path;

              // FIX: rimosso il check sullo slug -V1-/-V2-/-V3- (PB/MB/ST) —
              // vedi commento esteso su _risolviSinglesENomeFetch.

              // FIX (bug "carte vecchie non trovate", es. FST095 su Fusion
              // Strike → Cardmarket restituisce/reindirizza a
              // .../Fusion-Strike/Tynamo, SENZA alcun codice o numero nello
              // slug): il controllo sotto verificava SOLO lo slug dell'URL —
              // ma alcune espansioni datate non includono affatto il codice
              // set+numero nello slug, quindi quel controllo falliva sempre
              // anche per il link perfettamente corretto, mandando in
              // correzione manuale carte valide. La variabile `codice` è
              // stata appena estratta qui sopra dall'h1 REALE della pagina —
              // molto più affidabile di un'euristica sullo slug — quindi la
              // verifichiamo PRIMA: se il codice reale combacia (o non
              // combacia chiaramente) con quello cercato, decidiamo subito
              // in base a quello. Solo se la pagina non riporta alcun codice
              // leggibile (raro, ma possibile per alcune promo) ricadiamo sul
              // vecchio controllo sullo slug.
              if (eraRicerca && searchStringOriginale) {
                const slug = urlSingles.split('/').pop() || '';
                const q = searchStringOriginale.trim();
                const isCodice = !/\s/.test(q);
                const codiceNormPagina = (codice || '').toUpperCase().replace(/\s+/g, '');

                if (isCodice) {
                  const qNormUp = q.replace(/\s/g, '').toUpperCase();
                  if (codiceNormPagina) {
                    const okCodice = codiceNormPagina === qNormUp
                      || codiceNormPagina.endsWith(qNormUp)
                      || qNormUp.endsWith(codiceNormPagina);
                    if (!okCodice) return { urlSingles: null, nome: null, codice: null };
                  } else {
                    const slugNorm = slug.toLowerCase().replace(/\s/g, '');
                    const qNorm = q.replace(/\s/g, '').toLowerCase();
                    if (!slugNorm.endsWith(qNorm)) return { urlSingles: null, nome: null, codice: null };
                  }
                } else {
                  const parts = q.split(/\s+/);
                  const numPart = parts.find(p => /^\d+$/.test(p));
                  const textParts = parts.filter(p => !/^\d+$/.test(p)).map(p => p.toLowerCase());
                  if (numPart && textParts.length > 0) {
                    const numNorm = numPart.replace(/^0+/, '') || numPart;
                    const textNorm = textParts.join('');
                    const numMatchPagina = codiceNormPagina.match(/(\d+)$/);
                    if (numMatchPagina) {
                      const numPagina = numMatchPagina[1].replace(/^0+/, '') || numMatchPagina[1];
                      const nomeNormPagina = (nome || '').toUpperCase().replace(/\s+/g, '');
                      const hasNum = numPagina === numNorm;
                      const hasText = nomeNormPagina.includes(textNorm.toUpperCase());
                      if (!(hasNum && hasText)) return { urlSingles: null, nome: null, codice: null };
                    } else {
                      const segs = slug.split('-');
                      const nomePortion = (segs.length > 1 ? segs.slice(0, -1).join('') : segs[0] || '').toLowerCase();
                      const ultimoSeg = segs[segs.length - 1] || '';
                      const numMatch = ultimoSeg.match(/(\d+)$/);
                      const hasText = nomePortion.includes(textNorm);
                      const hasNum = numMatch && numMatch[1].replace(/^0+/, '') === numNorm;
                      if (!(hasText && hasNum)) return { urlSingles: null, nome: null, codice: null };
                    }
                  }
                }
              }

              return { urlSingles, nome, codice };
            }

            // FIX (bug "Dedenne-V1-DAA78" → apre .../Singles/Darkness-Ablaze
            // troncato): vedi commento identico in _risolviSinglesENome più
            // sopra — esclude i link "di sola espansione" senza nome carta.
            const tuttiLink = Array.from(document.querySelectorAll('a[href*="/Singles/"]'))
              .filter(a => {
                const idx = a.pathname.indexOf('/Singles/');
                if (idx === -1) return false;
                const resto = a.pathname.slice(idx + '/Singles/'.length);
                return resto.split('/').filter(Boolean).length >= 2;
              });
            if (tuttiLink.length === 0) return undefined;

            const slugLabel = (a) => {
              const slug = a.pathname.split('/').pop() || '';
              return slug
                .replace(/-V(\d+)-/gi, ' ★V$1 ')
                .replace(/-/g, ' ').trim();
            };
            const toOpzione = (a) => ({
              urlSingles: new URL(a.href).origin + new URL(a.href).pathname,
              label: slugLabel(a),
            });

            // FIX: rimossa la logica PB/MB/ST (OLO_SLUG) — vedi commento esteso
            // su _risolviSinglesENomeFetch. Candidati = sempre tutti i link.
            const candidati = tuttiLink;
            const searchString = new URLSearchParams(window.location.search).get('searchString') || '';
            const getSlugNorm = (a) => (a.pathname.split('/').pop() || '').toLowerCase().replace(/\s/g, '');
            // FIX (bug "MEW 8" → apriva Wartortle): l'ultimo segmento dello
            // slug è sempre {codiceSet}{numero} incollati (es. "MEW008" per
            // il set "Pokémon 151" — nulla a che fare col nome carta "Mew").
            // Il testo cercato va confrontato SOLO contro la parte "nome"
            // dello slug (tutti i segmenti tranne l'ultimo), mai contro il
            // codice-set+numero finale, altrimenti il codice-set stesso può
            // "contenere" per coincidenza il nome cercato.
            const getNomePortion = (a) => {
              const segs = (a.pathname.split('/').pop() || '').split('-');
              return (segs.length > 1 ? segs.slice(0, -1).join('') : segs[0] || '').toLowerCase();
            };
            const getUltimoSegmento = (a) => {
              const segs = (a.pathname.split('/').pop() || '').split('-');
              return segs[segs.length - 1] || '';
            };

            // FIX (bug "MEW 8" → apriva Wartortle): vedi commento esteso su
            // _trovaMatchCartaSingola in background.js. Non si accetta più un
            // singolo candidato "a scatola chiusa" — va sempre verificato
            // contro la query (codice esatto se senza spazi, nome+numero
            // combinati se con spazio).
            function _trovaMatch() {
              const q = searchString.trim();
              if (!q) {
                if (candidati.length === 1) return { match: candidati[0] };
                if (candidati.length > 1)  return { disambiguation: true, opzioni: candidati };
                return { match: null };
              }
              const isCodice = !/\s/.test(q);
              const qNorm = q.replace(/\s/g, '').toLowerCase();
              if (isCodice) {
                const exact = candidati.filter(a => getSlugNorm(a).endsWith(qNorm));
                if (exact.length === 1) return { match: exact[0] };
                if (exact.length > 1)  return { disambiguation: true, opzioni: exact };
                if (candidati.length > 1) return { disambiguation: true, opzioni: candidati };
                return { match: null };
              }
              const parts = q.split(/\s+/);
              const numPart = parts.find(p => /^\d+$/.test(p));
              const textParts = parts.filter(p => !/^\d+$/.test(p)).map(p => p.toLowerCase());
              if (numPart && textParts.length > 0) {
                const numNorm = numPart.replace(/^0+/, '') || numPart;
                const textNorm = textParts.join('');
                const byNameAndNum = candidati.filter(a => {
                  const hasText = getNomePortion(a).includes(textNorm);
                  const numMatch = getUltimoSegmento(a).match(/(\d+)$/);
                  const hasNum = numMatch && numMatch[1].replace(/^0+/, '') === numNorm;
                  return hasText && hasNum;
                });
                if (byNameAndNum.length === 1) return { match: byNameAndNum[0] };
                if (byNameAndNum.length > 1)  return { disambiguation: true, opzioni: byNameAndNum };
              }
              if (candidati.length > 1) return { disambiguation: true, opzioni: candidati };
              return { match: null };
            }

            const esito = _trovaMatch();
            if (esito.disambiguation) return { disambiguation: true, opzioni: esito.opzioni.map(toOpzione) };
            const link = esito.match;
            if (!link) return { urlSingles: null, nome: null };
            const url = new URL(link.href);
            return { urlSingles: url.origin + url.pathname, nome: null };
          },
        }, (results) => {
          if (chrome.runtime.lastError) return;
          const val = results?.[0]?.result;
          // FIX: chrome.scripting.executeScript puo' restituire result:null
          // (invece di undefined) quando lo script viene iniettato proprio mentre
          // la pagina sta navigando/reindirizzando (race condition nota di Chrome).
          // Con il solo controllo su undefined, un null passava indenne e il
          // successivo accesso a val.rateLimited andava in crash ("Cannot read
          // properties of null"). Ora si tratta null e undefined allo stesso modo:
          // 'non ancora pronto, il polling riprova'.
          if (val === undefined || val === null) return;

          if (val && val.rateLimited) {
            // Error 1015: niente challenge da risolvere, chiudi subito e propaga.
            chiudi({ urlSingles: null, nome: null, codice: null, prezzo: null, immagine: null, rateLimited: true });
            return;
          }

          if (val && val.cloudflare) {
            clearInterval(pollTimer);
            clearTimeout(timeout);
            chrome.tabs.onUpdated.removeListener(onLoad);
            _suonaEPortaInPrimoPiano(tabId, _avvisoSonoro, 'carte');
            // FIX: registra questa attesa nel watchdog persistente (vedi
            // _registraAttesaCf) — garantisce che la tab venga chiusa entro
            // il tempo configurato anche se il service worker si riavvia a
            // meta' dell'attesa e perde lo stato/i timer locali qui sotto.
            _registraAttesaCf(tabId, cfTimeoutMs / 60000);
            // CF_RISOLUZIONE_TIMEOUT_MS: vedi commento nell'altra occorrenza in
            // _risolviSinglesENome — stesso fix, stesso motivo, stessa fonte
            // (impostazioni utente sliderCfTimeout).
            const _cfDeadline = Date.now() + cfTimeoutMs;
            function aspettaRisoluzione() {
              // FIX (bug "resta bloccato su una carta"): vedi commento
              // analogo in _leggiPrezzoSealed.
              _touchRichiesta(requestId, tabId);
              if (Date.now() > _cfDeadline) {
                chiudi({ urlSingles: null, nome: null, codice: null, prezzo: null, immagine: null, cloudflareTimeout: true });
                return;
              }
              chrome.scripting.executeScript({
                target: { tabId },
                args: [CF_TITLES],
                func: (CF_TITLES) => {
                  const title = document.title.toLowerCase();
                  const isCF = CF_TITLES.some(t => title.includes(t))
                    || !!document.querySelector('.cf-turnstile,#challenge-running,#challenge-form,#cf-challenge-running');
                  return isCF ? 'cf' : 'ok';
                },
              }, (res) => {
                if (chrome.runtime.lastError) { chiudi({ urlSingles: null, nome: null, codice: null, prezzo: null, immagine: null, cloudflareTimeout: true }); return; }
                if (res?.[0]?.result === 'ok') {
                  caricata = true;
                  pollTimer = setInterval(() => {
                    if (fase === 'risoluzione') tentaLetturaRisoluzione();
                    else tentaLetturaPrezzo();
                  }, 600);
                  timeout = setTimeout(() => chiudi({ urlSingles: null, nome: null, codice: null, prezzo: null, immagine: null }), 15000);
                  chrome.tabs.onUpdated.addListener(onLoad);
                } else {
                  setTimeout(aspettaRisoluzione, 1500);
                }
              });
            }
            setTimeout(aspettaRisoluzione, 2000);
            return;
          }

          if (val && (val.disambiguation || val.varianteNonTrovata)) {
            chiudi({ urlSingles: null, nome: null, codice: null, prezzo: null, immagine: null, ...val });
            return;
          }

          if (!val || !val.urlSingles) {
            chiudi({ urlSingles: null, nome: null, codice: null, prezzo: null, immagine: null });
            return;
          }

          // Nome risolto direttamente (caso /Singles/): salva e passa subito al prezzo.
          // Caso /Search? → link (nome: null): passa al prezzo, poi leggiamo comunque
          // l'h1 della pagina filtrata nella fase prezzo per recuperare nome/codice.
          risolto = { urlSingles: val.urlSingles, nome: val.nome, codice: val.codice || null };
          passaAFasePrezzo(val.urlSingles);
        });
      }

      function tentaLetturaPrezzo() {
        if (!caricata) return;
        _touchRichiesta(requestId, tabId);
        chrome.scripting.executeScript({
          target: { tabId },
          func: async () => {
            // Error 1015: nessun challenge da risolvere, va segnalato subito.
            const _testoPagina = (document.title + ' ' + (document.body ? document.body.innerText.slice(0, 2000) : '')).toLowerCase();
            if (_testoPagina.includes('error 1015') || _testoPagina.includes('you are being rate limited')) {
              return { rateLimited: true };
            }

            const params = new URLSearchParams(window.location.search);
            const idLanguage   = params.get('language') || params.get('idLanguage') || null;
            const minCondition = (params.get('minCondition') || '').toLowerCase() || null;
            const isReverseHolo = params.get('isReverseHolo') === 'Y';
            const isFirstEd = params.get('isFirstEd') === 'Y';

            // FIX (duplicazione eliminata): la logica di filtro righe (lingua,
            // condizione, Reverse Holo, Prima Edizione, carrello cliccabile)
            // vive ora in un'unica fonte di verità — window.rigaSoddisfaFiltriShared,
            // definita in shared.js. shared.js è iniettato dichiarativamente su
            // ogni pagina Cardmarket (vedi content_scripts in manifest.json) e
            // Chrome condivide lo stesso "mondo isolato" tra content script
            // dichiarativi e injection imperative di chrome.scripting.executeScript
            // per la stessa estensione sulla stessa tab — quindi è già disponibile
            // qui. Fallback fail-open (nessun filtro) nell'improbabile caso in cui
            // non sia ancora pronta, per non ripetere l'incidente "tutte le carte
            // Esaurita".
            function rigaOk(riga, ignoraVarianti) {
              if (typeof window.rigaSoddisfaFiltriShared === 'function') {
                return window.rigaSoddisfaFiltriShared(riga, { idLanguage, minCondition, isReverseHolo, isFirstEd, ignoraVarianti });
              }
              console.warn('[CardSync] rigaSoddisfaFiltriShared non disponibile, nessun filtro applicato a questa riga');
              return true;
            }

            // Recupera nome/codice dall'h1 se non già noti (caso /Search? → link)
            let nomeDom = null, codiceDom = null;
            const h1 = document.querySelector('h1');
            if (h1) {
              const clone = h1.cloneNode(true);
              clone.querySelectorAll('span').forEach(s => s.remove());
              const testo = clone.textContent.trim();
              const ultimaParentesiIdx = testo.lastIndexOf('(');
              if (ultimaParentesiIdx === -1) {
                nomeDom = testo;
              } else {
                const codiceRaw = testo.slice(ultimaParentesiIdx + 1, testo.lastIndexOf(')')).trim().toUpperCase();
                codiceDom = codiceRaw || null;
                const nomePre = testo.slice(0, ultimaParentesiIdx).trim();
                if (!nomePre) {
                  const chiusaIdx = testo.lastIndexOf(')');
                  const nomeDopoP = chiusaIdx !== -1 ? testo.slice(chiusaIdx + 1).trim() || null : null;
                  nomeDom = nomeDopoP || null;
                } else { nomeDom = nomePre; }
              }
            }

            const righe = Array.from(document.querySelectorAll('.article-row'));
            if (righe.length === 0) return undefined; // pagina ancora in caricamento → riprova

            let valide = righe.filter(r => rigaOk(r, false));
            // FIX (carte disponibili SOLO in Reverse Holo/Prima Edizione — tipico
            // di molte espansioni cinesi): se l'esclusione badge lascia zero
            // righe, ripeschiamo includendole invece di restituire "Esaurita"
            // per una carta che in realtà ha offerte disponibili.
            if (valide.length === 0) {
              const valideSenzaEsclusione = righe.filter(r => rigaOk(r, true));
              if (valideSenzaEsclusione.length > 0) valide = valideSenzaEsclusione;
            }

            const metaImg = document.querySelector('meta[property="og:image"]');
            let immagine = metaImg ? metaImg.getAttribute('content') : null;
            if (immagine && immagine.includes('static.cardmarket.com/img/logos/')) immagine = null;

            if (valide.length === 0) return { prezzo: null, immagine, nomeDom, codiceDom };

            const selettori = [
              '.price-container .fw-bold',
              '.col-offer-price .fw-bold',
              '[class*="price"] .fw-bold',
              '.color-primary.fw-bold',
              '.price',
            ];

            for (const riga of valide) {
              for (const sel of selettori) {
                const el = riga.querySelector(sel);
                if (el && el.textContent.includes('€')) {
                  const match = el.textContent.match(/([\d,.]+)\s*€/);
                  if (match) {
                    const pulito = match[1].replace(/\./g, '').replace(',', '.');
                    return { prezzo: parseFloat(pulito) || null, immagine, nomeDom, codiceDom };
                  }
                }
              }
            }
            return { prezzo: null, immagine, nomeDom, codiceDom };
          },
        }, (results) => {
          if (chrome.runtime.lastError) return;
          const val = results?.[0]?.result;
          // FIX: chrome.scripting.executeScript puo' restituire result:null
          // (invece di undefined) quando lo script viene iniettato proprio mentre
          // la pagina sta navigando/reindirizzando (race condition nota di Chrome).
          // Con il solo controllo su undefined, un null passava indenne e il
          // successivo accesso a val.rateLimited andava in crash ("Cannot read
          // properties of null"). Ora si tratta null e undefined allo stesso modo:
          // 'non ancora pronto, il polling riprova'.
          if (val === undefined || val === null) return;

          if (val.rateLimited) {
            chiudi({ ...risolto, prezzo: null, immagine: null, rateLimited: true });
            return;
          }

          // Completa nome/codice se mancanti (caso /Search? risolto solo qui)
          if (!risolto.nome && val.nomeDom) risolto.nome = val.nomeDom;
          if (!risolto.codice && val.codiceDom) risolto.codice = val.codiceDom;

          // FIX (carte cinesi e altre espansioni "RH di base"): vedi
          // commento esteso nel percorso fetch statico (_leggiNomeDaCardmarket).
          // Se la lettura con isReverseHolo/isFirstEd non trova prezzo,
          // ritenta UNA volta senza quei parametri prima di arrenderci.
          const prezzoTrovato = val?.prezzo ?? null;
          if (prezzoTrovato === null && (oloType === 'RH' || firstEd) && !variantiRitentateSenzaFiltro) {
            variantiRitentateSenzaFiltro = true;
            passaAFasePrezzo(risolto.urlSingles, true);
            return;
          }

          // FIX: prima l'immagine veniva convertita in base64 qui (fetch +
          // FileReader), ma quel valore veniva quasi sempre scartato più in
          // alto (vedi _leggiNomeDaCardmarket) a favore dell'URL grezzo del
          // fetch statico — lavoro sprecato. Ora si usa sempre l'URL grezzo,
          // coerente con tutto il resto dell'estensione (popup.js, flusso
          // sealed) e con sidebar.html, che si aspetta un URL da proxare
          // tramite images.weserv.nl, non un data URI.
          chiudi({ ...risolto, prezzo: prezzoTrovato, immagine: val?.immagine || null });
        });
      }

      function onLoad(id, info) {
        if (id !== tabId || info.status !== 'complete') return;
        caricata = true;
      }

      chrome.tabs.onUpdated.addListener(onLoad);
      pollTimer = setInterval(() => {
        if (fase === 'risoluzione') tentaLetturaRisoluzione();
        else tentaLetturaPrezzo();
      }, 600);
      timeout = setTimeout(() => chiudi({ urlSingles: null, nome: null, codice: null, prezzo: null, immagine: null }), 15000);
    }

    // FIX (worker tab about:blank mai usata): se il chiamante ha passato
    // una worker tab (sessione bulk), la navighiamo con tabs.update invece
    // di aprirne una nuova. Se quella tab non esiste più (es. chiusa a
    // mano dall'utente), ne apriamo una nuova al volo — il chiamante la
    // registrerà come nuova worker tab leggendo il tabId nel risultato.
    if (vogliamoRiusare) {
      chrome.tabs.update(tabIdEsterno, { url: urlNome }, (tab) => {
        if (chrome.runtime.lastError || !tab) {
          chrome.tabs.create({ url: urlNome, active: false }, avviaCon);
        } else {
          avviaCon(tab);
        }
      });
    } else {
      chrome.tabs.create({ url: urlNome, active: false }, avviaCon);
    }
  });
}

// Apre l'URL /Singles/ già filtrato (con language= e minCondition=) e legge il prezzo
// con polling ogni 600ms perché le .article-row vengono iniettate via JS dopo il load.
// Applica gli stessi filtri DOM di content.js (lingua + condizione).
//
// FIX Cloudflare: questa funzione viene usata dal flusso principale
// _leggiNomeDaCardmarket quando il nome/urlSingles è già stato risolto via
// FETCH statico (fase1, nessuna tab aperta) — questa è quindi la SECONDA
// tab reale che si apre per la carta, solo per leggere il prezzo. Prima non
// c'era ALCUN rilevamento Cloudflare qui: se questa tab incappava nel
// challenge, il polling restava bloccato su ".article-row" vuoto fino al
// timeout di 15s, e la carta veniva salvata con prezzo/immagine null, senza
// nessun avviso sonoro né possibilità di risolvere il challenge. Ora si
// comporta come le altre funzioni "tab" dell'estensione: rileva Cloudflare,
// avvisa (suono + focus finestra) e aspetta la risoluzione entro il timeout
// configurato dall'utente, prima di riprendere il polling del prezzo.

function _leggiPrezzoDaSingles(urlConFiltri, tabIdEsterno, requestId = null) {
  return new Promise(async (resolve) => {
    const { cfTimeoutMs, avvisoSonoro: _avvisoSonoro } = await _leggiOpzioniCf();
    // FIX (troppe tab in sequenza → Cloudflare): se il chiamante passa
    // tabIdEsterno (worker tab della sessione bulk), la navighiamo con
    // tabs.update invece di aprirne una nuova ogni volta — vedi
    // _prontaWorkerTabId in testa al file.
    const vogliamoRiusare = tabIdEsterno != null;

    function avviaCon(tab) {
      const tabId = tab.id;
      let caricata = false;
      let pollTimer, timeout;

      // FIX (bug "riga con nome vuoto sovrascritta dalla carta successiva"):
      // questa tab, aperta per il solo ricontrollo prezzo, era comunque già
      // sulla pagina /Singles/ della carta — un posto perfetto per rileggere
      // ANCHE nome/codice a costo zero (nessuna tab aggiuntiva), da usare
      // come rete di sicurezza quando la carta era stata inserita a suo
      // tempo senza nome (vedi chiamanti in aggiungi_carta_popup.js).
      function chiudi(prezzo, immagine, nome, codice) {
        clearInterval(pollTimer);
        clearTimeout(timeout);
        chrome.tabs.onUpdated.removeListener(onLoad);
        // FIX: rimuove subito la voce dal watchdog persistente quando
        // l'attesa si risolve normalmente (prima della scadenza) — altrimenti
        // resterebbe li' fino alla sua scadenza naturale, tentando poi di
        // richiudere una tab gia' rimossa o riusata per qualcos'altro.
        _rimuoviAttesaCf(tabId);
        // FIX (troppe tab in sequenza → Cloudflare): la worker tab riusata
        // per tutta la sessione bulk NON viene mai chiusa qui — resta aperta
        // per la carta successiva. Si chiude solo per le chiamate "una
        // tantum" o esplicitamente a fine sessione (CHIUDI_WORKER_TAB).
        if (!vogliamoRiusare) chrome.tabs.remove(tabId, () => {});
        resolve({ prezzo, immagine: immagine || null, nome: nome || null, codice: codice || null, tabId });
      }

      function tentaLettura() {
        if (!caricata) return;
        // FIX (bug "resta bloccato su una carta"): a ogni tick di polling
        // aggiorna il timestamp heartbeat — vedi commento su _richiesteAttive.
        _touchRichiesta(requestId, tabId);
        chrome.scripting.executeScript({
          target: { tabId },
          args: [CF_TITLES],
          func: async (CF_TITLES) => {
            // Error 1015: nessun challenge da risolvere, va segnalato subito.
            const _testoPagina = (document.title + ' ' + (document.body ? document.body.innerText.slice(0, 2000) : '')).toLowerCase();
            if (_testoPagina.includes('error 1015') || _testoPagina.includes('you are being rate limited')) {
              return { rateLimited: true };
            }

            // ── Rilevamento Cloudflare ──
            // FIX: prima questo controllo non esisteva in questa funzione —
            // vedi commento sopra la dichiarazione di _leggiPrezzoDaSingles.
            const title = document.title.toLowerCase();
            const isCloudflare = CF_TITLES.some(t => title.includes(t))
              || !!document.querySelector('.cf-turnstile, #challenge-running, #challenge-form, #cf-challenge-running');
            if (isCloudflare) return { cloudflare: true };

            const params = new URLSearchParams(window.location.search);
            const idLanguage   = params.get('language') || params.get('idLanguage') || null;
            const minCondition = (params.get('minCondition') || '').toLowerCase() || null;
            const isReverseHolo = params.get('isReverseHolo') === 'Y';
            const isFirstEd = params.get('isFirstEd') === 'Y';

            // FIX (duplicazione eliminata): vedi commento gemello in
            // _risolviNomeEPrezzoUnicaTab più sopra — stessa logica, ora
            // centralizzata in window.rigaSoddisfaFiltriShared (shared.js),
            // già disponibile in questo mondo isolato. Fallback fail-open se
            // per qualche motivo non lo fosse.
            function rigaOk(riga, ignoraVarianti) {
              if (typeof window.rigaSoddisfaFiltriShared === 'function') {
                return window.rigaSoddisfaFiltriShared(riga, { idLanguage, minCondition, isReverseHolo, isFirstEd, ignoraVarianti });
              }
              console.warn('[CardSync] rigaSoddisfaFiltriShared non disponibile, nessun filtro applicato a questa riga');
              return true;
            }

            // Rilettura nome/codice dall'h1 — vedi commento su chiudi() più
            // sopra: questa tab è già sulla pagina /Singles/, costo zero.
            let nomeDom = null, codiceDom = null;
            const h1 = document.querySelector('h1');
            if (h1) {
              const clone = h1.cloneNode(true);
              clone.querySelectorAll('span').forEach(s => s.remove());
              const testo = clone.textContent.trim();
              const ultimaParentesiIdx = testo.lastIndexOf('(');
              if (ultimaParentesiIdx === -1) {
                nomeDom = testo || null;
              } else {
                const codiceRaw = testo.slice(ultimaParentesiIdx + 1, testo.lastIndexOf(')')).trim().toUpperCase();
                codiceDom = codiceRaw || null;
                const nomePre = testo.slice(0, ultimaParentesiIdx).trim();
                if (nomePre) { nomeDom = nomePre; }
                else {
                  const chiusaIdx = testo.lastIndexOf(')');
                  const nomeDopoP = chiusaIdx !== -1 ? (testo.slice(chiusaIdx + 1).trim() || null) : null;
                  nomeDom = nomeDopoP;
                }
              }
            }

            const righe = Array.from(document.querySelectorAll('.article-row'));
            if (righe.length === 0) return undefined; // non ancora caricate → polling riprova

            let valide = righe.filter(r => rigaOk(r, false));
            // FIX (carte disponibili SOLO in Reverse Holo/Prima Edizione — tipico
            // di molte espansioni cinesi): se l'esclusione badge lascia zero
            // righe, ripeschiamo includendole invece di restituire "nessun
            // prezzo" (falso "Esaurita") per una carta che ha offerte disponibili.
            if (valide.length === 0) {
              const valideSenzaEsclusione = righe.filter(r => rigaOk(r, true));
              if (valideSenzaEsclusione.length > 0) valide = valideSenzaEsclusione;
            }
            if (valide.length === 0) return { prezzo: null, immagine: null, nomeDom, codiceDom };

            const selettori = [
              '.price-container .fw-bold',
              '.col-offer-price .fw-bold',
              '[class*="price"] .fw-bold',
              '.color-primary.fw-bold',
              '.price',
            ];
            // Estrai immagine dal DOM (meta og:image, già nel DOM renderizzato)
            const metaImg = document.querySelector('meta[property="og:image"]');
            let immagine = metaImg ? metaImg.getAttribute('content') : null;
            if (immagine && immagine.includes('static.cardmarket.com/img/logos/')) immagine = null;

            for (const riga of valide) {
              for (const sel of selettori) {
                const el = riga.querySelector(sel);
                if (el && el.textContent.includes('€')) {
                  const match = el.textContent.match(/([\d,.]+)\s*€/);
                  if (match) {
                    const pulito = match[1].replace(/\./g, '').replace(',', '.');
                    return { prezzo: parseFloat(pulito) || null, immagine, nomeDom, codiceDom };
                  }
                }
              }
            }
            return { prezzo: null, immagine, nomeDom, codiceDom };
          },
        }, (results) => {
          if (chrome.runtime.lastError) return;
          const val = results?.[0]?.result;
          // FIX: chrome.scripting.executeScript puo' restituire result:null
          // (invece di undefined) quando lo script viene iniettato proprio mentre
          // la pagina sta navigando/reindirizzando (race condition nota di Chrome).
          // Con il solo controllo su undefined, un null passava indenne e il
          // successivo accesso a val.rateLimited andava in crash ("Cannot read
          // properties of null"). Ora si tratta null e undefined allo stesso modo:
          // 'non ancora pronto, il polling riprova'.
          if (val === undefined || val === null) return; // righe non ancora nel DOM → riprova
          // FIX: prima, quando nessuna riga soddisfaceva i filtri, la func
          // iniettata restituiva null e questo ramo lo trattava come
          // "risultato definitivo, nessun prezzo" — ma da quando la stessa
          // lettura recupera anche nomeDom/codiceDom, quel caso ritorna
          // sempre un oggetto (mai più null), quindi qui resta solo la
          // guardia difensiva per l'improbabile null residuo.
          if (val === null) { chiudi(null, null); return; }
          if (val.rateLimited) { chiudi('RateLimit', null); return; }

          if (val.cloudflare) {
            // FIX: prima Cloudflare qui non veniva mai gestito (vedi commento
            // sopra la funzione) — la tab restava a pollare ".article-row"
            // per sempre, senza risultati, fino al timeout di 15s, salvando
            // poi la carta senza prezzo né immagine. Ora si comporta come le
            // altre tab dell'estensione: avvisa l'utente (suono + focus) e
            // aspetta la risoluzione del challenge entro il timeout
            // configurato, prima di riprendere il polling del prezzo.
            clearInterval(pollTimer);
            clearTimeout(timeout);
            chrome.tabs.onUpdated.removeListener(onLoad);
            _suonaEPortaInPrimoPiano(tabId, _avvisoSonoro, 'carte');
            // FIX: registra questa attesa nel watchdog persistente (vedi
            // _registraAttesaCf) — garantisce che la tab venga chiusa entro
            // il tempo configurato anche se il service worker si riavvia a
            // meta' dell'attesa e perde lo stato/i timer locali qui sotto.
            _registraAttesaCf(tabId, cfTimeoutMs / 60000);
            const _cfDeadline = Date.now() + cfTimeoutMs;
            function aspettaRisoluzione() {
              // FIX (bug "resta bloccato su una carta"): vedi commento
              // analogo in _leggiPrezzoSealed.
              _touchRichiesta(requestId, tabId);
              if (Date.now() > _cfDeadline) { chiudi(null, null); return; }
              chrome.scripting.executeScript({
                target: { tabId }, args: [CF_TITLES],
                func: (CF_TITLES) => {
                  const title = document.title.toLowerCase();
                  return (CF_TITLES.some(t => title.includes(t)) || !!document.querySelector('.cf-turnstile,#challenge-running,#challenge-form,#cf-challenge-running')) ? 'cf' : 'ok';
                },
              }, (res) => {
                if (chrome.runtime.lastError) { chiudi(null, null); return; }
                if (res?.[0]?.result === 'ok') {
                  caricata = true;
                  pollTimer = setInterval(tentaLettura, 600);
                  timeout = setTimeout(() => chiudi(null, null), 15000);
                  chrome.tabs.onUpdated.addListener(onLoad);
                } else { setTimeout(aspettaRisoluzione, 1500); }
              });
            }
            setTimeout(aspettaRisoluzione, 2000);
            return;
          }

          // FIX: come nell'altra occorrenza in _risolviNomeEPrezzoUnicaTab,
          // niente più conversione base64 — si passa sempre l'URL grezzo,
          // coerente col resto dell'estensione e con sidebar.html.
          // FIX (bug "prezzo corrotto su carte Esaurite"): era `val?.prezzo ?? val`
          // — con ?? il fallback scatta anche quando val.prezzo è null (caso
          // legittimo: pagina caricata ma nessuna offerta valida), sostituendo
          // il prezzo con l'INTERO oggetto val invece di lasciarlo null. La
          // colonna prezzo finiva così con un valore corrotto (es. un oggetto
          // serializzato) al posto di restare vuota, sia per le carte aggiunte
          // in bulk sia per il ricontrollo prezzo mancante. Nessun fallback a
          // val: se prezzo è null, deve restare null.
          chiudi(val?.prezzo ?? null, val?.immagine || null, val?.nomeDom || null, val?.codiceDom || null);
        });
      }

      function onLoad(id, info) {
        if (id !== tabId || info.status !== 'complete') return;
        caricata = true;
      }

      chrome.tabs.onUpdated.addListener(onLoad);
      pollTimer = setInterval(tentaLettura, 600);
      timeout = setTimeout(() => chiudi(null, null), 15000);
    }

    if (vogliamoRiusare) {
      chrome.tabs.update(tabIdEsterno, { url: urlConFiltri }, (tab) => {
        if (chrome.runtime.lastError || !tab) {
          chrome.tabs.create({ url: urlConFiltri, active: false }, avviaCon);
        } else {
          avviaCon(tab);
        }
      });
    } else {
      chrome.tabs.create({ url: urlConFiltri, active: false }, avviaCon);
    }
  });
}