(function () {
  function scrollCasuale() {
    const altezzaPagina = document.body.scrollHeight;
    const passi = 3 + Math.floor(Math.random() * 4);
    let i = 0;
    function faiScroll() {
      if (i >= passi) {
        // FIX (comodità): prima la pagina restava ferma nell'ultima
        // posizione casuale raggiunta — bisognava sempre riscrollare a
        // mano in cima per controllare qualcosa. Lo scroll casuale serve
        // solo a sembrare un utente vero (contro Cloudflare), non ha
        // bisogno di "restare" da nessuna parte — la riportiamo sempre in
        // cima all'ultimo passo.
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return;
      }
      const posizione = Math.floor(Math.random() * altezzaPagina * 0.6);
      window.scrollTo({ top: posizione, behavior: 'smooth' });
      i++;
      setTimeout(faiScroll, 400 + Math.floor(Math.random() * 800));
    }
    faiScroll();
  }

  function simulaMovimentoMouse() {
    const eventi = 4 + Math.floor(Math.random() * 5);
    for (let i = 0; i < eventi; i++) {
      setTimeout(() => {
        const x = Math.floor(Math.random() * window.innerWidth);
        const y = Math.floor(Math.random() * window.innerHeight);
        document.dispatchEvent(new MouseEvent('mousemove', { clientX: x, clientY: y, bubbles: true }));
      }, i * (200 + Math.floor(Math.random() * 400)));
    }
  }

  scrollCasuale();
  simulaMovimentoMouse();

  let inviato = false;
  let cloudflareSegnalatO = false;
  let fallbackTimeoutId = null;

  const CF_TITLES = [
    'just a moment', 'un attimo', 'ci siamo quasi', 'almost there',
    'checking your', 'einen moment', 'por favor', 'verifique', 'patikrinimas',
  ];

  // Pagina di rate limit (Error 1015): diversa dal challenge "Just a moment…",
  // qui non c'è nulla da risolvere manualmente, serve solo aspettare.
  const RATE_LIMIT_MARKERS = ['error 1015', 'you are being rate limited'];

  function isRateLimited() {
    const testo = (document.title + ' ' + (document.body ? document.body.innerText.slice(0, 2000) : '')).toLowerCase();
    return RATE_LIMIT_MARKERS.some(m => testo.includes(m));
  }

  let rateLimitSegnalato = false;
  function segnalaRateLimit() {
    if (!rateLimitSegnalato) {
      rateLimitSegnalato = true;
      if (fallbackTimeoutId) clearTimeout(fallbackTimeoutId);
      chrome.runtime.sendMessage({ type: 'RATE_LIMIT_DETECTED' });
    }
  }


  function isCloudflare() {
    const title = document.title.toLowerCase();
    if (CF_TITLES.some(t => title.includes(t))) return true;
    if (
      document.querySelector('.cf-turnstile') ||
      document.getElementById('challenge-running') ||
      document.querySelector('[class*="cf-chl-widget"]') ||
      document.querySelector('[id*="cf-chl-widget"]') ||
      document.querySelector('[class*="cf-challenge"]') ||
      document.querySelector('#challenge-form') ||
      document.querySelector('#cf-challenge-running')
    ) return true;
    return false;
  }

  function segnalaCloudflare() {
    if (!cloudflareSegnalatO) {
      cloudflareSegnalatO = true;
      if (fallbackTimeoutId) clearTimeout(fallbackTimeoutId);
      chrome.runtime.sendMessage({ type: 'CLOUDFLARE_DETECTED' });
    }
  }

  // ── MAPPE LINGUA E CONDIZIONE / FILTRO RIGHE OFFERTA ─────────────────────────
  // FIX (duplicazione eliminata): la logica di filtro (lingua, condizione,
  // Reverse Holo, Prima Edizione, carrello cliccabile) viveva qui duplicata
  // quasi identica anche in due punti di background.js. Ora vive in un'unica
  // fonte di verità — window.rigaSoddisfaFiltriShared, definita in shared.js
  // — iniettato PRIMA di questo script sulle pagine Cardmarket (vedi
  // content_scripts in manifest.json). Fallback fail-open (nessun filtro
  // invece di bloccare tutto) nell'improbabile caso in cui shared.js non sia
  // ancora pronto, per non ripetere l'incidente "tutte le carte Esaurita".
  function rigaSoddisfaFiltri(riga, idLanguage, minCondition, isReverseHolo, isFirstEd, ignoraVarianti) {
    if (typeof rigaSoddisfaFiltriShared === 'function') {
      return rigaSoddisfaFiltriShared(riga, { idLanguage, minCondition, isReverseHolo, isFirstEd, ignoraVarianti });
    }
    console.warn('[CardSync] rigaSoddisfaFiltriShared non disponibile (shared.js non caricato?) — nessun filtro applicato a questa riga');
    return true;
  }

  // L'URL contiene minCondition come numero (es. "2"), non come sigla
  // testuale — la conversione avviene dentro rigaSoddisfaFiltriShared
  // (shared.js), tramite COND_NUM_TO_KEY_SHARED.

  function leggiParametriUrl() {
    const params = new URLSearchParams(window.location.search);
    return {
      idLanguage: params.get('language') || params.get('idLanguage') || null,
      minCondition: (params.get('minCondition') || '').toLowerCase() || null,
      isReverseHolo: params.get('isReverseHolo') === 'Y',
      isFirstEd: params.get('isFirstEd') === 'Y',
    };
  }

  // ── NOME/CODICE DALLA PAGINA (verifica anti-carta-sbagliata) ────────────────
  // FIX: mancava del tutto — popup.js si aspetta nomePagina/codicePagina nel
  // messaggio PREZZO_TROVATO per verificare (in verificaCartaNelDom) che il
  // prezzo letto appartenga davvero alla carta attesa, ma non venendo mai
  // inviati arrivavano sempre come stringa vuota: il controllo di sicurezza
  // era quindi un no-op silenzioso, sempre superato senza verificare nulla.
  // Stessa logica di estrazione usata in background.js per le tab aperte in
  // bulk: il codice è sempre nell'ultima coppia di parentesi dell'h1, tranne
  // le promo SVP che lo mettono in testa.
  function leggiNomeECodiceDaH1() {
    const h1 = document.querySelector('h1');
    if (!h1) return { nome: null, codice: null };
    const clone = h1.cloneNode(true);
    clone.querySelectorAll('span').forEach(s => s.remove());
    const testo = clone.textContent.trim();
    const ultimaParentesiIdx = testo.lastIndexOf('(');
    if (ultimaParentesiIdx === -1) return { nome: testo.toUpperCase() || null, codice: null };
    const codiceRaw = testo.slice(ultimaParentesiIdx + 1, testo.lastIndexOf(')')).trim().toUpperCase();
    const codice = codiceRaw || null;
    const nomePre = testo.slice(0, ultimaParentesiIdx).trim().toUpperCase();
    if (nomePre) return { nome: nomePre, codice };
    const chiusaIdx = testo.lastIndexOf(')');
    const nomePost = chiusaIdx !== -1 ? (testo.slice(chiusaIdx + 1).trim().toUpperCase() || null) : null;
    if (nomePost) return { nome: nomePost, codice };
    const primaP = testo.indexOf('(');
    const nomeAnte = primaP > 0 ? (testo.slice(0, primaP).trim().toUpperCase() || null) : null;
    return { nome: nomeAnte, codice };
  }

  // ── IMMAGINE REALE (esclude il logo generico) ────────────────────────────────
  // FIX: og:image qui non veniva mai filtrata — poteva finire salvato il logo
  // generico di Cardmarket invece della foto vera, stesso bug già corretto in
  // background.js per i flussi bulk. Le foto vere sono sempre servite da
  // product-images.s3.cardmarket.com.
  function estraiImmagineReale() {
    const metaImg = document.querySelector('meta[property="og:image"]');
    let immagine = metaImg ? metaImg.getAttribute('content') : null;
    if (immagine && !immagine.includes('product-images')) immagine = null;
    if (!immagine) {
      const imgReale = Array.from(document.querySelectorAll('img'))
        .map(img => img.src)
        .find(src => src && src.includes('product-images'));
      immagine = imgReale || null;
    }
    return immagine;
  }

  function estraiPrezzo() {
    if (isRateLimited()) { segnalaRateLimit(); return false; }
    if (isCloudflare()) { segnalaCloudflare(); return false; }
    if (cloudflareSegnalatO && !inviato) cloudflareSegnalatO = false;

    const { idLanguage, minCondition, isReverseHolo, isFirstEd } = leggiParametriUrl();
    const righe = Array.from(document.querySelectorAll('.article-row'));
    if (righe.length === 0) return false;

    let righeFiltrate = righe.filter(r => rigaSoddisfaFiltri(r, idLanguage, minCondition, isReverseHolo, isFirstEd));
    // FIX (carte disponibili SOLO in Reverse Holo / Prima Edizione — tipico
    // di molte espansioni cinesi): se il filtro standard lascia zero righe
    // SOLO a causa dell'esclusione badge RH/1ED (non per lingua/condizione),
    // ripeschiamo includendo anche quelle righe invece di segnalare
    // "Esaurita" per una carta che in realtà ha offerte disponibili. Passando
    // true/true disattiviamo solo l'esclusione RH/1ED, lingua e condizione
    // restano filtrate come richiesto.
    if (righeFiltrate.length === 0) {
      const righeSenzaEsclusioneVarianti = righe.filter(r => rigaSoddisfaFiltri(r, idLanguage, minCondition, true, true));
      if (righeSenzaEsclusioneVarianti.length > 0) righeFiltrate = righeSenzaEsclusioneVarianti;
    }
    if (righeFiltrate.length === 0) return false;

    // Prende il prezzo dalla prima riga valida
    for (const riga of righeFiltrate) {
      // Selettore principale (layout desktop): .price-container .fw-bold
      const selettori = [
        '.price-container .fw-bold',
        '.col-offer-price .fw-bold',
        '[class*="price"] .fw-bold',
        '.color-primary.fw-bold',
        '.price',
      ];
      let prezzoTesto = null;
      for (const sel of selettori) {
        const el = riga.querySelector(sel);
        if (el && el.textContent.includes('€')) { prezzoTesto = el.textContent.trim(); break; }
      }
      // Fallback regex
      if (!prezzoTesto) {
        for (const el of riga.querySelectorAll('span, div')) {
          const txt = el.textContent.trim();
          if (/^\d[\d.,]*\s*€$/.test(txt)) { prezzoTesto = txt; break; }
        }
      }
      if (prezzoTesto) {
        const match = prezzoTesto.match(/([\d,.]+)\s*€/);
        if (match) {
          const pulito = match[1].replace(/\./g, '').replace(',', '.');
          const prezzo = parseFloat(pulito);
          if (!inviato) {
            inviato = true;
            const _immagine = estraiImmagineReale();
            const { nome: _nomePagina, codice: _codicePagina } = leggiNomeECodiceDaH1();
            chrome.runtime.sendMessage({
              type: 'PREZZO_TROVATO',
              prezzo: isNaN(prezzo) ? 'N/D' : prezzo,
              immagine: _immagine,
              nomePagina: _nomePagina,
              codicePagina: _codicePagina,
            });
          }
          return true;
        }
      }
    }
    return false;
  }

  if (estraiPrezzo()) return;

  // FIX (freeze di Chrome sulle pagine con molte offerte): prima questo
  // observer richiamava estraiPrezzo() — una scansione pesante che prova 5
  // selettori diversi per riga e in fallback itera su OGNI span/div della
  // riga — ad OGNI singola mutazione del DOM, osservato su tutto il
  // documento in profondità (subtree:true). Su una pagina con molte righe
  // .article-row e immagini che caricano una per una (oltre allo scroll e ai
  // mousemove simulati sopra, che possono innescare ulteriore lazy-loading),
  // le mutazioni possono arrivare a centinaia al secondo, ognuna delle quali
  // rifaceva partire da capo la scansione pesante — abbastanza da saturare
  // CPU e memoria e bloccare l'intero browser, non solo la tab.
  //
  // Ora le mutazioni vengono raggruppate: qualunque numero di mutazioni
  // arrivi entro 150ms l'una dall'altra provoca UNA sola scansione, non una
  // per mutazione. 150ms è comunque impercettibile per l'utente (il prezzo
  // viene comunque rilevato quasi subito dopo che la pagina smette di
  // cambiare) ma taglia drasticamente il numero di scansioni pesanti
  // eseguite durante il caricamento.
  let debounceEstraiPrezzoId = null;
  const observer = new MutationObserver(() => {
    if (debounceEstraiPrezzoId) return; // già in attesa di un giro, non serve altro
    debounceEstraiPrezzoId = setTimeout(() => {
      debounceEstraiPrezzoId = null;
      if (isRateLimited()) { segnalaRateLimit(); return; }
      if (isCloudflare()) { segnalaCloudflare(); return; }
      // FIX (bug [18]): prima veniva disconnesso solo "observer" quando il
      // prezzo si trovava da qui — "titleObserver" restava attivo fino al
      // fallback timeout. Impatto pratico minimo (il listener che
      // gestirebbe un CLOUDFLARE_DETECTED tardivo è già rimosso lato
      // popup.js alla risoluzione della Promise), ma per coerenza con il
      // ramo di fallback sotto (che disconnette entrambi) meglio pulire
      // subito qui invece di lasciarlo attivo fino al timeout.
      if (estraiPrezzo()) { observer.disconnect(); titleObserver.disconnect(); }
    }, 150);
  });
  observer.observe(document.documentElement, { childList: true, subtree: true });

  const titleObserver = new MutationObserver(() => {
    if (isRateLimited()) { segnalaRateLimit(); return; }
    if (isCloudflare()) segnalaCloudflare();
  });
  const titleEl = document.querySelector('title');
  if (titleEl) titleObserver.observe(titleEl, { childList: true, characterData: true, subtree: true });

  fallbackTimeoutId = setTimeout(() => {
    observer.disconnect();
    titleObserver.disconnect();
    if (rateLimitSegnalato) return; // già segnalato il rate limit, non sovrascrivere
    if (!inviato) {
      inviato = true;
      const { idLanguage, minCondition, isReverseHolo, isFirstEd } = leggiParametriUrl();
      const tutteLeRighe = document.querySelectorAll('.article-row');
      let righeFiltrate = Array.from(tutteLeRighe).filter(r => rigaSoddisfaFiltri(r, idLanguage, minCondition, isReverseHolo, isFirstEd));
      // FIX: stesso fallback di estraiPrezzo() sopra — carte disponibili solo
      // in Reverse Holo/Prima Edizione (es. molte cinesi) non devono risultare
      // "Esaurita" solo perché l'esclusione badge scarta l'unica stampa esistente.
      if (righeFiltrate.length === 0) {
        const righeSenzaEsclusioneVarianti = Array.from(tutteLeRighe).filter(r => rigaSoddisfaFiltri(r, idLanguage, minCondition, true, true));
        if (righeSenzaEsclusioneVarianti.length > 0) righeFiltrate = righeSenzaEsclusioneVarianti;
      }
      const { nome: _nomePagina, codice: _codicePagina } = leggiNomeECodiceDaH1();
      if (tutteLeRighe.length > 0 && righeFiltrate.length === 0) {
        chrome.runtime.sendMessage({ type: 'PREZZO_TROVATO', prezzo: 'Esaurita', nomePagina: _nomePagina, codicePagina: _codicePagina });
        return;
      }
      // FIX (bug "Esaurita mostrata come N/D"): quando in pagina non c'è
      // NESSUNA .article-row (tutteLeRighe.length === 0), i parametri
      // language=/minCondition= nell'URL sono filtri NATIVI di Cardmarket
      // applicati server-side — zero righe significa quasi sempre che non
      // esiste alcuna offerta per quella combinazione lingua/condizione,
      // esattamente come il caso "Esaurita" sopra (lì il filtro scarta
      // alcune righe lato client, qui Cardmarket le ha già scartate tutte
      // lato server prima ancora di renderle). Prima questo caso veniva
      // riconosciuto come Esaurita SOLO se il testo della pagina conteneva
      // esattamente "no result"/"nessun risultato"/"esaurito" — se il
      // messaggio reale di Cardmarket per "zero offerte" non combacia con
      // nessuna di queste stringhe, si finiva su N/D, fuorviante perché la
      // pagina si è caricata perfettamente. Il nome carta letto dall'h1 è
      // la prova che la pagina è valida: se c'è, il motivo di zero righe è
      // quasi certamente "nessuna offerta disponibile", non un errore di
      // caricamento — quindi va classificato Esaurita, non N/D.
      if (tutteLeRighe.length === 0 && _nomePagina) {
        chrome.runtime.sendMessage({ type: 'PREZZO_TROVATO', prezzo: 'Esaurita', nomePagina: _nomePagina, codicePagina: _codicePagina });
        return;
      }
      const testo = document.body.innerText.toLowerCase();
      if (testo.includes('no result') || testo.includes('nessun risultato') || testo.includes('esaurito')) {
        chrome.runtime.sendMessage({ type: 'PREZZO_TROVATO', prezzo: 'Esaurita', nomePagina: _nomePagina, codicePagina: _codicePagina });
      } else {
        chrome.runtime.sendMessage({ type: 'PREZZO_TROVATO', prezzo: 'N/D', nomePagina: _nomePagina, codicePagina: _codicePagina });
      }
    }
  }, 15000);
})();