// ── auth_ui.js ────────────────────────────────────────────────────────────────
// Modulo di login condiviso: sostituisce i prompt() temporanei usati durante
// lo sviluppo con un vero modulo grafico, riusato identico da tutte le pagine
// dell'estensione (popup, hub, carte, sealed, wishlist, anteprima). Richiede
// che supabase.bundle.js e supabase_adapter.js siano già caricati PRIMA di
// questo file (usa la variabile globale supabaseClient definita lì).
//
// Uso in ogni pagina, al posto del vecchio blocco IIFE con prompt():
//   assicuraLoginSupabase();
//
// La funzione controlla se esiste già una sessione salvata (chrome.storage
// persiste il login tra le pagine, quindi nella maggior parte dei casi non
// succede nulla di visibile) — solo se NON c'è una sessione valida mostra il
// modulo a schermo intero, bloccando l'interazione con la pagina finché non
// viene completato un login riuscito.

(function () {
  const STILE_ID = 'cardsync-auth-ui-style';

  function iniettaStile() {
    if (document.getElementById(STILE_ID)) return;
    const style = document.createElement('style');
    style.id = STILE_ID;
    style.textContent = `
      #cardsync-auth-overlay {
        position: fixed; inset: 0; z-index: 999999;
        background: rgba(20, 16, 32, 0.72);
        display: flex; align-items: center; justify-content: center;
        font-family: 'DM Sans', -apple-system, BlinkMacSystemFont, sans-serif;
      }
      #cardsync-auth-card {
        background: #ffffff; color: #1a1625;
        width: min(340px, 90vw);
        border-radius: 16px;
        padding: 28px 26px 24px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.35);
      }
      #cardsync-auth-card h2 {
        margin: 0 0 4px; font-size: 18px; font-weight: 700;
      }
      #cardsync-auth-card p.sub {
        margin: 0 0 20px; font-size: 12.5px; color: #6b6478;
      }
      #cardsync-auth-card label {
        display: block; font-size: 12px; font-weight: 600;
        color: #4a4458; margin: 12px 0 5px;
      }
      #cardsync-auth-card input {
        width: 100%; box-sizing: border-box;
        padding: 9px 11px; border-radius: 9px;
        border: 1.5px solid #e0dce8; font-size: 14px;
        font-family: inherit;
      }
      #cardsync-auth-card input:focus {
        outline: none; border-color: #7c5cff;
      }
      #cardsync-auth-error {
        display: none; margin-top: 12px; padding: 9px 11px;
        background: #fdeaea; color: #b3261e; border-radius: 8px;
        font-size: 12.5px; line-height: 1.4;
      }
      #cardsync-auth-submit {
        width: 100%; margin-top: 18px; padding: 10px;
        border: none; border-radius: 10px;
        background: #7c5cff; color: #fff;
        font-size: 14px; font-weight: 700; cursor: pointer;
        font-family: inherit;
      }
      #cardsync-auth-submit:disabled {
        opacity: 0.6; cursor: default;
      }
      #cardsync-auth-submit:not(:disabled):hover {
        background: #6a4ce0;
      }
      #cardsync-logout-btn {
        position: fixed; bottom: 14px; right: 14px; z-index: 999998;
        background: rgba(20, 16, 32, 0.55); color: #fff;
        border: none; border-radius: 20px;
        padding: 6px 12px; font-size: 11.5px; font-weight: 600;
        font-family: 'DM Sans', -apple-system, BlinkMacSystemFont, sans-serif;
        cursor: pointer; display: flex; align-items: center; gap: 5px;
        opacity: 0.55; transition: opacity 0.15s;
      }
      #cardsync-logout-btn:hover { opacity: 1; }
    `;
    document.head.appendChild(style);
  }

  function costruisciOverlay() {
    const overlay = document.createElement('div');
    overlay.id = 'cardsync-auth-overlay';
    overlay.innerHTML = `
      <div id="cardsync-auth-card">
        <h2>🔐 Accedi a CardSync Pro</h2>
        <p class="sub">Usa l'account che ti è stato assegnato per la tua collezione.</p>
        <label for="cardsync-auth-email">Nome utente</label>
        <input type="text" id="cardsync-auth-email" autocomplete="username" placeholder="es. irene" />
        <label for="cardsync-auth-password">Password</label>
        <input type="password" id="cardsync-auth-password" autocomplete="current-password" />
        <div id="cardsync-auth-error"></div>
        <button id="cardsync-auth-submit">Accedi</button>
      </div>
    `;
    return overlay;
  }

  function mostraBottoneLogout(email) {
    if (document.getElementById('cardsync-logout-btn')) return; // già presente
    const btn = document.createElement('button');
    btn.id = 'cardsync-logout-btn';
    btn.title = 'Esci da CardSync Pro (' + email + ')';
    btn.innerHTML = '🚪 Esci';
    btn.addEventListener('click', async () => {
      if (!confirm('Uscire da CardSync Pro (' + email + ')?\n\nDovrai rifare il login per usare l\'estensione.')) return;
      await supabaseClient.auth.signOut();
      location.reload();
    });
    document.body.appendChild(btn);
  }

  // Espone la funzione di logout anche per un eventuale pulsante nella UI
  // vera in futuro (es. dentro il menu account), non solo quello fisso.
  window.logoutSupabase = async function () {
    await supabaseClient.auth.signOut();
    location.reload();
  };

  // Restituisce una Promise che si risolve quando l'utente ha (o aveva già)
  // una sessione Supabase valida. Sicura da chiamare più volte: se una
  // sessione esiste già, si risolve subito senza mostrare nulla a schermo.
  window.assicuraLoginSupabase = function () {
    return new Promise(async (resolve) => {
      const { data } = await supabaseClient.auth.getSession();
      if (data.session) {
        mostraBottoneLogout(data.session.user.email);
        resolve(data.session);
        return;
      }

      iniettaStile();
      const overlay = costruisciOverlay();
      document.body.appendChild(overlay);

      const elEmail    = overlay.querySelector('#cardsync-auth-email');
      const elPassword = overlay.querySelector('#cardsync-auth-password');
      const elErrore    = overlay.querySelector('#cardsync-auth-error');
      const elSubmit    = overlay.querySelector('#cardsync-auth-submit');

      async function tentaLogin() {
        const inputUtente = elEmail.value.trim();
        const password = elPassword.value;
        if (!inputUtente || !password) {
          elErrore.textContent = 'Inserisci nome utente e password.';
          elErrore.style.display = 'block';
          return;
        }
        // Chi digita solo il nome ("irene") lo trasformiamo in email
        // completa dietro le quinte — Supabase Auth richiede comunque
        // un'email valida, ma l'utente non deve più saperlo né digitarla
        // per intero. Se qualcuno incolla già l'email completa (abitudine
        // precedente), la usiamo così com'è.
        const email = inputUtente.includes('@') ? inputUtente : inputUtente.toLowerCase() + '@cardsyncpro.local';
        elSubmit.disabled = true;
        elSubmit.textContent = 'Accesso in corso…';
        elErrore.style.display = 'none';

        const { data: loginData, error } = await supabaseClient.auth.signInWithPassword({ email, password });
        if (error) {
          elErrore.textContent = '❌ ' + (error.message === 'Invalid login credentials'
            ? 'Nome utente o password errati.'
            : error.message);
          elErrore.style.display = 'block';
          elSubmit.disabled = false;
          elSubmit.textContent = 'Accedi';
          return;
        }

        overlay.remove();
        mostraBottoneLogout(loginData.session.user.email);
        resolve(loginData.session);
      }

      elSubmit.addEventListener('click', tentaLogin);
      [elEmail, elPassword].forEach((el) => {
        el.addEventListener('keydown', (e) => { if (e.key === 'Enter') tentaLogin(); });
      });
      elEmail.focus();
    });
  };
})();
