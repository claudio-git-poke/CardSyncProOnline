// ── auth_ui.js ────────────────────────────────────────────────────────────────
// Modulo di login condiviso: sostituisce i prompt() temporanei usati durante
// lo sviluppo con un vero modulo grafico, riusato identico da tutte le pagine
// dell'estensione (popup, hub, carte, sealed, wishlist, anteprima). Richiede
// che supabase.bundle.js e supabase_adapter.js siano già caricati PRIMA di
// questo file (usa la variabile globale supabaseClient definita lì).
//
// Uso in ogni pagina, al posto del vecchio blocco IIFE con prompt():
//   assicuraLoginSupabase();
//
// La funzione controlla se esiste già una sessione salvata (chrome.storage
// persiste il login tra le pagine, quindi nella maggior parte dei casi non
// succede nulla di visibile) — solo se NON c'è una sessione valida mostra il
// modulo a schermo intero, bloccando l'interazione con la pagina finché non
// viene completato un login riuscito.

(function () {
  const STILE_ID = 'cardsync-auth-ui-style';

  function iniettaStile() {
    if (document.getElementById(STILE_ID)) return;
    const style = document.createElement('style');
    style.id = STILE_ID;
    style.textContent = `
      #cardsync-auth-overlay {
        position: fixed; inset: 0; z-index: 999999;
        background: rgba(20, 16, 32, 0.72);
        display: flex; align-items: center; justify-content: center;
        font-family: 'DM Sans', -apple-system, BlinkMacSystemFont, sans-serif;
      }
      #cardsync-auth-card {
        background: #ffffff; color: #1a1625;
        width: min(340px, 90vw);
        border-radius: 16px;
        padding: 28px 26px 24px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.35);
      }
      #cardsync-auth-card h2 {
        margin: 0 0 4px; font-size: 18px; font-weight: 700;
      }
      #cardsync-auth-card p.sub {
        margin: 0 0 20px; font-size: 12.5px; color: #6b6478;
      }
      #cardsync-auth-card label {
        display: block; font-size: 12px; font-weight: 600;
        color: #4a4458; margin: 12px 0 5px;
      }
      #cardsync-auth-card input {
        width: 100%; box-sizing: border-box;
        padding: 9px 11px; border-radius: 9px;
        border: 1.5px solid #e0dce8; font-size: 14px;
        font-family: inherit;
      }
      #cardsync-auth-card input:focus {
        outline: none; border-color: #7c5cff;
      }
      #cardsync-auth-error {
        display: none; margin-top: 12px; padding: 9px 11px;
        background: #fdeaea; color: #b3261e; border-radius: 8px;
        font-size: 12.5px; line-height: 1.4;
      }
      #cardsync-auth-submit {
        width: 100%; margin-top: 18px; padding: 10px;
        border: none; border-radius: 10px;
        background: #7c5cff; color: #fff;
        font-size: 14px; font-weight: 700; cursor: pointer;
        font-family: inherit;
      }
      #cardsync-auth-submit:disabled {
        opacity: 0.6; cursor: default;
      }
      #cardsync-auth-submit:not(:disabled):hover {
        background: #6a4ce0;
      }
      #cardsync-logout-btn {
        position: fixed; bottom: 14px; right: 14px; z-index: 999998;
        background: rgba(20, 16, 32, 0.55); color: #fff;
        border: none; border-radius: 20px;
        padding: 6px 12px; font-size: 11.5px; font-weight: 600;
        font-family: 'DM Sans', -apple-system, BlinkMacSystemFont, sans-serif;
        cursor: pointer; display: flex; align-items: center; gap: 5px;
        opacity: 0.55; transition: opacity 0.15s;
      }
      #cardsync-logout-btn:hover { opacity: 1; }

      /* ── WIZARD AGGIORNAMENTO OBBLIGATORIO ────────────────────────────── */
      #cardsync-update-card {
        background: #ffffff; color: #1a1625;
        width: min(420px, 92vw);
        border-radius: 18px;
        padding: 28px 26px 24px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.35);
      }
      #cardsync-update-dots { display: flex; gap: 6px; justify-content: center; margin-bottom: 18px; }
      .cardsync-update-dot { width: 7px; height: 7px; border-radius: 50%; background: #e0dce8; transition: background .2s; }
      .cardsync-update-dot.attivo { background: #7c5cff; }
      .cardsync-update-slide h2 { margin: 0 0 10px; font-size: 17px; font-weight: 800; }
      .cardsync-update-slide p { margin: 0 0 8px; font-size: 13px; color: #6b6478; line-height: 1.5; }
      .cardsync-update-tasto {
        font-weight: 800; font-size: 14px; background: #f6f4fb;
        border: 1px solid #e0dce8; border-bottom-width: 3px; border-radius: 8px;
        padding: 7px 13px; color: #1a1625;
      }
      #cardsync-update-comando {
        display: flex; align-items: center; gap: 8px;
        background: #f6f4fb; border: 1px solid #e0dce8; border-radius: 8px;
        padding: 9px 11px; margin: 10px 0;
      }
      #cardsync-update-comando code { flex: 1; font-size: 11px; word-break: break-all; user-select: all; }
      #cardsync-update-copia {
        flex-shrink: 0; border: none; background: #7c5cff; color: #fff;
        border-radius: 6px; padding: 7px 9px; cursor: pointer; font-size: 13px;
      }
      #cardsync-update-nav { display: flex; gap: 10px; margin-top: 18px; }
      #cardsync-update-nav button {
        flex: 1; padding: 10px; border-radius: 10px; border: none;
        font-size: 13px; font-weight: 700; cursor: pointer; font-family: inherit;
      }
      #cardsync-update-indietro { background: #f0eefb; color: #4a4458; }
      #cardsync-update-avanti { background: #7c5cff; color: #fff; }
    `;
    document.head.appendChild(style);
  }

  // Confronta due versioni tipo "3.14" vs "3.9" NUMERICAMENTE per ogni
  // parte (non come testo — altrimenti "3.9" risulterebbe "maggiore" di
  // "3.14" per un confronto alfabetico ingannevole).
  function versioneMaggiore(a, b) {
    const pa = String(a).split('.').map(Number);
    const pb = String(b).split('.').map(Number);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
      const na = pa[i] || 0, nb = pb[i] || 0;
      if (na > nb) return true;
      if (na < nb) return false;
    }
    return false;
  }

  const URL_ULTIMA_VERSIONE = 'https://claudio-git-poke.github.io/CardSyncProOnline/releases/latest-version.txt';
  const COMANDO_AGGIORNAMENTO = 'irm https://claudio-git-poke.github.io/CardSyncProOnline/releases/aggiorna_cardsync.bat -OutFile "$env:TEMP\\aggiorna_cardsync.bat"; & "$env:TEMP\\aggiorna_cardsync.bat"';

  const SLIDE_AGGIORNAMENTO = [
    {
      titolo: '🔄 Aggiornamento obbligatorio',
      corpo: `<p>C'è una versione più recente di CardSync Pro — <strong>è obbligatorio aggiornare per continuare, sorry not sorry</strong>.</p><p>3 passi veloci, solo la prima volta con qualche domanda in più. Funziona solo su Windows.</p>`,
    },
    {
      titolo: 'Passo 1 — Apri PowerShell',
      corpo: `<div style="display:flex; align-items:center; justify-content:center; gap:8px; background:#f6f4fb; border:1px solid #e0dce8; border-radius:10px; padding:14px; margin-bottom:10px;"><span class="cardsync-update-tasto">⊞ Win</span><span style="font-weight:800; color:#6b6478;">+</span><span class="cardsync-update-tasto">X</span></div><p>Tieni premuto il tasto <strong>Windows</strong> e premi <strong>X</strong>. Clicca su <strong>"Terminale"</strong> o <strong>"Windows PowerShell"</strong> nel menu che compare.</p>`,
    },
    {
      titolo: 'Passo 2 — Copia e incolla il comando',
      corpo: `<div id="cardsync-update-comando"><code>${COMANDO_AGGIORNAMENTO}</code><button id="cardsync-update-copia" title="Copia">📋</button></div><p>Clicca l'icona per copiarlo, poi in PowerShell: tasto destro per incollare, e premi <strong>Invio</strong>.</p>`,
    },
    {
      titolo: 'Passo 3 — Fatto, pensa a tutto lui',
      corpo: `<p>Solo la prima volta potrebbe chiederti dove hai l'estensione — le volte dopo se la ricorda.</p><p>Scarica, installa e riavvia Chrome da solo. Quando Chrome si riapre, questa finestra sparisce da sola.</p>`,
    },
  ];

  function iniettaStileWizard() { iniettaStile(); }

  function costruisciWizardAggiornamento() {
    const overlay = document.createElement('div');
    overlay.id = 'cardsync-auth-overlay';
    const card = document.createElement('div');
    card.id = 'cardsync-update-card';
    overlay.appendChild(card);

    let slideAttuale = 0;

    function disegna() {
      const s = SLIDE_AGGIORNAMENTO[slideAttuale];
      card.innerHTML = `
        <div id="cardsync-update-dots">
          ${SLIDE_AGGIORNAMENTO.map((_, i) => `<span class="cardsync-update-dot${i === slideAttuale ? ' attivo' : ''}"></span>`).join('')}
        </div>
        <div class="cardsync-update-slide">
          <h2>${s.titolo}</h2>
          ${s.corpo}
        </div>
        <div id="cardsync-update-nav">
          <button id="cardsync-update-indietro" style="visibility:${slideAttuale === 0 ? 'hidden' : 'visible'};">← Indietro</button>
          <button id="cardsync-update-avanti">${slideAttuale === SLIDE_AGGIORNAMENTO.length - 1 ? 'Ricontrolla ↻' : 'Avanti →'}</button>
        </div>
      `;
      card.querySelector('#cardsync-update-indietro').addEventListener('click', () => { slideAttuale = Math.max(0, slideAttuale - 1); disegna(); });
      card.querySelector('#cardsync-update-avanti').addEventListener('click', () => {
        if (slideAttuale === SLIDE_AGGIORNAMENTO.length - 1) {
          // "Ricontrolla" sull'ultima slide: se l'utente ha già aggiornato e
          // riavviato Chrome, questa pagina si sarà già ricaricata da sola —
          // ma nel caso stia ancora aspettando, un ricontrollo manuale non
          // fa mai male (rifà semplicemente il confronto versione).
          location.reload();
          return;
        }
        slideAttuale = Math.min(SLIDE_AGGIORNAMENTO.length - 1, slideAttuale + 1);
        disegna();
      });
      const btnCopia = card.querySelector('#cardsync-update-copia');
      if (btnCopia) {
        btnCopia.addEventListener('click', () => {
          navigator.clipboard.writeText(COMANDO_AGGIORNAMENTO).then(() => {
            btnCopia.textContent = '✅';
            setTimeout(() => { btnCopia.textContent = '📋'; }, 1500);
          });
        });
      }
    }

    disegna();
    return overlay;
  }

  // Controlla se è disponibile una versione più recente di quella
  // installata — se sì, blocca TUTTO (nemmeno il login è raggiungibile)
  // finché non si aggiorna. Fallisce in modo silenzioso e permissivo se il
  // controllo stesso non riesce (es. offline): meglio lasciar lavorare
  // qualcuno senza internet che bloccarlo per un controllo che non può
  // nemmeno completarsi.
  function controllaVersioneObbligatoria() {
    return new Promise((resolve) => {
      const versioneLocale = chrome.runtime.getManifest().version;
      fetch(URL_ULTIMA_VERSIONE + '?t=' + Date.now(), { cache: 'no-store' })
        .then((r) => (r.ok ? r.text() : null))
        .then((testo) => {
          const versioneRemota = (testo || '').trim();
          if (!versioneRemota || !versioneMaggiore(versioneRemota, versioneLocale)) {
            resolve(false); // già aggiornato, o controllo non valido — non blocca
            return;
          }
          iniettaStileWizard();
          const overlay = costruisciWizardAggiornamento();
          document.body.appendChild(overlay);
          resolve(true); // bloccato — il chiamante non deve proseguire
        })
        .catch(() => resolve(false)); // offline o errore di rete — non blocca
    });
  }

  function costruisciOverlay() {
    const overlay = document.createElement('div');
    overlay.id = 'cardsync-auth-overlay';
    overlay.innerHTML = `
      <div id="cardsync-auth-card">
        <h2>🔐 Accedi a CardSync Pro</h2>
        <p class="sub">Usa l'account che ti è stato assegnato per la tua collezione.</p>
        <label for="cardsync-auth-email">Nome utente</label>
        <input type="text" id="cardsync-auth-email" autocomplete="username" placeholder="es. irene" />
        <label for="cardsync-auth-password">Password</label>
        <input type="password" id="cardsync-auth-password" autocomplete="current-password" />
        <div id="cardsync-auth-error"></div>
        <button id="cardsync-auth-submit">Accedi</button>
      </div>
    `;
    return overlay;
  }

  function mostraBottoneLogout(email) {
    if (document.getElementById('cardsync-logout-btn')) return; // già presente
    const btn = document.createElement('button');
    btn.id = 'cardsync-logout-btn';
    btn.title = 'Esci da CardSync Pro (' + email + ')';
    btn.innerHTML = '🚪 Esci';
    btn.addEventListener('click', async () => {
      if (!confirm('Uscire da CardSync Pro (' + email + ')?\n\nDovrai rifare il login per usare l\'estensione.')) return;
      await supabaseClient.auth.signOut();
      location.reload();
    });
    document.body.appendChild(btn);
  }

  // Espone la funzione di logout anche per un eventuale pulsante nella UI
  // vera in futuro (es. dentro il menu account), non solo quello fisso.
  window.logoutSupabase = async function () {
    await supabaseClient.auth.signOut();
    location.reload();
  };

  // Restituisce una Promise che si risolve quando l'utente ha (o aveva già)
  // una sessione Supabase valida. Sicura da chiamare più volte: se una
  // sessione esiste già, si risolve subito senza mostrare nulla a schermo.
  window.assicuraLoginSupabase = function () {
    return new Promise(async (resolve) => {
      // Controllo versione OBBLIGATORIO — prima di qualunque altra cosa,
      // nemmeno il login è raggiungibile se c'è un aggiornamento disponibile.
      const bloccatoDaAggiornamento = await controllaVersioneObbligatoria();
      if (bloccatoDaAggiornamento) return; // non risolve mai la Promise: la pagina resta bloccata

      const { data } = await supabaseClient.auth.getSession();
      if (data.session) {
        mostraBottoneLogout(data.session.user.email);
        resolve(data.session);
        return;
      }

      iniettaStile();
      const overlay = costruisciOverlay();
      document.body.appendChild(overlay);

      const elEmail    = overlay.querySelector('#cardsync-auth-email');
      const elPassword = overlay.querySelector('#cardsync-auth-password');
      const elErrore    = overlay.querySelector('#cardsync-auth-error');
      const elSubmit    = overlay.querySelector('#cardsync-auth-submit');

      async function tentaLogin() {
        const inputUtente = elEmail.value.trim();
        const password = elPassword.value;
        if (!inputUtente || !password) {
          elErrore.textContent = 'Inserisci nome utente e password.';
          elErrore.style.display = 'block';
          return;
        }
        // Chi digita solo il nome ("irene") lo trasformiamo in email
        // completa dietro le quinte — Supabase Auth richiede comunque
        // un'email valida, ma l'utente non deve più saperlo né digitarla
        // per intero. Se qualcuno incolla già l'email completa (abitudine
        // precedente), la usiamo così com'è.
        const email = inputUtente.includes('@') ? inputUtente : inputUtente.toLowerCase() + '@cardsyncpro.local';
        elSubmit.disabled = true;
        elSubmit.textContent = 'Accesso in corso…';
        elErrore.style.display = 'none';

        const { data: loginData, error } = await supabaseClient.auth.signInWithPassword({ email, password });
        if (error) {
          elErrore.textContent = '❌ ' + (error.message === 'Invalid login credentials'
            ? 'Nome utente o password errati.'
            : error.message);
          elErrore.style.display = 'block';
          elSubmit.disabled = false;
          elSubmit.textContent = 'Accedi';
          return;
        }

        overlay.remove();
        mostraBottoneLogout(loginData.session.user.email);
        resolve(loginData.session);
      }

      elSubmit.addEventListener('click', tentaLogin);
      [elEmail, elPassword].forEach((el) => {
        el.addEventListener('keydown', (e) => { if (e.key === 'Enter') tentaLogin(); });
      });
      elEmail.focus();
    });
  };
})();
