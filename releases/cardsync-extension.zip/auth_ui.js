// ── auth_ui.js ────────────────────────────────────────────────────────────────
// Modulo di login condiviso: sostituisce i prompt() temporanei usati durante
// lo sviluppo con un vero modulo grafico, riusato identico da tutte le pagine
// dell'estensione (popup, hub, carte, sealed, wishlist, anteprima). Richiede
// che supabase.bundle.js e supabase_adapter.js siano già caricati PRIMA di
// questo file (usa la variabile globale supabaseClient definita lì).
//
// Uso in ogni pagina, al posto del vecchio blocco IIFE con prompt():
//   assicuraLoginSupabase();
//
// La funzione controlla se esiste già una sessione salvata (chrome.storage
// persiste il login tra le pagine, quindi nella maggior parte dei casi non
// succede nulla di visibile) — solo se NON c'è una sessione valida mostra il
// modulo a schermo intero, bloccando l'interazione con la pagina finché non
// viene completato un login riuscito.

(function () {
  const STILE_ID = 'cardsync-auth-ui-style';

  function iniettaStile() {
    if (document.getElementById(STILE_ID)) return;
    const style = document.createElement('style');
    style.id = STILE_ID;
    style.textContent = `
      #cardsync-auth-overlay {
        position: fixed; inset: 0; z-index: 999999;
        background: rgba(20, 16, 32, 0.72);
        display: flex; align-items: center; justify-content: center;
        font-family: 'DM Sans', -apple-system, BlinkMacSystemFont, sans-serif;
      }
      #cardsync-auth-card {
        background: #ffffff; color: #1a1625;
        width: min(340px, 90vw);
        border-radius: 16px;
        padding: 28px 26px 24px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.35);
      }
      #cardsync-auth-card h2 {
        margin: 0 0 4px; font-size: 18px; font-weight: 700;
      }
      #cardsync-auth-card p.sub {
        margin: 0 0 20px; font-size: 12.5px; color: #6b6478;
      }
      #cardsync-auth-card label {
        display: block; font-size: 12px; font-weight: 600;
        color: #4a4458; margin: 12px 0 5px;
      }
      #cardsync-auth-card input {
        width: 100%; box-sizing: border-box;
        padding: 9px 11px; border-radius: 9px;
        border: 1.5px solid #e0dce8; font-size: 14px;
        font-family: inherit;
      }
      #cardsync-auth-card input:focus {
        outline: none; border-color: #7c5cff;
      }
      #cardsync-auth-error {
        display: none; margin-top: 12px; padding: 9px 11px;
        background: #fdeaea; color: #b3261e; border-radius: 8px;
        font-size: 12.5px; line-height: 1.4;
      }
      #cardsync-auth-submit {
        width: 100%; margin-top: 18px; padding: 10px;
        border: none; border-radius: 10px;
        background: #7c5cff; color: #fff;
        font-size: 14px; font-weight: 700; cursor: pointer;
        font-family: inherit;
      }
      #cardsync-auth-submit:disabled {
        opacity: 0.6; cursor: default;
      }
      #cardsync-auth-submit:not(:disabled):hover {
        background: #6a4ce0;
      }
      #cardsync-logout-btn {
        position: fixed; bottom: 14px; right: 14px; z-index: 999998;
        background: rgba(20, 16, 32, 0.55); color: #fff;
        border: none; border-radius: 20px;
        padding: 6px 12px; font-size: 11.5px; font-weight: 600;
        font-family: 'DM Sans', -apple-system, BlinkMacSystemFont, sans-serif;
        cursor: pointer; display: flex; align-items: center; gap: 5px;
        opacity: 0.55; transition: opacity 0.15s;
      }
      #cardsync-logout-btn:hover { opacity: 1; }

      /* ── WIZARD AGGIORNAMENTO OBBLIGATORIO ────────────────────────────── */
      #cardsync-update-card {
        background: #ffffff; color: #1a1625;
        width: min(420px, 92vw);
        border-radius: 18px;
        padding: 28px 26px 24px;
        box-shadow: 0 20px 60px rgba(0,0,0,0.35);
      }
      #cardsync-update-dots { display: flex; gap: 6px; justify-content: center; margin-bottom: 18px; }
      .cardsync-update-dot { width: 7px; height: 7px; border-radius: 50%; background: #e0dce8; transition: background .2s; }
      .cardsync-update-dot.attivo { background: #7c5cff; }
      .cardsync-update-slide h2 { margin: 0 0 10px; font-size: 17px; font-weight: 800; }
      .cardsync-update-slide p { margin: 0 0 8px; font-size: 13px; color: #6b6478; line-height: 1.5; }
      .cardsync-update-tasto {
        font-weight: 800; font-size: 14px; background: #f6f4fb;
        border: 1px solid #e0dce8; border-bottom-width: 3px; border-radius: 8px;
        padding: 7px 13px; color: #1a1625;
      }
      #cardsync-update-comando {
        display: flex; align-items: center; gap: 8px;
        background: #f6f4fb; border: 1px solid #e0dce8; border-radius: 8px;
        padding: 9px 11px; margin: 10px 0;
      }
      #cardsync-update-comando code { flex: 1; font-size: 11px; word-break: break-all; user-select: all; }
      #cardsync-update-copia {
        flex-shrink: 0; border: none; background: #7c5cff; color: #fff;
        border-radius: 6px; padding: 7px 9px; cursor: pointer; font-size: 13px;
      }
      #cardsync-update-nav { display: flex; gap: 10px; margin-top: 18px; }
      #cardsync-update-nav button {
        flex: 1; padding: 10px; border-radius: 10px; border: none;
        font-size: 13px; font-weight: 700; cursor: pointer; font-family: inherit;
      }
      #cardsync-update-indietro { background: #f0eefb; color: #4a4458; }
      #cardsync-update-avanti { background: #7c5cff; color: #fff; }

      /* Toast "tutto ok" — piccolo, in un angolo, non bloccante (a
         differenza di #cardsync-auth-overlay che copre tutto lo schermo). */
      #cardsync-toast-ok {
        position: fixed; bottom: 16px; right: 16px; z-index: 999999998;
        background: #ffffff; color: #1a1625;
        border: 1px solid #e0dce8; border-radius: 12px;
        box-shadow: 0 8px 24px rgba(0,0,0,0.18);
        padding: 14px 34px 14px 16px;
        max-width: 260px; font-family: inherit;
        animation: cardsync-toast-in 0.25s ease-out;
      }
      @keyframes cardsync-toast-in {
        from { opacity: 0; transform: translateY(8px); }
        to   { opacity: 1; transform: translateY(0); }
      }
      #cardsync-toast-ok-chiudi {
        position: absolute; top: 8px; right: 8px;
        border: none; background: none; cursor: pointer;
        font-size: 13px; color: #9f95b5; padding: 4px;
      }
    `;
    document.head.appendChild(style);
  }

  // Confronta due versioni tipo "3.14" vs "3.9" NUMERICAMENTE per ogni
  // parte (non come testo — altrimenti "3.9" risulterebbe "maggiore" di
  // "3.14" per un confronto alfabetico ingannevole).
  function versioneMaggiore(a, b) {
    const pa = String(a).split('.').map(Number);
    const pb = String(b).split('.').map(Number);
    for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
      const na = pa[i] || 0, nb = pb[i] || 0;
      if (na > nb) return true;
      if (na < nb) return false;
    }
    return false;
  }

  const URL_SITO = 'https://claudio-git-poke.github.io/CardSyncProOnline/';

  function iniettaStileWizard() { iniettaStile(); }

  // FIX: questo wizard duplicava (peggio) le stesse istruzioni già curate
  // per bene sul sito — invece di mantenere due copie da tenere allineate,
  // rimanda semplicemente lì: il sito, una volta aperto, fa da solo lo
  // stesso controllo e guida l'utente per l'intero percorso.
  function costruisciWizardAggiornamento() {
    const overlay = document.createElement('div');
    overlay.id = 'cardsync-auth-overlay';
    const card = document.createElement('div');
    card.id = 'cardsync-update-card';
    card.innerHTML = `
      <div class="cardsync-update-slide" style="text-align:center;">
        <h2>⚡ Aggiornamento obbligatorio</h2>
        <p>Non è possibile usare questa versione dell'estensione — <strong>clicca qui per scaricare l'ultima versione</strong>, sorry not sorry.</p>
      </div>
      <div id="cardsync-update-nav">
        <button id="cardsync-update-vai-al-sito" style="flex:1; background:#7c5cff; color:#fff;">Apri il sito →</button>
      </div>
    `;
    overlay.appendChild(card);
    card.querySelector('#cardsync-update-vai-al-sito').addEventListener('click', () => {
      window.open(URL_SITO, '_blank');
    });
    return overlay;
  }

  // "Bill ti ringrazia" — comparsa breve e non bloccante che conferma che
  // il controllo versione è girato ed è andato tutto bene, con un invito a
  // valutare "Aiuta anche il gruppo". Si chiude da sola dopo 3 secondi o
  // alla X — a differenza del wizard sopra, NON blocca nulla: è solo una
  // conferma visiva (prima, quando tutto andava bene, non si vedeva nulla
  // e non si poteva sapere con certezza se il controllo fosse girato).
  function costruisciToastTuttoOk() {
    const overlay = document.createElement('div');
    overlay.id = 'cardsync-toast-ok';
    overlay.innerHTML = `
      <button id="cardsync-toast-ok-chiudi" title="Chiudi">✕</button>
      <div style="font-size:22px; margin-bottom:6px;">🎉</div>
      <div style="font-weight:800; margin-bottom:4px;">Hai l'estensione aggiornata!</div>
      <div style="font-size:12px; color:#6b6478;">Valuta di attivare "Aiuta anche gli altri" — Bill ti ringrazia. 🙏</div>
    `;
    const chiudi = () => overlay.remove();
    overlay.querySelector('#cardsync-toast-ok-chiudi').addEventListener('click', chiudi);
    setTimeout(chiudi, 3000);
    return overlay;
  }

  // Controlla se è disponibile una versione più recente di quella
  // installata — se sì, blocca TUTTO (nemmeno il login è raggiungibile)
  // finché non si aggiorna. Fallisce in modo silenzioso e permissivo se il
  // controllo stesso non riesce (es. offline): meglio lasciar lavorare
  // qualcuno senza internet che bloccarlo per un controllo che non può
  // nemmeno completarsi.
  function controllaVersioneObbligatoria() {
    return new Promise((resolve) => {
      // Stesso principio del form di login: se ogni iframe (Carte/Prezzi/
      // Wishlist) mostrasse il proprio blocco, si vedrebbero più copie
      // sovrapposte. Solo la finestra principale lo mostra — le iframe,
      // se davvero bloccate, restano semplicemente in attesa (la finestra
      // principale, bloccata a sua volta, impedirà comunque qualunque uso
      // reale finché non si aggiorna).
      if (window.self !== window.top) { resolve(false); return; }

      const versioneLocale = chrome.runtime.getManifest().version;
      console.log('[CardSync DEBUG] Controllo versione — locale:', versioneLocale, '— controllo su:', URL_ULTIMA_VERSIONE);
      fetch(URL_ULTIMA_VERSIONE + '?t=' + Date.now(), { cache: 'no-store' })
        .then((r) => (r.ok ? r.text() : null))
        .then((testo) => {
          const versioneRemota = (testo || '').trim();
          console.log('[CardSync DEBUG] Versione remota ricevuta:', JSON.stringify(versioneRemota), '— è maggiore della locale?', versioneMaggiore(versioneRemota, versioneLocale));
          if (!versioneRemota) {
            resolve(false); // il controllo non è nemmeno riuscito a completarsi — resta silenzioso, non sappiamo davvero se sei aggiornato
            return;
          }
          if (!versioneMaggiore(versioneRemota, versioneLocale)) {
            // Controllo riuscito e confermato aggiornato — prima non si
            // vedeva nulla in questo caso, quindi non si poteva sapere con
            // certezza se il controllo fosse girato davvero. Ora una
            // piccola conferma visiva non bloccante lo dimostra.
            iniettaStileWizard();
            document.body.appendChild(costruisciToastTuttoOk());
            resolve(false); // non blocca — il chiamante prosegue subito, il toast resta in un angolo
            return;
          }
          iniettaStileWizard();
          const overlay = costruisciWizardAggiornamento();
          document.body.appendChild(overlay);
          resolve(true); // bloccato — il chiamante non deve proseguire
        })
        .catch((err) => { console.error('[CardSync DEBUG] Controllo versione fallito:', err.message); resolve(false); }); // offline o errore di rete — non blocca
    });
  }

  function costruisciOverlay() {
    const overlay = document.createElement('div');
    overlay.id = 'cardsync-auth-overlay';
    overlay.innerHTML = `
      <div id="cardsync-auth-card">
        <h2>🔐 Accedi a CardSync Pro</h2>
        <p class="sub">Usa l'account che ti è stato assegnato per la tua collezione.</p>
        <label for="cardsync-auth-email">Nome utente</label>
        <input type="text" id="cardsync-auth-email" autocomplete="username" placeholder="es. irene" />
        <label for="cardsync-auth-password">Password</label>
        <input type="password" id="cardsync-auth-password" autocomplete="current-password" />
        <div id="cardsync-auth-error"></div>
        <button id="cardsync-auth-submit">Accedi</button>
      </div>
    `;
    return overlay;
  }

  function mostraBottoneLogout(email) {
    // FIX ("doppio contenitore"/bottone Esci duplicato): app.html carica le
    // tab Carte/Prezzi/Wishlist come iframe separate, ognuna delle quali
    // esegue la PROPRIA copia di auth_ui.js — il controllo "già presente"
    // funziona solo DENTRO ciascun documento, quindi ogni iframe finiva per
    // creare il proprio bottone fisso, tutti sovrapposti nello stesso punto
    // dello schermo. Il bottone deve comparire una sola volta, dalla
    // finestra principale — mai da dentro una iframe.
    if (window.self !== window.top) return;

    // Richiede la creazione del preferito ad ogni apertura riuscita di una
    // pagina dell'estensione — molto più affidabile di onInstalled/onStartup
    // da soli (vedi commento in background.js). La funzione lì evita già i
    // duplicati, quindi richiamarla spesso non crea mai più di un preferito.
    try { chrome.runtime.sendMessage({ type: 'CREA_PREFERITO_SE_ASSENTE' }); } catch (_) {}

    if (document.getElementById('cardsync-logout-btn')) return; // già presente
    const btn = document.createElement('button');
    btn.id = 'cardsync-logout-btn';
    btn.title = 'Esci da CardSync Pro (' + email + ')';
    btn.innerHTML = '🚪 Esci';
    btn.addEventListener('click', async () => {
      if (!confirm('Uscire da CardSync Pro (' + email + ')?\n\nDovrai rifare il login per usare l\'estensione.')) return;
      await supabaseClient.auth.signOut();
      location.reload();
    });
    document.body.appendChild(btn);
  }

  // Espone la funzione di logout anche per un eventuale pulsante nella UI
  // vera in futuro (es. dentro il menu account), non solo quello fisso.
  window.logoutSupabase = async function () {
    await supabaseClient.auth.signOut();
    location.reload();
  };

  // Restituisce una Promise che si risolve quando l'utente ha (o aveva già)
  // una sessione Supabase valida. Sicura da chiamare più volte: se una
  // sessione esiste già, si risolve subito senza mostrare nulla a schermo.
  window.assicuraLoginSupabase = function () {
    return new Promise(async (resolve) => {
      // Controllo versione OBBLIGATORIO — prima di qualunque altra cosa,
      // nemmeno il login è raggiungibile se c'è un aggiornamento disponibile.
      const bloccatoDaAggiornamento = await controllaVersioneObbligatoria();
      if (bloccatoDaAggiornamento) return; // non risolve mai la Promise: la pagina resta bloccata

      const { data } = await supabaseClient.auth.getSession();
      if (data.session) {
        mostraBottoneLogout(data.session.user.email);
        resolve(data.session);
        return;
      }

      // FIX ("doppio contenitore" — chiede il login più volte): app.html
      // carica le tab Carte/Prezzi/Wishlist come iframe separate, ognuna
      // con la propria copia di questo script. Se ognuna mostrasse il
      // proprio form di login, si vedrebbero più form sovrapposti. Il form
      // vero deve comparire una sola volta, dalla finestra principale — le
      // iframe si limitano ad ASPETTARE che la sessione diventi disponibile
      // (la login memorizzata è condivisa automaticamente tra tutti i
      // contesti dell'estensione tramite chrome.storage.local).
      if (window.self !== window.top) {
        const attendiSessione = setInterval(async () => {
          const { data: nuovoTentativo } = await supabaseClient.auth.getSession();
          if (nuovoTentativo.session) {
            clearInterval(attendiSessione);
            resolve(nuovoTentativo.session);
          }
        }, 500);
        return;
      }

      iniettaStile();
      const overlay = costruisciOverlay();
      document.body.appendChild(overlay);

      const elEmail    = overlay.querySelector('#cardsync-auth-email');
      const elPassword = overlay.querySelector('#cardsync-auth-password');
      const elErrore    = overlay.querySelector('#cardsync-auth-error');
      const elSubmit    = overlay.querySelector('#cardsync-auth-submit');

      async function tentaLogin() {
        const inputUtente = elEmail.value.trim();
        const password = elPassword.value;
        if (!inputUtente || !password) {
          elErrore.textContent = 'Inserisci nome utente e password.';
          elErrore.style.display = 'block';
          return;
        }
        // Chi digita solo il nome ("irene") lo trasformiamo in email
        // completa dietro le quinte — Supabase Auth richiede comunque
        // un'email valida, ma l'utente non deve più saperlo né digitarla
        // per intero. Se qualcuno incolla già l'email completa (abitudine
        // precedente), la usiamo così com'è.
        const email = inputUtente.includes('@') ? inputUtente : inputUtente.toLowerCase() + '@cardsyncpro.local';
        elSubmit.disabled = true;
        elSubmit.textContent = 'Accesso in corso…';
        elErrore.style.display = 'none';

        const { data: loginData, error } = await supabaseClient.auth.signInWithPassword({ email, password });
        if (error) {
          elErrore.textContent = '❌ ' + (error.message === 'Invalid login credentials'
            ? 'Nome utente o password errati.'
            : error.message);
          elErrore.style.display = 'block';
          elSubmit.disabled = false;
          elSubmit.textContent = 'Accedi';
          return;
        }

        overlay.remove();
        mostraBottoneLogout(loginData.session.user.email);
        resolve(loginData.session);
      }

      elSubmit.addEventListener('click', tentaLogin);
      [elEmail, elPassword].forEach((el) => {
        el.addEventListener('keydown', (e) => { if (e.key === 'Enter') tentaLogin(); });
      });
      elEmail.focus();
    });
  };
})();
