# CardSync Pro — Istruzioni

CardSync Pro gestisce una collezione di carte Pokémon (prezzi, scambio,
wishlist, sealed) condivisa da un piccolo gruppo di persone. È composto da
tre pezzi che lavorano insieme:

1. **Il sito** (`https://claudio-git-poke.github.io/CardSyncProOnline/`) —
   dove si passa il 95% del tempo: si vede/gestisce la collezione, si
   cercano carte da aggiungere, si gestisce wishlist/scambio.
2. **L'estensione Chrome** — legge i prezzi da Cardmarket e cerca le carte
   quando se ne aggiunge una nuova (serve un'estensione perché un sito
   normale non può "leggere" un altro sito come Cardmarket).
3. **Un database Supabase** — dove vivono davvero tutti i dati. Sito ed
   estensione parlano entrambi con questo database, mai direttamente tra
   loro.

Non serve più nessun Google Sheet, nessuno script da incollare, nessuna
configurazione manuale di URL o fogli: tutto è già collegato.

---

## PARTE 1 — Installa l'estensione Chrome

1. Apri Chrome e vai su `chrome://extensions`.
2. Attiva **"Modalità sviluppatore"** (interruttore in alto a destra).
3. Clicca **"Carica estensione non pacchettizzata"**.
4. Seleziona la cartella del progetto (quella con `manifest.json`).
5. L'estensione appare nella barra di Chrome 🃏.

Per aggiornamenti successivi, vedi lo script `aggiorna_cardsync.bat`
generato dal sito stesso (pannello di controllo versione) — non richiede di
rifare questi passaggi da capo.

---

## PARTE 2 — Apri il sito e accedi

1. Apri `https://claudio-git-poke.github.io/CardSyncProOnline/`.
2. Il sito controlla da solo se l'estensione è installata e aggiornata
   (comunica direttamente con lei) — se manca o è vecchia, mostra le
   istruzioni; altrimenti chiede di accedere (nome utente + password, lo
   stesso account per tutto: sito ed estensione).
3. In alto trovi **"Apri l'app"** (apre/porta in primo piano l'estensione,
   già collegata con lo stesso account — nessun secondo login) e lo switch
   **"Apri sempre l'app all'apertura del sito da questo dispositivo"**, se
   preferisci che parta da sola ogni volta.

Da qui in poi si usa il sito per (quasi) tutto: vedere la collezione,
cercare carte da aggiungere, controllare i prezzi, gestire wishlist. Le
richieste finiscono in una coda condivisa che l'estensione (se installata
e aperta) elabora da sola in background, scrivendo i risultati nel
database — non serve interagire direttamente con l'estensione per l'uso
quotidiano.

---

## PARTE 3 — L'estensione, colonna per colonna

Aprendola (dal sito o dall'icona nella barra di Chrome) si apre un'unica
pagina con più colonne sempre visibili affiancate:

- **💹 Controllo prezzi** — rilegge periodicamente gli URL Cardmarket già
  salvati e aggiorna prezzo e variazione. Si può avviare anche da qui
  (▶ Avvia / 🧪 Prova per un dry run), oltre che in automatico.
- **➕ Carte** — mostra in tempo reale le carte che l'estensione sta
  cercando e aggiungendo, arrivate dalla coda condivisa (alimentata dal
  sito). Si può anche scrivere/incollare una carta a mano per un caso
  eccezionale che la ricerca automatica non trova (premi Invio).
- **📦 Sealed** — pagina di inserimento bulk manuale (box, ETB, display…),
  al momento non ancora collegata alla coda condivisa del sito.
- **🗂️ Wishlist** — carte da comprare, con prezzo obiettivo.
- **📋 Coda pendente** — vista di sola lettura: cosa c'è in attesa/in corso
  nella coda condivisa in questo momento, ed eventuali errori recenti.
  Utile per verificare che un inserimento fatto dal sito sia stato preso in
  carico.

Tema e tema scuro **non si scelgono più nell'estensione**: arrivano in
automatico dal sito ogni volta che la si apre da lì.

---

## PARTE 4 — Login su Cardmarket (importante)

Diverse operazioni (controllo prezzi, aggiunta carte/sealed) leggono le
offerte da Cardmarket in una tab in background. Cardmarket nasconde il
bottone "Aggiungi al carrello" per le offerte non acquistabili da un
account non loggato, e questo viene usato dall'estensione come controllo
di attendibilità del prezzo — **senza essere loggati, ogni carta rischia di
risultare "Esaurita"**.

Prima di ogni sessione compare un modale di promemoria ("🚀 Recluta il Team
Rocket!"): dopo la conferma, l'estensione verifica *davvero* il login (in
modo silenzioso, senza rubarti il focus se sei già loggato) e blocca
l'avvio se risulti disconnesso, aprendoti una tab per accedere.

---

## PARTE 5 — Sintassi per l'inserimento manuale (Carte/Wishlist)

Quando serve scrivere una carta a mano (ricerca automatica fallita, o
inserimento diretto nell'estensione):

- `CODICE` — attaccato, zeri inclusi: `MEW008`, `SV01006`.
- `NOME NUMERO` — staccati, solo col vero nome carta: `Eevee 55`, `Mew 151`.
- Modificatori opzionali (in qualunque ordine, separati da spazio):
  lingua (`EN`, `JAP`, …), condizione (`NM`, `EX+`, `LP-`, …), `RH` (reverse
  holo), `1ED` (prima edizione).
- **Nomi che contengono parole come EX/GD** (es. "Mew EX"): separa nome e
  modificatori con una virgola — `Mew EX, EX RH` → nome "Mew EX",
  condizione EX, reverse holo. Senza virgola l'ultimo "EX" verrebbe letto
  come condizione.
- **Nota libera** (solo col formato con virgola): dopo la virgola,
  qualunque parola che non sia lingua/condizione/RH/1ED viene scritta come
  nota — `FST007, NM error` → codice FST007, condizione NM, nota "ERROR".
- **In Wishlist**, aggiungi `@PREZZO` in qualunque punto della riga per
  impostare un prezzo obiettivo — es. `MEW008 @15` o `Mew EX, EX @12`.

Esempi validi: `CRI090` · `Eevee 55` · `xBLK026 EN NM RH` · `Mew EX, EX` ·
`FST007, NM error` · `MEW008 @15`

Le carte non riconosciute automaticamente finiscono in un pannello di
**correzione manuale** (link diretto alla ricerca Cardmarket, incolla
l'URL corretto).

---

## Significato dei valori nella cella prezzo

- `Esaurita` — pagina caricata correttamente ma nessuna offerta soddisfa i
  filtri lingua/condizione richiesti.
- `N/D` — la pagina non si è caricata/letta correttamente, riprova più tardi.
- `Timeout` — la pagina ha impiegato troppo a rispondere.
- Cella vuota dopo un blocco Cloudflare non risolto in tempo — la sessione
  passa alla carta successiva.

---

## Struttura dei file (estensione)

```
cardmarket-extension/
├── manifest.json                    — configurazione estensione
├── popup.html / popup.js            — controllo prezzi
├── aggiungi_carta_popup.html/.js    — carte (coda condivisa + inserimento manuale)
├── aggiungi_sealed_popup.html/.js   — sealed (inserimento manuale)
├── aggiungi_wishlist_popup.html/.js — wishlist
├── app.html / app.js                — hub a colonne (pagina unica)
├── coda_pendente.js                 — colonna "Coda pendente" (sola lettura)
├── auth_ui.js                       — login condiviso + controllo versione
├── supabase_adapter.js              — dispatcher centrale verso Supabase
├── changelog.html / changelog.js    — visualizzatore CHANGELOG.md
├── background.js                    — service worker
├── content.js                       — legge il prezzo dalla pagina Cardmarket
├── shared.js                        — mappe/funzioni condivise (lingua, condizione, filtri)
├── tab_detect.js                    — rileva se una pagina è aperta in tab o iframe
├── offscreen.html / offscreen.js    — riproduzione avviso sonoro Cloudflare
└── CHANGELOG.md                     — cronologia versioni
```

---

## Note importanti

- **Lascia Chrome aperto** mentre l'estensione lavora — le sessioni bulk
  possono richiedere diversi minuti su liste lunghe.
- Le sessioni interrotte si possono **riprendere** dal punto esatto in cui
  erano rimaste.
- Un blocco `Error 1015` (rate limit Cardmarket) mette in pausa
  automaticamente per 30 minuti prima di ritentare.
