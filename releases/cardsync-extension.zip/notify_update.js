#!/usr/bin/env node
// ─────────────────────────────────────────────────────────────────────────────
// notify_update.js — Avvisa su Telegram quando esce una nuova versione di
// CardSync Pro, leggendo la versione da manifest.json e la descrizione delle
// novità dalla sezione corrispondente di CHANGELOG.md.
//
// COME FUNZIONA
//   1. Legge la versione corrente da manifest.json.
//   2. La confronta con l'ultima versione già notificata (salvata in un
//      piccolo file .last_notified_version nella stessa cartella).
//   3. Se è cambiata: estrae la sezione del CHANGELOG.md per quella versione,
//      la formatta e la invia al canale Telegram configurato.
//   4. Aggiorna .last_notified_version, così una seconda esecuzione con la
//      stessa versione non manda un doppione.
//
// QUANDO ESEGUIRLO
//   A mano, una volta, ogni volta che pubblichi un aggiornamento (dopo aver
//   alzato "version" in manifest.json e aggiunto la voce in CHANGELOG.md):
//
//     node notify_update.js
//
//   Nessun server necessario: non fa polling, non resta in esecuzione — legge,
//   invia, esce. Vedi ISTRUZIONI_BOT_TELEGRAM.md per il setup completo
//   (creazione bot, creazione canale, configurazione token/chat id).
// ─────────────────────────────────────────────────────────────────────────────

'use strict';

const fs = require('fs');
const path = require('path');
const https = require('https');

// ── CONFIGURAZIONE ───────────────────────────────────────────────────────────
// FIX (sicurezza — credenziali hardcoded): questo file veniva distribuito/
// versionato con un token bot Telegram e un chat id VERI incorporati come
// valore di default (attivo per chiunque eseguisse lo script senza impostare
// le variabili d'ambiente) — chiunque avesse accesso al file poteva usare
// quel token per mandare messaggi nel canale/gruppo configurato. Niente più
// default "veri" qui: le tre variabili vanno SEMPRE impostate via ambiente,
// mai scritte nel codice.
//   TELEGRAM_BOT_TOKEN=123456:ABC-DEF... node notify_update.js
//   TELEGRAM_CHAT_ID=@nomecanale node notify_update.js
//   TELEGRAM_THREAD_ID=5 node notify_update.js   (opzionale)
const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN || '';
// Per un canale PUBBLICO: '@nomecanale' (con la @ davanti).
// Per un canale PRIVATO o un GRUPPO: l'ID numerico negativo, es. '-1001234567890'
// (vedi ISTRUZIONI_BOT_TELEGRAM.md su come ottenerlo).
const CHAT_ID = process.env.TELEGRAM_CHAT_ID || '';

// Opzionale: ID dell'ARGOMENTO (topic) del gruppo in cui mandare le notifiche,
// se il gruppo ha gli Argomenti attivi e vuoi usarne uno dedicato invece della
// chat generale. Lascia non impostata la variabile d'ambiente per mandare
// nell'argomento "Generale" di default (o se il gruppo non usa gli Argomenti).
// Vedi ISTRUZIONI_BOT_TELEGRAM.md su come trovare questo numero.
const THREAD_ID = process.env.TELEGRAM_THREAD_ID || '';

// ── PERCORSI ──────────────────────────────────────────────────────────────────
// Per default cerca manifest.json/CHANGELOG.md nella stessa cartella dello
// script: copia notify_update.js dentro la cartella del progetto
// dell'estensione, oppure passa un percorso diverso con --dir=/percorso.
const argDir = process.argv.find(a => a.startsWith('--dir='));
const BASE_DIR = argDir ? argDir.slice('--dir='.length) : __dirname;

// --force: ignora il controllo "versione già notificata" e rimanda comunque
// il messaggio per la versione corrente — utile per rispedire un aggiornamento
// (es. testo corretto nel changelog, o volevi solo re-inviarlo) senza dover
// cancellare a mano il file .last_notified_version.
const FORCE = process.argv.includes('--force');

const MANIFEST_PATH      = path.join(BASE_DIR, 'manifest.json');
const CHANGELOG_PATH     = path.join(BASE_DIR, 'CHANGELOG.md');
const LAST_VERSION_PATH  = path.join(BASE_DIR, '.last_notified_version');

// ── LETTURA VERSIONE ──────────────────────────────────────────────────────────
function leggiVersioneCorrente() {
  const manifest = JSON.parse(fs.readFileSync(MANIFEST_PATH, 'utf8'));
  return manifest.version;
}

function leggiUltimaVersioneNotificata() {
  try {
    return fs.readFileSync(LAST_VERSION_PATH, 'utf8').trim();
  } catch (_) {
    return null; // prima esecuzione: nessuna versione salvata ancora
  }
}

function salvaVersioneNotificata(v) {
  fs.writeFileSync(LAST_VERSION_PATH, v, 'utf8');
}

// ── ESTRAZIONE SEZIONE CHANGELOG ──────────────────────────────────────────────
// Trova il blocco "## vX.XX — data" ... fino al prossimo "## v" (o fine file).
function estraiSezioneChangelog(versione) {
  const testo = fs.readFileSync(CHANGELOG_PATH, 'utf8');
  const righe = testo.split('\n');
  const versioneEsc = versione.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const inizioRe = new RegExp('^##\\s+v' + versioneEsc + '\\b');

  let inizio = -1;
  for (let i = 0; i < righe.length; i++) {
    if (inizioRe.test(righe[i])) { inizio = i; break; }
  }
  if (inizio === -1) return null;

  let fine = righe.length;
  for (let i = inizio + 1; i < righe.length; i++) {
    if (/^##\s+v/.test(righe[i])) { fine = i; break; }
  }
  return righe.slice(inizio, fine).join('\n').trim();
}

// ── FORMATTAZIONE PER TELEGRAM ────────────────────────────────────────────────
// Telegram (con parse_mode 'HTML') supporta solo un sottoinsieme minimo di tag
// (<b>, <i>, <code>, <a>, ecc.) — niente <h1>/<h2>/<ul>. Converte il markdown
// minimale del changelog in testo semplice + <b>/<code>, adatto a un messaggio.
function formattaPerTelegram(sezioneMd, versione) {
  let testo = sezioneMd
    .replace(/^##\s+.*$/m, '')            // rimuove l'intestazione "## vX.XX — data" (già nel titolo messaggio)
    .replace(/^###\s+(.*)$/gm, '\n<b>$1</b>')
    .replace(/\*\*([^*]+)\*\*/g, '<b>$1</b>')
    .replace(/`([^`]+)`/g, '<code>$1</code>')
    .replace(/^-\s+/gm, '• ')
    .replace(/[<>&]/g, (c) => {
      // Escape solo dei simboli che NON fanno parte dei tag appena creati
      // sopra — qui ci limitiamo a & (gli unici < e > rimasti sono i nostri
      // tag <b>/<code>, quindi non li tocchiamo).
      return c === '&' ? '&amp;' : c;
    })
    .trim();

  // Telegram limita i messaggi a 4096 caratteri: tronca con un rimando al
  // changelog completo se la sezione è insolitamente lunga.
  const MAX = 3800;
  if (testo.length > MAX) {
    testo = testo.slice(0, MAX).trim() + '\n\n… (elenco troncato, vedi il changelog completo nell\'estensione)';
  }

  return `🃏 <b>CardSync Pro — nuova versione v${versione}</b>\n\n${testo}\n\n⬇️ Aggiorna l'estensione per avere tutte le novità.`;
}

// ── INVIO TELEGRAM ────────────────────────────────────────────────────────────
function inviaMessaggioTelegram(testo) {
  return new Promise((resolve, reject) => {
    const payload = {
      chat_id: CHAT_ID,
      text: testo,
      parse_mode: 'HTML',
      disable_web_page_preview: true,
    };
    // Se è impostato un argomento (topic) dedicato, il messaggio va lì invece
    // che nella chat/argomento "Generale" di default del gruppo.
    if (THREAD_ID) payload.message_thread_id = Number(THREAD_ID);
    const body = JSON.stringify(payload);
    const options = {
      hostname: 'api.telegram.org',
      path: `/bot${BOT_TOKEN}/sendMessage`,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(body),
      },
    };
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        let risposta;
        try { risposta = JSON.parse(data); } catch (_) { risposta = { ok: false, description: data }; }
        if (risposta.ok) resolve(risposta);
        else reject(new Error('Telegram API error: ' + JSON.stringify(risposta)));
      });
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

// ── MAIN ──────────────────────────────────────────────────────────────────────
async function main() {
  // FIX (sicurezza — credenziali hardcoded): BOT_TOKEN/CHAT_ID non hanno più
  // un valore di default "vero" scritto nel file (vedi commento in cima) —
  // qui basta verificare che le variabili d'ambiente siano state impostate,
  // invece del vecchio confronto contro placeholder che i default reali
  // precedenti non avrebbero comunque mai fatto scattare.
  if (!BOT_TOKEN || !CHAT_ID) {
    console.error(
      '⚠️  Configura BOT_TOKEN e CHAT_ID prima di eseguire lo script, tramite variabili d\'ambiente:\n' +
      '   TELEGRAM_BOT_TOKEN=... TELEGRAM_CHAT_ID=... node notify_update.js\n' +
      '   Vedi ISTRUZIONI_BOT_TELEGRAM.md per come ottenerli.'
    );
    process.exit(1);
  }

  let versioneCorrente;
  try {
    versioneCorrente = leggiVersioneCorrente();
  } catch (e) {
    console.error('❌ Impossibile leggere manifest.json da ' + MANIFEST_PATH + ': ' + e.message);
    console.error('   Se lo script non è nella cartella del progetto, usa --dir=/percorso/progetto');
    process.exit(1);
  }

  const ultimaNotificata = leggiUltimaVersioneNotificata();

  if (versioneCorrente === ultimaNotificata && !FORCE) {
    console.log(`ℹ️  Nessun aggiornamento: versione corrente (${versioneCorrente}) già notificata in precedenza.`);
    console.log('   (Per rimandarla comunque: node notify_update.js --force)');
    return;
  }

  if (versioneCorrente === ultimaNotificata && FORCE) {
    console.log(`🔁 Rinvio forzato della notifica per v${versioneCorrente} (--force).`);
  } else {
    console.log(`🆕 Nuova versione rilevata: ${ultimaNotificata || '(nessuna precedente)'} → ${versioneCorrente}`);
  }

  const sezione = estraiSezioneChangelog(versioneCorrente);
  const testoMessaggio = sezione
    ? formattaPerTelegram(sezione, versioneCorrente)
    : `🃏 <b>CardSync Pro — nuova versione v${versioneCorrente}</b>\n\nNuova versione disponibile — aggiorna l'estensione!`;

  if (!sezione) {
    console.warn('⚠️  Nessuna sezione trovata in CHANGELOG.md per v' + versioneCorrente + ' — invio un messaggio generico.');
  }

  try {
    await inviaMessaggioTelegram(testoMessaggio);
    salvaVersioneNotificata(versioneCorrente);
    console.log(`✅ Notifica inviata su Telegram${THREAD_ID ? ` (argomento #${THREAD_ID})` : ' (chat/argomento Generale)'} e versione salvata in ` + LAST_VERSION_PATH);
  } catch (e) {
    console.error('❌ Errore nell\'invio della notifica:', e.message);
    process.exit(1);
  }
}

main();
