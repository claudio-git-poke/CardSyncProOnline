// ── webapp_registro_profili.gs ───────────────────────────────────────────────
// Script da incollare in un Google Sheet SEPARATO (nuovo, diverso dal tuo
// inventario), che funge da "registro profili" condiviso tra più persone/PC.
// Ogni riga di questo foglio è un profilo (es. "Irene", "Marco"): contiene
// gli stessi dati che oggi si copiano a mano nel riquadro "⚡ Connessione
// Google" (URL Web App, ID Sheet, Nome scheda) più le colonne personalizzate,
// così chi cambia PC/utente può caricarli con un click invece di ridigitarli.
//
// SETUP (una tantum):
//   1. Crea un NUOVO Google Sheet (es. "CardSync — Profili"), separato dal
//      tuo inventario carte.
//   2. Prima riga = intestazioni, in quest'ordine esatto:
//        Nome | WebAppUrl | SheetId | SheetName | ColLocation | ColLingua |
//        ColCondizione | ColUrl | ColPrezzo | ColVariazione | RigaInizio
//      (le colonne dopo SheetName sono opzionali: se lasciate vuote in una
//      riga, l'estensione userà i valori predefiniti già in uso).
//   3. Estensioni → Apps Script → incolla questo file → Salva.
//   4. Distribuisci → Nuova distribuzione → Tipo "App web" → Esegui come
//      "Me" → Accesso "Chiunque" → Distribuisci, autorizza.
//   5. Copia l'URL /exec e incollalo UNA VOLTA nel popup di CardSync Pro,
//      nel riquadro "👤 Profilo condiviso" → "URL registro profili".
//      Va fatto su ogni PC/installazione, ma è un solo campo invece di
//      quattro-cinque da ricopiare ogni volta che cambia la persona.
//
// Attenzione: chiunque abbia l'URL di QUESTA web app può leggere/scrivere
// tutte le righe del registro (quindi vede webAppUrl/sheetId di tutti i
// profili salvati) — va bene per un uso ristretto tra poche persone fidate,
// ma non condividere questo URL più ampiamente di quanto condivideresti le
// credenziali stesse dei fogli.

function doPost(e) {
  try {
    var payload = JSON.parse(e.postData.contents);
    var sheet = SpreadsheetApp.getActiveSpreadsheet().getSheets()[0];

    if (payload.azione === 'elencaProfili') {
      return risposta({ ok: true, profili: _elencaNomiProfili(sheet) });
    }

    if (payload.azione === 'leggiProfilo') {
      var nome = (payload.nome || '').toString().trim();
      var trovato = _trovaProfilo(sheet, nome);
      if (!trovato) return risposta({ ok: false, errore: 'Profilo "' + nome + '" non trovato.' });
      return risposta({ ok: true, profilo: trovato.dati });
    }

    if (payload.azione === 'salvaProfilo') {
      var dati = payload.profilo || {};
      var nomeSalva = (dati.nome || '').toString().trim();
      if (!nomeSalva) return risposta({ ok: false, errore: 'Nome profilo mancante.' });

      var riga = _trovaProfilo(sheet, nomeSalva);
      var valori = [
        nomeSalva,
        dati.webAppUrl || '',
        dati.sheetId || '',
        dati.sheetName || '',
        dati.colLocation || '',
        dati.colLingua || '',
        dati.colCondizione || '',
        dati.colUrl || '',
        dati.colPrezzo || '',
        dati.colVariazione || '',
        dati.rigaInizio || '',
      ];

      if (riga) {
        sheet.getRange(riga.rigaSheet, 1, 1, valori.length).setValues([valori]);
        return risposta({ ok: true, aggiornato: true, riga: riga.rigaSheet });
      } else {
        var ultimaRiga = sheet.getLastRow();
        var rigaNuova = Math.max(ultimaRiga + 1, 2);
        sheet.getRange(rigaNuova, 1, 1, valori.length).setValues([valori]);
        return risposta({ ok: true, aggiornato: false, riga: rigaNuova });
      }
    }

    if (payload.azione === 'eliminaProfilo') {
      var nomeElimina = (payload.nome || '').toString().trim();
      var rigaEl = _trovaProfilo(sheet, nomeElimina);
      if (!rigaEl) return risposta({ ok: false, errore: 'Profilo "' + nomeElimina + '" non trovato.' });
      sheet.deleteRow(rigaEl.rigaSheet);
      return risposta({ ok: true });
    }

    return risposta({ ok: false, errore: "Azione non riconosciuta: '" + payload.azione + "'." });

  } catch (err) {
    return risposta({ ok: false, errore: err.toString() });
  }
}

// Legge tutte le righe (dalla 2 in poi) e restituisce i nomi profilo non vuoti.
function _elencaNomiProfili(sheet) {
  var lastRow = sheet.getLastRow();
  if (lastRow < 2) return [];
  var vals = sheet.getRange(2, 1, lastRow - 1, 1).getValues();
  var nomi = [];
  for (var i = 0; i < vals.length; i++) {
    var n = String(vals[i][0] || '').trim();
    if (n) nomi.push(n);
  }
  return nomi;
}

// Cerca un profilo per nome (case-insensitive). Restituisce { rigaSheet, dati } o null.
function _trovaProfilo(sheet, nome) {
  if (!nome) return null;
  var lastRow = sheet.getLastRow();
  if (lastRow < 2) return null;
  var vals = sheet.getRange(2, 1, lastRow - 1, 11).getValues();
  var nomeUp = nome.toUpperCase();
  for (var i = 0; i < vals.length; i++) {
    var riga = vals[i];
    if (String(riga[0] || '').trim().toUpperCase() === nomeUp) {
      return {
        rigaSheet: i + 2,
        dati: {
          nome:          String(riga[0] || '').trim(),
          webAppUrl:     String(riga[1] || '').trim(),
          sheetId:       String(riga[2] || '').trim(),
          sheetName:     String(riga[3] || '').trim(),
          colLocation:   String(riga[4] || '').trim(),
          colLingua:     String(riga[5] || '').trim(),
          colCondizione: String(riga[6] || '').trim(),
          colUrl:        String(riga[7] || '').trim(),
          colPrezzo:     String(riga[8] || '').trim(),
          colVariazione: String(riga[9] || '').trim(),
          rigaInizio:    String(riga[10] || '').trim(),
        },
      };
    }
  }
  return null;
}

function risposta(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function doOptions() {
  return ContentService.createTextOutput('').setMimeType(ContentService.MimeType.TEXT);
}
