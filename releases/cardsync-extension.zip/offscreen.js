chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'SUONA') {
    const audio = new Audio(message.url);
    audio.volume = 1.0;
    audio.play().catch(() => {
      // Fallback oscillatore
      try {
        const ctx = new (window.AudioContext || window.webkitAudioContext)();
        [0, 0.18, 0.36].forEach((t, i) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.frequency.value = 880 - i * 110;
          gain.gain.setValueAtTime(0.3, ctx.currentTime + t);
          gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + t + 0.15);
          osc.start(ctx.currentTime + t);
          osc.stop(ctx.currentTime + t + 0.15);
        });
      } catch(e) {}
    });
  }
});
