// ── tab_detect.js ─────────────────────────────────────────────────────────────
// Rilevamento contesto TAB vs POPUP, condiviso da popup.html,
// aggiungi_carta_popup.html, aggiungi_sealed_popup.html,
// aggiungi_wishlist_popup.html e anteprima_popup.html.
//
// Le pagine delle estensioni MV3 hanno una Content Security Policy che
// blocca sempre gli script inline (script-src 'self'), quindi questa logica
// deve vivere in un file .js esterno caricato con <script src="…">, non
// direttamente nell'HTML.
//
// Metodo primario: parametro ?modo=tab nell'URL — va aggiunto a mano (o dal
// codice che apre la pagina, come fa popup.js per le pagine "Carte"/"Sealed")
// quando si apre la pagina in una vera tab del browser. Sincrono e
// immediato, nessuna dipendenza da timing/permessi dell'API chrome.tabs.
//
// Fallback: se la pagina è comunque aperta in una vera tab senza il
// parametro, chrome.tabs.getCurrent() restituisce la tab corrente; nel
// popup reale dell'estensione restituisce undefined.
(function () {
  const modalitaTab = new URLSearchParams(location.search).get('modo') === 'tab';
  if (modalitaTab) {
    document.body.classList.add('modalita-tab');
  } else if (chrome.tabs && chrome.tabs.getCurrent) {
    chrome.tabs.getCurrent((tab) => {
      if (tab) document.body.classList.add('modalita-tab');
    });
  }

  // ── RILEVAMENTO "DENTRO L'HUB" (app.html) ──────────────────────────────
  // Quando questa pagina vive in un iframe (non è la finestra di primo
  // livello), l'hub (app.html) mostra già un proprio header unico con
  // profilo/⚙/📜 in cima — l'header di QUESTA pagina (logo, titolo,
  // sottotitolo, bottoni azione) sarebbe duplicato e va nascosto. Il
  // pulsante ⚙ locale resta comunque funzionante nel codice: l'hub lo
  // aziona da fuori inoltrando un postMessage all'iframe attivo (vedi
  // 'CARDSYNC_TOGGLE_SETTINGS' nei rispettivi *_popup.js), così il click
  // su ⚙ nell'hub apre sempre il pannello giusto per la sezione visibile,
  // senza dover duplicare il contenuto del pannello nell'hub stesso.
  if (window.self !== window.top) {
    document.body.classList.add('embedded-in-hub');
  }
})();
