// ── shared.js ─────────────────────────────────────────────────────────────────
// Unica fonte di verità per mappe e funzioni usate in background.js,
// popup.js e aggiungi_carta_popup.js.
//
// Caricamento:
//   - background.js (service worker):  importScripts('shared.js')
//   - popup.html:                      <script src="shared.js"></script>
//   - aggiungi_carta_popup.html:       <script src="shared.js"></script>

// Mappa sigla lingua → idLanguage Cardmarket
const LINGUA_MAP_SHARED = {
  'IT':'5','ITA':'5','EN':'1','ENG':'1','DE':'3','FR':'2','ES':'4',
  'PT':'8','JA':'7','JP':'7','JAP':'7','KOR':'10','CHN':'6','CHN-T':'11',
  'IND':'16','THAI':'17','RU':'9',
};

// Mappa sigla condizione → numero minCondition Cardmarket
const COND_NUM_MAP_SHARED = { 'MT':1,'NM':2,'EX':3,'GD':4,'LP':5,'PL':6,'PO':7 };

/**
 * Costruisce un URL /Singles/ con i parametri language= e minCondition= corretti.
 * Rimuove eventuali valori preesistenti prima di aggiungere i nuovi.
 *
 * Sintassi condizione supportata:
 *   NM   → minCondition=2  (NM o peggio)
 *   NM+  → minCondition=1  (solo MT, ovvero migliore di NM)
 *   NM-  → minCondition=3  (EX o peggio, ovvero peggiore di NM)
 *
 * FIX (bug "Dedenne-V1-DAA78" e ogni altra carta Reverse Holo/Prima Edizione
 * con URL già salvato in H): la versione precedente rimuoveva i parametri
 * con una regex tipo replace(pattern-che-include-"?&"-e-il-nome-parametro)
 * su stringa grezza. Su un URL come
 * "...?language=5&minCondition=2&isReverseHolo=Y", il replace toglie anche
 * il "?" (perché il pattern include [?&]), lasciando "...&isReverseHolo=Y"
 * SENZA alcun "?" residuo. Il controllo successivo url.includes('?') risultava
 * quindi falso, e la funzione ne aggiungeva uno NUOVO dopo isReverseHolo=Y:
 *   ".../Dedenne-V1-DAA78&isReverseHolo=Y?language=5&minCondition=2"
 * "&isReverseHolo=Y" finiva così a far parte del PATH invece che della query
 * string — Cardmarket non trova nessuno slug con quel nome e reindirizza
 * alla pagina dell'espansione (sintomo: link tagliato solo in fase di
 * apertura automatica, mai copiando/incollando l'URL originale a mano).
 * Riscritta con l'API URL/URLSearchParams: qualunque parametro extra già
 * presente (isReverseHolo, isFirstEd, o altri in futuro) resta intatto e il
 * "?" non si perde mai, indipendentemente dall'ordine o dal numero di
 * parametri nell'URL di partenza.
 */
function costruisciUrlFiltrato(urlBase, lingua, condizioneRaw) {
  let u;
  try {
    u = new URL(urlBase);
  } catch (_) {
    return urlBase; // URL non valido/relativo: non tocchiamo nulla
  }

  u.searchParams.delete('idLanguage');
  u.searchParams.delete('language');
  u.searchParams.delete('minCondition');

  const idLingua = LINGUA_MAP_SHARED[(lingua || '').toUpperCase().trim()];
  if (idLingua) u.searchParams.set('language', idLingua);

  condizioneRaw = (condizioneRaw || '').toUpperCase().trim();
  const haPiu      = condizioneRaw.endsWith('+');
  const haMeno     = condizioneRaw.endsWith('-');
  const condizione = (haPiu || haMeno) ? condizioneRaw.slice(0, -1).trim() : condizioneRaw;
  const rank       = COND_NUM_MAP_SHARED[condizione] || 0;

  if (rank > 0) {
    // FIX: haPiu (es. "EX+") deve restringere la soglia a una condizione
    // MIGLIORE di quella base (rank-1, verso MT) — prima il codice usava
    // "rankFinale = rank" anche per haPiu, cioè IDENTICO alla condizione
    // base senza suffisso: "EX+" si comportava esattamente come "EX" sul
    // filtro reale, contraddicendo la sintassi documentata qui sopra
    // (NM+ → minCondition=1, solo MT) e la legenda mostrata all'utente.
    // haMeno (es. "NM-") allarga la soglia verso una condizione peggiore
    // (rank+1, verso PO) — quel ramo era già corretto.
    const rankFinale = haMeno ? Math.min(rank + 1, 7) : (haPiu ? Math.max(rank - 1, 1) : rank);
    u.searchParams.set('minCondition', String(rankFinale));
  }

  // isReverseHolo / isFirstEd (o qualsiasi altro parametro già presente
  // nell'URL) non vengono mai toccati qui: restano intatti automaticamente
  // perché operiamo su u.searchParams invece che su replace() di stringa.
  return u.toString();
}

// Alias esplicito per popup.js, che mantiene il nome locale costruisciUrlFiltrato
// per compatibilità con le chiamate interne.
const costruisciUrlFiltrato_shared = costruisciUrlFiltrato;

// ── RILEVAMENTO RATE LIMIT (Error 1015) ──────────────────────────────────────
// Cloudflare/Cardmarket mostrano questa pagina quando le richieste sono troppo
// frequenti: "Error 1015 — You are being rate limited". A differenza del
// challenge anti-bot classico ("Just a moment…"), qui non c'è nulla da
// risolvere manualmente: serve solo aspettare. Usata sia su testo HTML grezzo
// (fetch) sia su DOM renderizzato (tab).
const RATE_LIMIT_MARKERS = ['error 1015', 'you are being rate limited'];

function isPaginaRateLimit(testo) {
  if (!testo) return false;
  const t = testo.toLowerCase();
  return RATE_LIMIT_MARKERS.some(m => t.includes(m));
}

// Durata standard della pausa anti-rate-limit, in millisecondi (30 minuti).
const PAUSA_RATE_LIMIT_MS = 30 * 60 * 1000;

// ── DIAGNOSTICA RISPOSTE WEB APP (Google Apps Script) ────────────────────────
// Quando la fetch verso la Web App riceve una risposta che non è JSON valido
// (tipicamente una pagina HTML), prima l'errore mostrato all'utente era il
// messaggio grezzo del parser — es. "Unexpected token '<', '<!DOCTYPE '...
// is not valid JSON" — poco utile per capire cosa sistemare. Questa funzione
// ispeziona il testo/status della risposta e riconosce le cause più comuni,
// restituendo un messaggio comprensibile e azionabile.
function diagnosticaRispostaWebApp(testo, status, statusText, url) {
  const t = (testo || '').toLowerCase();

  // Redirect verso il login Google → la distribuzione non è impostata su
  // "Chiunque" (richiede che l'utente sia autenticato/autorizzato).
  if (t.includes('accounts.google.com') || t.includes('serviceloginauth') || t.includes('accedi con il tuo account google')) {
    return 'La Web App richiede l\'accesso con un account Google: nella distribuzione di Apps Script imposta "Chi ha accesso" su "Chiunque" (non "Solo utenti dell\'organizzazione" o "Solo io"), poi crea una NUOVA distribuzione (o "Gestisci distribuzioni" → modifica la versione).';
  }

  // Pagina di errore interna di Apps Script (eccezione non gestita nello script).
  if (t.includes('exception') || t.includes('script error') || t.includes('errore di script') || t.includes('googleusercontent') && t.includes('error')) {
    return 'Lo script Apps Script ha generato un errore interno durante l\'esecuzione. Apri il tuo Google Sheet → Estensioni → Apps Script → "Esecuzioni" (icona a sinistra) per vedere il dettaglio dell\'errore, oppure controlla che sheetName e i parametri inviati siano corretti.';
  }

  // URL della Web App non corretto: deve terminare con /exec (distribuzione),
  // non essere l'URL dell'editor o una versione /dev (richiede login).
  if (url && !url.includes('/exec')) {
    return 'L\'URL della Web App non sembra corretto: deve terminare con "/exec" (URL della distribuzione pubblicata), non essere l\'URL dell\'editor di Apps Script né una versione "/dev".';
  }

  if (status === 404) {
    return 'La Web App non è stata trovata (HTTP 404). Controlla di aver incollato l\'URL dell\'ultima distribuzione attiva — se hai ridistribuito lo script, l\'URL potrebbe essere cambiato.';
  }
  if (status === 401 || status === 403) {
    return `Accesso negato dalla Web App (HTTP ${status}). Controlla i permessi della distribuzione ("Chi ha accesso" → "Chiunque") e, se richiesto, riautorizza lo script dall'editor Apps Script.`;
  }
  if (status >= 500) {
    return `Il server ha risposto con un errore (HTTP ${status}${statusText ? ' ' + statusText : ''}). Riprova tra poco; se persiste, ridistribuisci lo script Apps Script.`;
  }

  // Fallback: nessuna causa nota riconosciuta — mostra un estratto della
  // risposta grezza, così almeno si vede cosa è arrivato davvero.
  const estratto = (testo || '').replace(/\s+/g, ' ').trim().slice(0, 160);
  return `Risposta inattesa dalla Web App (non è JSON valido)${status ? `, HTTP ${status}` : ''}. Inizio risposta ricevuta: "${estratto || '(vuota)'}"`;
}

// Legge il testo di una Response già ottenuta da fetch() e prova a parsarlo
// come JSON, con diagnostica leggibile in caso di fallimento (vedi sopra).
async function parseRispostaWebAppRes(res, url) {
  const testo = await res.text();
  if (!res.ok) {
    throw new Error(diagnosticaRispostaWebApp(testo, res.status, res.statusText, url));
  }
  try {
    return JSON.parse(testo);
  } catch (_) {
    throw new Error(diagnosticaRispostaWebApp(testo, res.status, res.statusText, url));
  }
}

// Fetch POST verso la Web App + parsing JSON con diagnostica, in un'unica
// chiamata. Usata da background.js per AGGIUNGI_CARTA (bulk carte/sealed).
//
// FIX: prima un solo tentativo, nessun retry — un 404/errore di rete
// puntuale (cold start di Apps Script, redirect Google scaduto sotto
// richieste ravvicinate come capita in un bulk) marcava la carta come
// fallita per sempre, anche se un secondo tentativo sarebbe riuscito senza
// problemi. Aggiunto lo stesso pattern di retry-con-backoff già usato in
// popup.js (_fetchWebApp) per leggi/scrivi, esteso anche ai codici 404/5xx:
// un 404 vero (deployment inesistente) fallirebbe SEMPRE identico su ogni
// carta, quindi ritentare un 404 isolato è sicuro (lo script non ha nemmeno
// iniziato a eseguire — nessun rischio di riga duplicata). Nota: un errore
// di rete "Failed to fetch" ha in teoria un rischio residuo di duplicato se
// la risposta si perde DOPO che la riga è già stata scritta — stesso
// compromesso già accettato altrove in questo file per scriviDati/scriviUrl.
async function fetchWebAppJson(url, options, tentativi = 3) {
  let res;
  for (let i = 0; i < tentativi; i++) {
    try {
      res = await fetch(url, options);
    } catch (e) {
      if (i < tentativi - 1) { await new Promise(r => setTimeout(r, 1000 * (i + 1))); continue; }
      throw new Error('Impossibile contattare la Web App (rete non raggiungibile) dopo ' + tentativi + ' tentativi: ' + e.message);
    }
    if (!res.ok && (res.status === 404 || res.status >= 500) && i < tentativi - 1) {
      await new Promise(r => setTimeout(r, 1000 * (i + 1)));
      continue;
    }
    break;
  }
  return parseRispostaWebAppRes(res, url);
}

// ── FILTRO RIGHE OFFERTA (DOM Cardmarket) — UNICA FONTE DI VERITÀ ────────────
//
// Questa logica leggeva/scriveva IDENTICA (o quasi) in tre punti diversi:
// content.js e due copie inline dentro chrome.scripting.executeScript in
// background.js. Le copie inline erano necessarie perché il codice eseguito
// via executeScript gira in un contesto isolato che non può referenziare
// funzioni esterne dell'estensione — tutto ciò che serve va scritto
// letteralmente dentro la func iniettata.
//
// Fix: queste funzioni vivono ora QUI, in shared.js, che viene iniettato
// dichiarativamente su ogni pagina Cardmarket (vedi content_scripts in
// manifest.json — shared.js è elencato PRIMA di content.js). Chrome condivide
// lo stesso "mondo isolato" tra i content script dichiarativi e le injection
// imperative di chrome.scripting.executeScript per la STESSA estensione sulla
// STESSA tab — quindi quando background.js inietta codice via executeScript
// su una tab già navigata su Cardmarket, queste funzioni sono già disponibili
// come globali (window.rigaSoddisfaFiltriShared, ecc.), e il codice iniettato
// può richiamarle invece di riscriverle. content.js le usa direttamente,
// essendo caricato nello stesso mondo isolato.
//
// Ogni chiamante mantiene comunque un fallback fail-open (nessun filtro
// invece di bloccare tutto) nell'improbabile caso in cui questa funzione non
// sia ancora disponibile — vedi commenti nei chiamanti.

// LINGUA: Cardmarket usa aria-label="<lingua>" sul primo span[aria-label]
// dentro .product-attributes (icona bandiera). I valori sono nella lingua
// dell'interfaccia utente — con interfaccia italiana Cardmarket scrive
// "Italiano", "Inglese", ecc. Verificato dal DOM reale il 2025-06. Il secondo
// alias (en/fr/...) copre eventuali utenti con interfaccia in inglese.
//
// Corrispondenze codici foglio → idLanguage:
//   IT/ITA → 5 Italiano · EN → 1 Inglese · FR → 2 Francese · DE → 3 Tedesco
//   ES → 4 Spagnolo · PT → 8 Portoghese · JA/JAP → 7 Giapponese
//   KOR → 10 Coreano · CHN → 6 Cinese-S + 11 Cinese-T · RU → 9 Russo
//   IND → 16 Indonesiano · THAI → 17 Tailandese
const LANGUAGE_ARIA_MAP_SHARED = {
  '1':  ['inglese', 'english'],
  '2':  ['francese', 'french'],
  '3':  ['tedesco', 'german'],
  '4':  ['spagnolo', 'spanish'],
  '5':  ['italiano', 'italian'],
  '6':  ['cinese-s', 'chinese-s', 'simplified chinese', 'cinese s', 'cinese'],
  '7':  ['giapponese', 'japanese'],
  '8':  ['portoghese', 'portuguese'],
  '9':  ['russo', 'russian'],
  '10': ['coreano', 'korean'],
  '11': ['cinese-t', 'chinese-t', 'traditional chinese', 'cinese t'],
  '16': ['indonesiano', 'indonesian'],
  '17': ['tailandese', 'thai'],
};

// CONDIZIONE: Cardmarket usa la classe CSS "condition-nm", "condition-ex",
// ecc. sull'elemento <a class="article-condition condition-XX"> dentro
// .product-attributes. Rank: più basso = condizione migliore.
const CONDITION_RANK_SHARED = { mt: 1, nm: 2, ex: 3, gd: 4, lp: 5, pl: 6, po: 7 };

// L'URL contiene minCondition come numero (es. "2"), non come sigla testuale
// — questa mappa converte il valore numerico stringa nella chiave testuale
// usata da CONDITION_RANK_SHARED.
const COND_NUM_TO_KEY_SHARED = { '1': 'mt', '2': 'nm', '3': 'ex', '4': 'gd', '5': 'lp', '6': 'pl', '7': 'po' };

// REVERSE HOLO / PRIMA EDIZIONE: Cardmarket marca la riga con un'icona
// aggiuntiva (span[aria-label]) DOPO quella della lingua, dentro
// .product-attributes. Verificato dal DOM reale (2026-07): l'aria-label è
// sempre "Reverse Holo" / "First Edition" in inglese fisso, indipendentemente
// dalla lingua dell'interfaccia. Le altre varianti restano come fallback
// difensivo.
const REVERSE_HOLO_ARIA_MARKERS_SHARED = [
  'reverse holo', 'reverse-holo', 'reverseholo', 'holo reverse',
  'olografia inversa', 'inversa',
];
const FIRST_ED_ARIA_MARKERS_SHARED = [
  'first edition', 'firstedition', '1st edition', '1sted',
  'prima edizione', 'primaedizione', 'prima ed', '1a edizione',
];

function rigaHaIconaVarianteShared(riga, markers) {
  const attributi = riga.querySelector('.product-attributes');
  if (!attributi) return false;
  // Il primo span[aria-label] è la bandiera-lingua — le icone successive
  // (foil/speciali, tra cui Reverse Holo/First Edition) vengono dopo.
  const icone = Array.from(attributi.querySelectorAll('span[aria-label]')).slice(1);
  return icone.some(el => {
    const label = (el.getAttribute('aria-label') || '').toLowerCase();
    return markers.some(m => label.includes(m));
  });
}

// CARRELLO NON CLICCABILE (prezzo non attendibile): alcuni venditori
// mostrano un prezzo ma l'offerta non è davvero acquistabile da noi (il
// venditore non spedisce nella nostra zona, blacklist reciproca, ecc.) —
// Cardmarket in quel caso NON mostra il normale bottone "Aggiungi al
// carrello" ma un elemento diverso, non cliccabile. Verificato dal DOM
// reale (2026-07, utente loggato):
//   - Cliccabile:     <button class="btn btn-primary ..." data-id-amount="...">
//   - Non cliccabile: <a class="btn btn-grey" role="button"> (nessun data-id-amount)
//
// FIX (bug "tutte le carte risultano Esaurita"): una versione precedente
// era un'ALLOWLIST — richiedeva ESATTAMENTE <button data-id-amount>,
// bloccando ogni riga che non combaciava perfettamente (es. tab non ancora
// autenticata su Cardmarket al momento della lettura, o markup leggermente
// diverso da quello osservato). Risultato: ogni riga veniva scartata e ogni
// carta risultava "Esaurita". Ora si esclude SOLO il pattern esplicito "non
// cliccabile" osservato nel DOM reale — <a class="btn-grey" role="button">
// senza data-id-amount — e qualunque altro markup non blocca la riga:
// fail-safe invece di allowlist rigida.
function rigaCarrelloCliccabileShared(riga) {
  const cartIcon = riga.querySelector('.fonticon-cart');
  const cartEl = cartIcon ? cartIcon.closest('a, button') : null;
  if (!cartEl) return true; // elemento non trovato: non blocchiamo
  if (cartEl.tagName === 'A' && cartEl.classList.contains('btn-grey') && !cartEl.hasAttribute('data-id-amount')) {
    return false;
  }
  return true;
}

// Filtro completo su una singola riga d'offerta (.article-row). opts:
//   idLanguage    — idLanguage atteso (stringa numerica, es. "5"), o null
//   minCondition  — minCondition atteso (stringa, numerica o già chiave tipo
//                   "nm"), o null
//   isReverseHolo / isFirstEd — Y/true se la variante è quella richiesta
//   ignoraVarianti — true per disattivare SOLO l'esclusione badge RH/1ED
//                    (fallback quando la carta esiste solo in quella
//                    variante — es. molte espansioni cinesi — vedi
//                    chiamanti). Lingua/condizione/carrello restano filtrati.
function rigaSoddisfaFiltriShared(riga, opts) {
  opts = opts || {};
  const { idLanguage, minCondition, isReverseHolo, isFirstEd, ignoraVarianti } = opts;

  // Il controllo carrello è SEMPRE applicato, indipendentemente dagli altri
  // filtri: un'offerta non acquistabile non deve mai essere scelta come
  // fonte del prezzo, a differenza dei filtri RH/1ED che ignoraVarianti
  // rilassa volutamente in alcuni casi.
  if (!rigaCarrelloCliccabileShared(riga)) return false;

  const attributi = riga.querySelector('.product-attributes');
  if (!attributi) return true; // struttura inattesa → non bloccare

  // ── Filtro lingua ──
  if (idLanguage) {
    const accettate = LANGUAGE_ARIA_MAP_SHARED[idLanguage] || [];
    const iconaBandiera = attributi.querySelector('span[aria-label]');
    const label = (iconaBandiera?.getAttribute('aria-label') || '').toLowerCase();
    if (!accettate.some(a => label.includes(a))) return false;
  }

  // ── Filtro condizione ──
  if (minCondition) {
    const condKey = COND_NUM_TO_KEY_SHARED[minCondition] || minCondition; // fallback: già testuale
    const rankMinimo = CONDITION_RANK_SHARED[condKey];
    if (rankMinimo) {
      const elCond = attributi.querySelector('a.article-condition');
      if (elCond) {
        const match = elCond.className.match(/condition-([a-z]+)/);
        if (match) {
          const rankRiga = CONDITION_RANK_SHARED[match[1]] ?? null;
          if (rankRiga !== null && rankRiga > rankMinimo) return false;
        }
      }
    }
  }

  // ── Filtro Reverse Holo / Prima Edizione ──
  // FIX (bug "Esaurita" su ogni carta RH/1ED): isReverseHolo=Y e isFirstEd=Y
  // sono filtri NATIVI di Cardmarket — quando presenti nell'URL, Cardmarket
  // ha GIÀ ristretto le righe alla variante richiesta, e in quel contesto il
  // badge per-riga può essere assente (ridondante). Ci fidiamo del filtro
  // nativo per l'INCLUSIONE; il badge serve solo per l'ESCLUSIONE quando la
  // variante NON è richiesta (offerte miste in pagina). ignoraVarianti
  // disattiva anche l'esclusione badge: usato come fallback quando la carta
  // esiste SOLO in RH/1ED (es. molte espansioni cinesi).
  if (!ignoraVarianti) {
    if (!isReverseHolo && rigaHaIconaVarianteShared(riga, REVERSE_HOLO_ARIA_MARKERS_SHARED)) return false;
    if (!isFirstEd && rigaHaIconaVarianteShared(riga, FIRST_ED_ARIA_MARKERS_SHARED)) return false;
  }

  return true;
}

// Espone le funzioni sul global object esplicitamente: nel mondo isolato dei
// content script, dichiarazioni `function`/`const` di primo livello sono già
// visibili come proprietà implicite dell'ambiente globale condiviso, ma
// l'assegnazione esplicita rende il contratto (cosa background.js si aspetta
// di trovare via window.___) leggibile e a prova di refactor futuro.
if (typeof window !== 'undefined') {
  window.rigaSoddisfaFiltriShared = rigaSoddisfaFiltriShared;
  window.rigaCarrelloCliccabileShared = rigaCarrelloCliccabileShared;
}

// ── AUDIO KEEP-ALIVE (fix "sessione si blocca se la tab va in background") ───
// FIX: una sessione lunga (▶ Avvia / 📋📦🗂️ bulk) lasciata per ore in una tab
// NON in primo piano (finestra minimizzata, coperta da altre, cambio di
// desktop virtuale...) rallenta drasticamente o si blocca del tutto fino a
// quando la tab non torna in focus (es. muovendo il mouse). Causa: il
// "background tab timer throttling" di Chrome — setTimeout/setInterval in
// una tab non visibile/non attiva vengono rallentati fino a girare anche
// solo una volta al minuto dopo pochi minuti in background, e tutta la
// logica di attesa (_attendiConCountdown, i vari delay tra una carta e
// l'altra) si basa proprio su questi timer. chrome.power (usato per evitare
// la sospensione del PC) non c'entra: agisce sul sistema operativo, non sul
// throttling per-tab di Chrome.
//
// Chrome esclude dal throttling intensivo le tab che stanno riproducendo
// audio ("audible tab") — trucco noto e usato da diverse web app per tenere
// vivi i propri timer in background. Basta un audio in loop a volume quasi
// impercettibile (non zero: volume 0 non viene considerato "audio in
// riproduzione" da Chrome) per tutta la durata della sessione. Nessun file
// esterno necessario: un WAV silenzioso di 1 campione codificato come data
// URI, generato una volta sola e riusato.
//
// Avviato SEMPRE come primissima istruzione sincrona del click handler che
// avvia una sessione (prima di qualunque await) — l'autorizzazione del
// browser a riprodurre audio richiede un gesto utente "fresco"; chiamarlo
// dopo una await (es. dopo una verifica di rete) rischia di perdere quel
// gesto e far fallire play() silenziosamente.
const _AUDIO_KEEPALIVE_SRC =
  'data:audio/wav;base64,UklGRiQAAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQAAAAA=';
let _audioKeepAlive = null;

// FIX (freeze totale di Chrome/sistema su "Avvia"): l'audio keep-alive
// introdotto in v3.0 per evitare il "background tab timer throttling" di
// Chrome (vedi commento sopra) causa su questo specifico PC un blocco
// totale del sistema operativo quando Chrome avvia la riproduzione audio —
// molto probabilmente un problema del driver audio del PC (non del codice
// dell'estensione in sé: creare/avviare un elemento <audio> richiede che
// Chrome passi la mano al sottosistema audio di Windows, e se quel
// passaggio si blocca lì, blocca tutto il sistema, non solo la tab).
// Confermato con un test isolato: disattivando SOLO questa funzione il
// freeze sparisce completamente, con tutto il resto del codice invariato.
//
// Disattivata quindi in modo permanente. Contropartita accettata: una
// sessione molto lunga (▶ Avvia su centinaia di carte) potrebbe rallentare
// o mettersi in pausa da sola se la tab resta a lungo fuori dal primo piano
// (finestra minimizzata per ore, ecc.) — molto meglio di un freeze totale
// del sistema. Se in futuro serve recuperare la protezione dal throttling
// con un meccanismo diverso dall'audio (es. chrome.alarms lato service
// worker invece di setTimeout lato tab), è un lavoro a parte.
function avviaAudioKeepAlive() {
  return; // disattivata — vedi commento sopra
}

function fermaAudioKeepAlive() {
  if (!_audioKeepAlive) return;
  try { _audioKeepAlive.pause(); } catch (_) {}
  _audioKeepAlive = null;
}

// ── NOME DISPOSITIVO ──────────────────────────────────────────────────────────
// Ogni PC/estensione ha un nome persistente, generato una sola volta e
// salvato in chrome.storage.local — serve per capire, quando più dispositivi
// sono online insieme (es. "un portatile sempre acceso" + il tuo PC
// principale), CHI ha preso in carico ogni riga della coda unificata
// (coda_carte.dispositivo). Non serve configurarlo: la prima volta che
// questa funzione viene chiamata su un'estensione ne genera uno e lo
// riusa sempre per quel browser/profilo da quel momento in poi.
function nomeDispositivo() {
  return new Promise((resolve) => {
    if (window._nomeDispositivoCache) { resolve(window._nomeDispositivoCache); return; }
    chrome.storage.local.get('nomeDispositivo', (saved) => {
      let nome = saved.nomeDispositivo;
      if (!nome) {
        nome = 'PC-' + Math.random().toString(36).slice(2, 7).toUpperCase();
        chrome.storage.local.set({ nomeDispositivo: nome });
      }
      window._nomeDispositivoCache = nome;
      resolve(nome);
    });
  });
}