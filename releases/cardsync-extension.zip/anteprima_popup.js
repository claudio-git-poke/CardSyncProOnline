// ── anteprima_popup.js ───────────────────────────────────────────────────────
// Pagina standalone (aperta in una tab con chrome.tabs.create, come
// changelog.html) che mostra un'anteprima del foglio Google configurato —
// sia LETTURA che SCRITTURA passano dalla stessa Web App già configurata nel
// popup principale (richiede webapp_scrivi_prezzi.gs con l'azione
// "leggiAnteprima", vedi ISTRUZIONI.md Parte 2).
//
// FIX (righe nascoste sparivano/disallineavano l'anteprima): la lettura
// passava in precedenza dall'export CSV pubblico di Google (endpoint
// "gviz/tq", stesso motore che genera i grafici da un foglio pubblicato —
// evitava una chiamata ad Apps Script, bastava che il foglio fosse
// condiviso come "Chiunque abbia il link può visualizzare"). Quell'endpoint
// ha però un limite non aggirabile via URL: ESCLUDE del tutto dal risultato
// le righe nascoste manualmente (tasto destro → Nascondi riga) — non le
// restituisce nemmeno come riga vuota. L'effetto pratico: ogni riga dopo
// quella nascosta scalava silenziosamente di una posizione nel conteggio
// interno del numero di riga, facendo sparire/disallineare esattamente le
// righe vicino all'inizio del foglio quando una riga nascosta precedeva la
// soglia di inizio dati. La Web App legge invece con
// SpreadsheetApp/getDisplayValues() lato Apps Script (azione
// "leggiAnteprima"), che include SEMPRE tutte le righe della griglia reale,
// comprese quelle nascoste — quindi ora richiede l'URL Web App configurato
// anche solo per VISUALIZZARE l'anteprima, non più solo per modificare la
// Location.
//
// La SCRITTURA (modifica inline della colonna Location) usa lo stesso
// meccanismo generico di scrittura singola cella già usato da
// scriviUrl/scriviDati in popup.js:
// { sheetName, colPrezzo: <lettera colonna>, prezzi: [{ riga, prezzo: <valore> }] }
// — "colPrezzo"/"prezzo" sono nomi storici del payload, ma scrivono
// qualunque colonna/valore, non solo il prezzo.

// ── LOGIN SUPABASE ────────────────────────────────────────────────────────────
assicuraLoginSupabase();

const LISTA_TEMI = ['purple', 'green', 'blue', 'contrast', 'dark', 'sakura', 'wine', 'autunno', 'estate', 'heartgold', 'soulsilver', 'steel', 'electric', 'grass', 'pokemon', 'team-rocket'];

function applicaTema(nome) {
  LISTA_TEMI.forEach(t => document.body.classList.remove(`theme-${t}`));
  if (nome !== 'purple') document.body.classList.add(`theme-${nome}`);
  document.body.classList.toggle('tema-attivo', nome !== 'purple');
}

chrome.storage.local.get(['selectedTheme', 'cardsyncDarkMode'], (saved) => {
  applicaTema(saved.selectedTheme || 'purple');
  document.body.classList.toggle('modo-scuro', saved.cardsyncDarkMode === true);
});
chrome.storage.onChanged.addListener((changes) => {
  if (changes.selectedTheme) location.reload(); // FIX: refresh vero invece di un cambio 'a caldo' incompleto
  if (changes.cardsyncDarkMode) location.reload();
});

// FIX (pulizia codice morto): rimosso parseCSV() — la lettura dell'anteprima
// non passa più dall'export CSV pubblico gviz/tq (limitato: esclude le righe
// nascoste dal risultato, senza modo di aggirarlo lato URL) ma dalla Web App
// già configurata, che restituisce JSON pronto all'uso (azione
// "leggiAnteprima", vedi caricaAnteprima() più sotto).

// ── LETTERA COLONNA (0 → A, 1 → B, … 25 → Z, 26 → AA, …) ────────────────────
function lettera(idx) {
  let n = idx + 1;
  let s = '';
  while (n > 0) {
    const resto = (n - 1) % 26;
    s = String.fromCharCode(65 + resto) + s;
    n = Math.floor((n - 1) / 26);
  }
  return s;
}

// Inverso di lettera() — serve per convertire la lettera colonna configurata
// (es. "D" per Location) nell'indice 0-based della riga CSV corrispondente.
function letteraToIndice(let_) {
  let n = 0;
  const s = (let_ || '').trim().toUpperCase();
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    if (c < 65 || c > 90) return -1; // lettera non valida
    n = n * 26 + (c - 64);
  }
  return n - 1;
}

// ── STATO ─────────────────────────────────────────────────────────────────────
// _righeComplete: array di { rigaSheet, celle } — rigaSheet è il numero di
// riga REALE nel foglio (1-based, come lo vede Google Sheets), necessario
// per scrivere la modifica sulla cella giusta. Le righe completamente vuote
// vengono scartate PRIMA di assegnare rigaSheet, quindi il numero resta
// sempre quello vero anche se in tabella non sono consecutive.
let _righeComplete = [];
let _colMap = {};
let _colLocationIdx = -1;
let _colLocationLettera = '';
let _colPrezzoIdx = -1;
let _webAppUrl = '';
let _sheetNameCorrente = '';
const LIMITE_RIGHE = 2000;

function renderTabella(righe) {
  const wrap = document.getElementById('tabellaWrap');
  wrap.innerHTML = '';

  if (righe.length === 0) {
    wrap.innerHTML = '<p class="anteprima-vuoto">Nessuna riga da mostrare.</p>';
    return;
  }

  const maxCol = righe.reduce((m, r) => Math.max(m, r.celle.length), 1);
  const daMostrare = righe.slice(0, LIMITE_RIGHE);

  const table = document.createElement('table');
  table.className = 'anteprima-table';

  const thead = document.createElement('thead');
  const trIntestazione = document.createElement('tr');
  for (let c = 0; c < maxCol; c++) {
    const th = document.createElement('th');
    const let_ = lettera(c);
    const etichetta = _colMap[let_];
    th.innerHTML = `<span class="col-lettera">${let_}</span>` + (etichetta ? `<span class="col-etichetta">${etichetta}</span>` : '');
    trIntestazione.appendChild(th);
  }
  thead.appendChild(trIntestazione);
  table.appendChild(thead);

  const tbody = document.createElement('tbody');
  daMostrare.forEach((rigaObj) => {
    const tr = document.createElement('tr');
    const celle = rigaObj.celle;
    for (let c = 0; c < maxCol; c++) {
      const valore = (celle[c] || '').trim();
      const td = document.createElement('td');

      if (c === _colLocationIdx && _colLocationIdx >= 0) {
        // ── CELLA LOCATION EDITABILE ──────────────────────────────────────
        // Click → diventa un campo di testo, Invio/perdita focus salva
        // davvero su Supabase, Esc annulla.
        td.className = 'cell-editable';
        td.textContent = valore || '—';
        td.title = 'Clicca per modificare';
        // FIX (la seconda modifica non veniva salvata): passare qui la
        // variabile "valore" catturava il valore SOLO al momento del
        // render iniziale della tabella — dopo un salvataggio riuscito
        // rigaObj.celle viene aggiornato correttamente, ma questa cella non
        // viene ridisegnata (stesso nodo DOM, stesso listener), quindi ogni
        // click successivo continuava a passare per sempre il valore
        // ORIGINARIO del primo caricamento, mai quello aggiornato. Effetto:
        // al secondo click il campo si apriva con il valore vecchio, e il
        // controllo "nessuna modifica" (nuovoValore === valoreAttuale) lo
        // confrontava contro quel valore stantio — se il nuovo valore
        // desiderato coincideva per caso con quello originario (es.
        // alternando tra due location), il salvataggio veniva saltato
        // silenziosamente perché sembrava "nessun cambiamento". Leggendo il
        // valore direttamente da rigaObj.celle al momento del click (sempre
        // aggiornato da salva(), vedi sotto) invece della variabile
        // congelata, ogni modifica successiva alla prima funziona.
        td.addEventListener('click', () => _avviaModificaLocation(td, rigaObj, (rigaObj.celle[_colLocationIdx] || '').trim()));
      } else if (/^https?:\/\//i.test(valore)) {
        // Qualunque cella con un URL (tipicamente la colonna URL Cardmarket,
        // ma vale per qualsiasi colonna) diventa un link cliccabile che apre
        // la pagina in una nuova tab — etichetta breve al posto dell'URL
        // intero (spesso lunghissimo), l'URL completo resta nel title.
        const a = document.createElement('a');
        a.href = valore;
        a.target = '_blank';
        a.rel = 'noopener';
        a.className = 'cell-link';
        a.textContent = '🔗 Apri';
        a.title = valore;
        td.appendChild(a);
      } else if (c === _colPrezzoIdx && _colPrezzoIdx >= 0 && valore && !valore.includes('€') && /^-?\d+([.,]\d+)?$/.test(valore)) {
        // ── CELLA PREZZO CON SIMBOLO € ──────────────────────────────────────
        // Aggiunge "€" solo se la cella contiene un numero puro (es. "12,50"
        // o "12.50") e non lo ha già (una cella già formattata a valuta nel
        // foglio arriva qui con il simbolo incluso in getDisplayValues() —
        // in quel caso non tocchiamo nulla, per non duplicarlo). Non
        // riformatta il numero (niente arrotondamenti/separatori diversi):
        // aggiunge solo il simbolo, lasciando intatta la formattazione già
        // presente nel foglio.
        td.textContent = valore + ' €';
        td.title = valore;
      } else {
        td.textContent = valore;
        if (valore) td.title = valore;
      }
      tr.appendChild(td);
    }
    tbody.appendChild(tr);
  });
  table.appendChild(tbody);
  wrap.appendChild(table);

  if (righe.length > LIMITE_RIGHE) {
    const nota = document.createElement('p');
    nota.className = 'anteprima-nota';
    nota.textContent = `Mostrate le prime ${LIMITE_RIGHE} righe su ${righe.length} — usa la ricerca per restringere, oppure apri il foglio completo.`;
    wrap.appendChild(nota);
  }
}

// ── MODIFICA INLINE DELLA LOCATION ───────────────────────────────────────────
function _avviaModificaLocation(td, rigaObj, valoreAttuale) {
  if (td.querySelector('input')) return; // già in modifica, non riaprire

  const input = document.createElement('input');
  input.type = 'text';
  input.value = valoreAttuale;
  input.className = 'cell-edit-input';
  td.textContent = '';
  td.appendChild(input);
  input.focus();
  input.select();

  let concluso = false;

  function ripristinaTesto(testo) {
    td.textContent = testo || '—';
    td.title = 'Clicca per modificare';
  }

  async function salva() {
    if (concluso) return;
    concluso = true;
    const nuovoValore = input.value.trim();

    if (nuovoValore === valoreAttuale) { ripristinaTesto(valoreAttuale); return; }

    input.disabled = true;
    const stato = document.getElementById('statoAnteprima');
    try {
      await _scriviLocation(rigaObj._id, nuovoValore);
      rigaObj.celle[_colLocationIdx] = nuovoValore;
      ripristinaTesto(nuovoValore);
      _popolaFiltroLocation(_righeComplete);
      if (stato) stato.textContent = `✅ Location riga ${rigaObj.rigaSheet} aggiornata a "${nuovoValore || '(vuota)'}".`;
    } catch (e) {
      ripristinaTesto(valoreAttuale);
      if (stato) stato.textContent = '❌ Salvataggio non riuscito: ' + e.message;
    }
  }

  input.addEventListener('blur', salva);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') { input.blur(); }
    else if (e.key === 'Escape') { concluso = true; ripristinaTesto(valoreAttuale); }
  });
}

// Scrive un nuovo valore nella colonna Location per una carta specifica.
// "rigaId" qui è l'ID reale della carta su Supabase (rigaObj._id), NON il
// numero di riga "finto" (rigaObj.rigaSheet) usato solo per la numerazione
// visuale della tabella — vedi _supabaseToCelleAnteprima nell'adapter.
async function _scriviLocation(rigaId, nuovoValore) {
  const data = await chiamaSupabase('aggiornaLocationRiga', { riga: rigaId, location: nuovoValore });
  if (!data.ok) throw new Error(data.errore || 'Scrittura non riuscita.');
}

async function caricaAnteprima() {
  const stato = document.getElementById('statoAnteprima');
  const btn   = document.getElementById('btnAggiorna');
  const wrap  = document.getElementById('tabellaWrap');
  const hint  = document.getElementById('hintModifica');

  btn.disabled = true;
  stato.textContent = '⏳ Carico i dati dal foglio…';
  if (hint) hint.textContent = '';
  wrap.innerHTML = '';

  const saved = await new Promise((r) => chrome.storage.local.get(
    ['sheetId', 'colLocation', 'colLingua', 'colCondizione', 'colUrl', 'colPrezzo', 'colVariazione'], r));

  const sheetId = (saved.sheetId || '').trim();

  // Con Supabase non serve più configurare Web App/foglio per leggere
  // l'anteprima — serve solo essere loggati.
  const { data: _sessCheck } = await supabaseClient.auth.getSession();
  if (!_sessCheck.session) {
    stato.textContent = '⚠️ Non sei loggato su Supabase — ricarica la pagina per rifare il login.';
    btn.disabled = false;
    return;
  }

  // Etichette sotto la lettera colonna, lette dalla stessa mappatura
  // colonne configurata nel popup principale ("📋 Colonne foglio") — B/C
  // (nome/codice) sono fisse in tutta l'estensione, non configurabili.
  _colMap = { B: 'Nome', C: 'Codice' };
  const mappaCampi = {
    colLocation:   'Location',
    colLingua:     'Lingua',
    colCondizione: 'Condizione',
    colUrl:        'URL',
    colPrezzo:     'Prezzo',
    colVariazione: 'Variazione',
  };
  Object.keys(mappaCampi).forEach((campo) => {
    const let_ = (saved[campo] || '').trim().toUpperCase();
    if (let_) _colMap[let_] = mappaCampi[campo];
  });

  _colLocationLettera = (saved.colLocation || 'D').trim().toUpperCase();
  _colLocationIdx = letteraToIndice(_colLocationLettera);
  _colPrezzoIdx = letteraToIndice((saved.colPrezzo || 'I').trim().toUpperCase());

  const linkSheet = document.getElementById('linkApriSheet');
  if (linkSheet) linkSheet.href = `https://docs.google.com/spreadsheets/d/${encodeURIComponent(sheetId)}/edit`;

  // Riga di partenza FISSA e indipendente da "rigaInizio" in
  // chrome.storage.local — quel valore è il puntatore di RIPRESA che il
  // Riga di partenza mostrata nel messaggio di stato — con Supabase la
  // lettura non è più paginata per riga (leggiAnteprima restituisce sempre
  // tutta la collezione), questo valore resta solo per il testo a video.
  const RIGA_INIZIO_ANTEPRIMA = 4;

  try {
    const data = await chiamaSupabase('leggiAnteprima', {});
    if (!data.ok) throw new Error(data.errore || 'Errore nella lettura da Supabase.');

    // rigaSheet qui è un numero progressivo "finto" (solo per la
    // numerazione visuale della tabella) — per scrivere va sempre usato
    // r._id, l'ID reale della carta su Supabase (vedi _scriviLocation).
    const righeConIndice = (data.righe || [])
      .filter((r) => r.celle.some((c) => (c || '').trim() !== ''));

    _righeComplete = righeConIndice;
    _popolaFiltroLocation(righeConIndice);
    applicaFiltri();
    stato.textContent = `📄 ${righeConIndice.length} carte caricate dalla tua collezione Supabase.`;
    if (hint) {
      hint.textContent = (_colLocationIdx >= 0)
        ? '✏️ Clicca su una Location per modificarla direttamente nel foglio.'
        : '';
    }
  } catch (e) {
    stato.textContent = '❌ ' + e.message;
  }

  btn.disabled = false;
}

// ── FILTRO LOCATION ───────────────────────────────────────────────────────────
// Stesso concetto del filtro "🗂️ Filtro Location" nel popup principale, ma
// qui è solo un filtro di VISUALIZZAZIONE sui dati già caricati — nessuna
// chiamata di rete aggiuntiva, i valori vengono estratti direttamente dalla
// colonna Location (colLocation, default D) dei dati già scaricati.
function _popolaFiltroLocation(righe) {
  const select = document.getElementById('filtroLocationAnteprima');
  if (!select) return;
  const valoreAttuale = select.value;

  if (_colLocationIdx < 0) {
    select.innerHTML = '<option value="">🗂️ Tutte le location</option>';
    select.disabled = true;
    return;
  }
  select.disabled = false;

  const valori = new Set();
  righe.forEach((r) => {
    const v = (r.celle[_colLocationIdx] || '').trim();
    if (v) valori.add(v);
  });
  const elencoOrdinato = Array.from(valori).sort((a, b) => a.localeCompare(b, 'it'));

  select.innerHTML = '<option value="">🗂️ Tutte le location</option>';
  elencoOrdinato.forEach((v) => {
    const opt = document.createElement('option');
    opt.value = v;
    opt.textContent = v;
    select.appendChild(opt);
  });
  if (valoreAttuale && elencoOrdinato.includes(valoreAttuale)) select.value = valoreAttuale;
}

// Applica insieme il filtro Location (select) e la ricerca testuale (input) —
// chiamata da entrambi i listener così i due filtri si combinano sempre,
// invece di escludersi a vicenda.
function applicaFiltri() {
  const q = (document.getElementById('inputCerca').value || '').trim().toLowerCase();
  const locSelezionata = document.getElementById('filtroLocationAnteprima').value;

  let righe = _righeComplete;
  if (locSelezionata && _colLocationIdx >= 0) {
    righe = righe.filter((r) => (r.celle[_colLocationIdx] || '').trim() === locSelezionata);
  }
  if (q) {
    righe = righe.filter((r) => r.celle.some((c) => (c || '').toLowerCase().includes(q)));
  }
  renderTabella(righe);
}

document.getElementById('btnAggiorna').addEventListener('click', caricaAnteprima);

document.getElementById('inputCerca').addEventListener('input', applicaFiltri);
document.getElementById('filtroLocationAnteprima').addEventListener('change', applicaFiltri);

caricaAnteprima();