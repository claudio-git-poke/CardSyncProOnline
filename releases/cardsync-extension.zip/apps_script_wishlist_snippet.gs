// ═══════════════════════════════════════════════════════════════════════════
// SNIPPET WISHLIST — da incollare dentro webapp_scrivi_prezzi.gs
// ═══════════════════════════════════════════════════════════════════════════
//
// DOVE incollarlo: dentro la funzione doPost(e), tra il blocco
//   if (payload.azione === "aggiungi") { ... }
// e il blocco
//   // --- FALLBACK: SCRITTURA PREZZI RIGA PER RIGA ...
//
// Cioè subito PRIMA di:
//   if (!payload.prezzi) { ... }
//
// Non serve toccare nient'altro: nessuna delle funzioni esistenti
// (colLetteraANumero, risposta, normalizzaLingua, normalizzaCondizione)
// viene modificata, sono già riusate qui sotto.

    // --- AZIONE: LEGGI WISHLIST (righe complete: nome, codice, qty, lingua,
    // condizione, url, prezzo, prezzo obiettivo, note) — usata dal pannello
    // "📋 Wishlist attuale" della pagina Wishlist per mostrare l'elenco e
    // permettere "✓ Comprata" / "🗑️ Rimuovi". A differenza dell'azione
    // "leggi" (pensata per il controllo prezzi dell'Inventario, con Location
    // e filtro), questa restituisce TUTTE le colonne rilevanti per la
    // wishlist in un colpo solo. ---
    if (payload.azione === "leggiWishlist") {
      var rigaInizioWL = payload.rigaInizio || 4;
      var lastRowWL = sheet.getLastRow();
      if (lastRowWL < rigaInizioWL) {
        return risposta({ ok: true, righe: [] });
      }
      // B..K = colonne 2..11
      var valsWL = sheet.getRange(rigaInizioWL, 2, lastRowWL - rigaInizioWL + 1, 10).getValues();
      var righeWL = [];
      for (var iw = 0; iw < valsWL.length; iw++) {
        var rigaRealeWL = rigaInizioWL + iw;
        var nomeWL   = String(valsWL[iw][0] || '').trim();   // B
        var codiceWL = String(valsWL[iw][1] || '').trim();   // C
        var qtyWL    = valsWL[iw][3];                        // E
        var linguaWL = String(valsWL[iw][4] || '').trim();   // F
        var condWL   = String(valsWL[iw][5] || '').trim();   // G
        var urlWL    = String(valsWL[iw][6] || '').trim();   // H
        var prezzoWLRaw = valsWL[iw][7];                     // I
        var obiettivoWLRaw = valsWL[iw][8];                  // J
        var noteWL   = String(valsWL[iw][9] || '').trim();   // K

        // Riga considerata vuota/da ignorare se non ha nome né url.
        if (!nomeWL && !urlWL) continue;

        righeWL.push({
          riga:            rigaRealeWL,
          nome:            nomeWL,
          codice:          codiceWL,
          qty:             Number(qtyWL) || 1,
          lingua:          linguaWL,
          condizione:      condWL,
          url:             urlWL,
          prezzo:          (typeof prezzoWLRaw === 'number') ? prezzoWLRaw : (parseFloat(prezzoWLRaw) || null),
          prezzoObiettivo: (typeof obiettivoWLRaw === 'number') ? obiettivoWLRaw : (parseFloat(obiettivoWLRaw) || null),
          note:            noteWL,
        });
      }
      return risposta({ ok: true, righe: righeWL });
    }

    // --- AZIONE: SVUOTA RIGA (usata da "✓ Comprata" e "🗑️ Rimuovi" nella
    // Wishlist, per liberare la riga dopo averla eventualmente copiata in
    // Inventario). Generica: pulisce un intervallo di colonne su una riga,
    // qualunque sia il foglio — non elimina la riga fisica (niente shift
    // delle righe sottostanti), solo il contenuto delle celle. ---
    if (payload.azione === "svuotaRiga") {
      var rigaDaSvuotare = payload.riga;
      var colDaSvuotare  = colLetteraANumero(payload.colDa || 'B');
      var colASvuotare   = colLetteraANumero(payload.colA  || 'K');
      var numColSvuotare = colASvuotare - colDaSvuotare + 1;
      if (rigaDaSvuotare && numColSvuotare > 0) {
        sheet.getRange(rigaDaSvuotare, colDaSvuotare, 1, numColSvuotare).clearContent();
      }
      return risposta({ ok: true, riga: rigaDaSvuotare });
    }
