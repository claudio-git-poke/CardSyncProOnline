# Patch da applicare ai file esistenti

Questi 4 file NON sono stati riscritti per intero (sono grossi e già
rifiniti) — qui sotto trovi il "prima → dopo" di ogni singola modifica,
da applicare a mano nel tuo progetto.

═══════════════════════════════════════════════════════════════════════════
## 1. popup.html — CSS: griglia da 4 a 5 colonne (per il nuovo bottone)
═══════════════════════════════════════════════════════════════════════════

CERCA (nel blocco `.novita-grid`):

```css
    .novita-grid {
      display: grid;
      grid-template-columns: repeat(4, 1fr);
      gap: 5px;
    }
```

SOSTITUISCI CON:

```css
    .novita-grid {
      display: grid;
      grid-template-columns: repeat(5, 1fr);
      gap: 5px;
    }
```

---

CERCA (nel blocco `body.modalita-tab .novita-grid`):

```css
    body.modalita-tab .novita-grid {
      grid-template-columns: repeat(4, 1fr);
      gap: 8px;
    }
```

SOSTITUISCI CON:

```css
    body.modalita-tab .novita-grid {
      grid-template-columns: repeat(5, 1fr);
      gap: 8px;
    }
```

═══════════════════════════════════════════════════════════════════════════
## 2. popup.html — markup: nuovo bottone "Wishlist" nella griglia Novità
═══════════════════════════════════════════════════════════════════════════

CERCA:

```html
      <button class="novita-btn novita-btn-primary" id="btnSealed" title="Aggiungi prodotti sealed al foglio">
        <span class="novita-btn-icon">📦</span>
        <span class="novita-btn-label">Sealed</span>
      </button>
      <button class="novita-btn novita-btn-soon" id="btnScambi" title="In arrivo — presto disponibile">
```

SOSTITUISCI CON (aggiunge il bottone Wishlist tra Sealed e Scambi):

```html
      <button class="novita-btn novita-btn-primary" id="btnSealed" title="Aggiungi prodotti sealed al foglio">
        <span class="novita-btn-icon">📦</span>
        <span class="novita-btn-label">Sealed</span>
      </button>
      <button class="novita-btn novita-btn-primary" id="btnWishlist" title="Gestisci la wishlist — carte da comprare">
        <span class="novita-btn-icon">🗂️</span>
        <span class="novita-btn-label">Wishlist</span>
      </button>
      <button class="novita-btn novita-btn-soon" id="btnScambi" title="In arrivo — presto disponibile">
```

═══════════════════════════════════════════════════════════════════════════
## 3. popup.js — apertura della pagina Wishlist
═══════════════════════════════════════════════════════════════════════════

CERCA:

```js
// ── BOTTONE SEALED ────────────────────────────────────────────────────────────
document.getElementById('btnSealed').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('aggiungi_sealed_popup.html?modo=tab'), active: true });
});
```

SOSTITUISCI CON (aggiunge il bottone Wishlist subito dopo, stesso pattern):

```js
// ── BOTTONE SEALED ────────────────────────────────────────────────────────────
document.getElementById('btnSealed').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('aggiungi_sealed_popup.html?modo=tab'), active: true });
});

// ── BOTTONE WISHLIST ──────────────────────────────────────────────────────────
document.getElementById('btnWishlist').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('aggiungi_wishlist_popup.html?modo=tab'), active: true });
});
```

═══════════════════════════════════════════════════════════════════════════
## 4. Google Sheet — crea la scheda "Wishlist"
═══════════════════════════════════════════════════════════════════════════

Nel tuo Google Sheet (lo stesso dell'Inventario), crea una nuova linguetta
chiamata `Wishlist` (o il nome che preferisci — lo configurerai nella
pagina stessa). Intestazioni consigliate riga 1-3 libere come per
l'Inventario, dati da riga 4:

| Colonna | Contenuto |
|---|---|
| B | Nome carta |
| C | Codice set |
| E | Quantità desiderata |
| F | Lingua |
| G | Condizione |
| H | URL Cardmarket |
| I | Prezzo attuale (scritto automaticamente) |
| J | Prezzo obiettivo (facoltativo, anche a mano) |
| K | Note |

═══════════════════════════════════════════════════════════════════════════
## 5. Apps Script — incolla le 2 nuove azioni
═══════════════════════════════════════════════════════════════════════════

Vedi `apps_script_wishlist_snippet.gs` — va incollato dentro `doPost(e)`
nel tuo `webapp_scrivi_prezzi.gs` esistente (posizione esatta indicata nel
commento in testa al file). Dopo averlo incollato:

1. Salva (Ctrl+S) nell'editor Apps Script.
2. **"Gestisci distribuzioni" → modifica la versione attiva** (o crea una
   nuova distribuzione) — salvare da solo l'editor non basta, l'URL
   pubblicato resta sulla versione precedente finché non ridistribuisci
   (stesso promemoria già presente in ISTRUZIONI.md).

═══════════════════════════════════════════════════════════════════════════
## 6. CHANGELOG.md — nuova voce in cima al file
═══════════════════════════════════════════════════════════════════════════

Aggiungi questo blocco subito dopo la riga
`Tutte le modifiche rilevanti al progetto sono elencate qui, dalla più
recente alla meno recente.` (cioè PRIMA di `## v2.21`):

```markdown
## v2.22 — 2026-07-18

### Novità
- **🗂️ Wishlist** — nuovo terzo flusso, accanto a "➕ Carte" e "📦 Sealed":
  una pagina dedicata per registrare le carte che vuoi comprare (non che
  possiedi già), su una scheda separata dello stesso Google Sheet
  dell'Inventario. Stessa sintassi bulk delle carte (codice/nome, lingua,
  condizione, RH, 1ED, formato con virgola per nomi tipo "Mew EX"), con in
  più un **prezzo obiettivo** opzionale: aggiungi `@PREZZO` in qualunque
  punto della riga (es. `MEW008 @15`) per segnare la soglia sotto cui
  conviene comprare — le carte scese sotto quella soglia vengono
  evidenziate in verde nel pannello "📋 Wishlist attuale".
- **🔄 Aggiorna prezzi** (Wishlist) — ricontrolla in sequenza il prezzo di
  tutte le carte già in wishlist, riusando la stessa infrastruttura di
  lettura prezzo già collaudata nel controllo prezzi principale — nessuna
  modifica al service worker.
- **✓ Comprata** (Wishlist) — sposta con un click la carta dalla Wishlist
  all'Inventario (stessa configurazione Web App/Sheet ID già impostata nel
  popup principale), svuotando la riga di origine. **🗑️ Rimuovi** elimina
  la riga senza spostarla, per le carte che non interessano più.
- Richiede due nuove azioni lato Apps Script (`leggiWishlist`,
  `svuotaRiga`) — vedi `apps_script_wishlist_snippet.gs` e Parte 10 di
  `ISTRUZIONI.md` per il setup.
```

═══════════════════════════════════════════════════════════════════════════
## 7. ISTRUZIONI.md — nuova sezione (facoltativa ma consigliata)
═══════════════════════════════════════════════════════════════════════════

Aggiungi una nuova "PARTE 10" dopo la Parte 9 esistente ("Temi e altre
funzioni"), e aggiorna la "Struttura dei file" in fondo aggiungendo la riga:

```
├── aggiungi_wishlist_popup.html/.js  — bulk "wishlist" + gestione comprate/rimosse
```

Testo suggerito per la nuova Parte 10:

```markdown
## PARTE 10 — Wishlist (carte da comprare)

Apre una pagina dedicata (🗂️ Wishlist dal popup principale) per registrare
le carte che vuoi comprare — non quelle già in collezione — su una scheda
separata dello stesso Google Sheet dell'Inventario (di norma chiamata
`Wishlist`, vedi Parte 1 per crearla).

### Aggiungere carte
Stesso bulk-add e stessa sintassi riga della Parte 7 ("Aggiungi carte
sbustate"). In più, aggiungi `@PREZZO` in qualunque punto della riga per
impostare un prezzo obiettivo — es. `MEW008 @15` o `Mew EX, EX @12`.
Facoltativo: senza `@` la colonna resta vuota, modificabile a mano nel
foglio in qualunque momento.

### Wishlist attuale
Clicca "↺ Carica" per vedere l'elenco delle carte già in wishlist. Le
righe con prezzo attuale ≤ prezzo obiettivo sono evidenziate in verde. Per
ogni carta:
- **✓ Comprata** — la scrive nell'Inventario (stessa Web App/foglio già
  configurati) e la rimuove dalla Wishlist.
- **🗑️ Rimuovi** — la toglie dalla Wishlist senza spostarla altrove.

### Aggiornare i prezzi
"🔄 Aggiorna prezzi" ricontrolla in sequenza il prezzo di tutte le carte
caricate — stesso comportamento (delay, gestione Cloudflare/rate limit) del
controllo prezzi principale.
```
