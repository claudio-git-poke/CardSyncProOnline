// ── COLONNA IMMAGINE ─────────────────────────────────────────────────────────
// L'immagine (URL raw) viene scritta in colonna M come testo.
// La sidebar la legge per mostrare l'anteprima al click sulla riga.
// NON si usa =IMAGE() perché vogliamo l'URL grezzo leggibile da Apps Script.
var COL_IMMAGINE = 'M';

// ── MENU E SIDEBAR ────────────────────────────────────────────────────────────
function onOpen() {
  SpreadsheetApp.getUi()
    .createMenu('CardSync')
    .addItem('📷 Mostra anteprima carte', 'mostraSidebar')
    .addToUi();
}

function mostraSidebar() {
  var html = HtmlService.createHtmlOutputFromFile('sidebar')
    .setTitle('Anteprima carta')
    .setWidth(260);
  SpreadsheetApp.getUi().showSidebar(html);
}

/**
 * Chiamata dalla sidebar via google.script.run ogni 800ms.
 * Legge la riga attiva e restituisce i dati della carta (inclusa immagine).
 * Schema foglio: B=nome C=codice D=location E=qty F=lingua G=condizione H=url I=prezzo L=immagine
 */
function getDatiRigaSelezionata() {
  try {
    var sheet = SpreadsheetApp.getActiveSheet();
    var riga  = sheet.getActiveRange().getRow();

    // Riga 1 = intestazioni
    if (riga < 2) return { riga: riga, messaggio: 'Intestazioni — seleziona una riga dati' };

    // Legge le colonne B→M (colonne 2→13)
    var vals = sheet.getRange(riga, 2, 1, 12).getValues()[0];
    // idx: 0=nome 1=codice 2=location 3=qty 4=lingua 5=condizione 6=url 7=prezzo(H) ...11=immagine(M)
    var nome       = String(vals[0] || '').trim();
    var codice     = String(vals[1] || '').trim();
    var lingua     = String(vals[4] || '').trim();
    var condizione = String(vals[5] || '').trim();
    var url        = String(vals[6] || '').trim();
    var prezzo     = vals[7];   // colonna I
    var immagine   = String(vals[11] || '').trim(); // colonna M

    if (!nome && !immagine) {
      return { riga: riga, messaggio: 'Riga vuota' };
    }

    return {
      riga:       riga,
      nome:       nome,
      codice:     codice,
      lingua:     lingua,
      condizione: condizione,
      url:        url,
      prezzo:     (typeof prezzo === 'number') ? prezzo : (parseFloat(prezzo) || null),
      immagine:   immagine || null,
    };
  } catch(e) {
    return { riga: -1, messaggio: 'Errore: ' + e.toString() };
  }
}

function doPost(e) {
  try {
    var payload = JSON.parse(e.postData.contents);
    var ss = SpreadsheetApp.getActiveSpreadsheet();

    // ═════════════════════════════════════════════════════════════════════
    // AZIONI GESTIONE SCHEDA LOCATION (elenco / aggiungi / rinomina / elimina)
    // — vanno gestite QUI, PRIMA del lookup del foglio Inventario qui sotto:
    // 'elencaLocationTab'/'aggiungiLocationTab' non mandano affatto
    // "sheetName" nel payload (operano solo sulla scheda LOCATION, non
    // sull'Inventario) — se restassero dopo il controllo "if (!sheet)"
    // fallirebbero sempre con "Foglio 'undefined' non trovato" prima
    // ancora di poter essere eseguite. 'rinominaLocationTab'/
    // 'eliminaLocationTab' possono ricevere sheetName (per propagare la
    // modifica in Inventario) ma lo gestiscono già come opzionale
    // (if (foglioInv) {...}), quindi anche loro possono stare qui.
    // ═════════════════════════════════════════════════════════════════════

    // --- AZIONE: ELENCA VALORI SCHEDA LOCATION ---
    if (payload.azione === 'elencaLocationTab') {
      var sheetLocTab = payload.sheetLocationTab || 'LOCATION';
      var colLocTab = payload.colLocationTab || 'B';
      var rigaInizioLocTab = payload.rigaInizioLocationTab || 2;

      var foglioLoc = ss.getSheetByName(sheetLocTab);
      if (!foglioLoc) {
        return risposta({ ok: false, errore: 'Scheda "' + sheetLocTab + '" non trovata.' });
      }

      var ultimaRigaLoc = foglioLoc.getLastRow();
      var elenco = [];
      if (ultimaRigaLoc >= rigaInizioLocTab) {
        var valoriLoc = foglioLoc.getRange(colLocTab + rigaInizioLocTab + ':' + colLocTab + ultimaRigaLoc).getValues();
        for (var i = 0; i < valoriLoc.length; i++) {
          var v = (valoriLoc[i][0] || '').toString().trim();
          if (v) elenco.push(v);
        }
      }

      return risposta({ ok: true, location: elenco });
    }

    // --- AZIONE: AGGIUNGI VALORE ALLA SCHEDA LOCATION ---
    if (payload.azione === 'aggiungiLocationTab') {
      var sheetLocTab = payload.sheetLocationTab || 'LOCATION';
      var colLocTab = payload.colLocationTab || 'B';
      var rigaInizioLocTab = payload.rigaInizioLocationTab || 2;
      var nomeNuovo = (payload.nome || '').toString().trim();

      if (!nomeNuovo) {
        return risposta({ ok: false, errore: 'Nome location mancante.' });
      }

      var foglioLoc = ss.getSheetByName(sheetLocTab);
      if (!foglioLoc) {
        return risposta({ ok: false, errore: 'Scheda "' + sheetLocTab + '" non trovata.' });
      }

      var ultimaRigaLoc = foglioLoc.getLastRow();
      var primaRigaLibera = rigaInizioLocTab;

      if (ultimaRigaLoc >= rigaInizioLocTab) {
        var valoriLoc = foglioLoc.getRange(colLocTab + rigaInizioLocTab + ':' + colLocTab + ultimaRigaLoc).getValues();
        for (var i = 0; i < valoriLoc.length; i++) {
          var v = (valoriLoc[i][0] || '').toString().trim();
          if (v === nomeNuovo) {
            return risposta({ ok: true, giaEsistente: true, riga: rigaInizioLocTab + i });
          }
          if (v) primaRigaLibera = rigaInizioLocTab + i + 1;
        }
      }

      foglioLoc.getRange(colLocTab + primaRigaLibera).setValue(nomeNuovo);

      return risposta({ ok: true, giaEsistente: false, riga: primaRigaLibera });
    }

    // --- AZIONE: RINOMINA VALORE NELLA SCHEDA LOCATION (+ propaga in Inventario) ---
    if (payload.azione === 'rinominaLocationTab') {
      var sheetLocTab = payload.sheetLocationTab || 'LOCATION';
      var colLocTab = payload.colLocationTab || 'B';
      var rigaInizioLocTab = payload.rigaInizioLocationTab || 2;
      var vecchioNome = (payload.vecchioNome || '').toString().trim();
      var nuovoNome = (payload.nuovoNome || '').toString().trim();

      if (!vecchioNome || !nuovoNome) {
        return risposta({ ok: false, errore: 'Nome vecchio/nuovo mancante.' });
      }

      var foglioLoc = ss.getSheetByName(sheetLocTab);
      if (!foglioLoc) {
        return risposta({ ok: false, errore: 'Scheda "' + sheetLocTab + '" non trovata.' });
      }

      // 1) Rinomina nella scheda LOCATION (il "master" della tendina).
      var ultimaRigaLoc = foglioLoc.getLastRow();
      if (ultimaRigaLoc >= rigaInizioLocTab) {
        var rangeLoc = foglioLoc.getRange(colLocTab + rigaInizioLocTab + ':' + colLocTab + ultimaRigaLoc);
        var valoriLoc = rangeLoc.getValues();
        for (var i = 0; i < valoriLoc.length; i++) {
          var v = (valoriLoc[i][0] || '').toString().trim();
          if (v === vecchioNome) { valoriLoc[i][0] = nuovoNome; }
        }
        rangeLoc.setValues(valoriLoc);
      }

      // 2) Propaga il rinomino a tutte le righe dell'Inventario che usavano il
      //    vecchio nome, così restano coerenti con la scheda LOCATION.
      //    sheetName è opzionale qui: se assente/non trovato, si salta solo
      //    questo passaggio di propagazione senza generare errore.
      var foglioInv = payload.sheetName ? ss.getSheetByName(payload.sheetName) : null;
      var righeInventarioAggiornate = 0;
      if (foglioInv) {
        var colInv = payload.colLocation || 'D';
        var rigaInizioInv = payload.rigaInizio || 4;
        var ultimaRigaInv = foglioInv.getLastRow();
        if (ultimaRigaInv >= rigaInizioInv) {
          var rangeInv = foglioInv.getRange(colInv + rigaInizioInv + ':' + colInv + ultimaRigaInv);
          var valoriInv = rangeInv.getValues();
          for (var j = 0; j < valoriInv.length; j++) {
            var vi = (valoriInv[j][0] || '').toString().trim();
            if (vi === vecchioNome) { valoriInv[j][0] = nuovoNome; righeInventarioAggiornate++; }
          }
          if (righeInventarioAggiornate > 0) rangeInv.setValues(valoriInv);
        }
      }

      return risposta({ ok: true, righeInventarioAggiornate: righeInventarioAggiornate });
    }

    // --- AZIONE: ELIMINA VALORE DALLA SCHEDA LOCATION (+ ripristina "?" in Inventario) ---
    if (payload.azione === 'eliminaLocationTab') {
      var sheetLocTab = payload.sheetLocationTab || 'LOCATION';
      var colLocTab = payload.colLocationTab || 'B';
      var rigaInizioLocTab = payload.rigaInizioLocationTab || 2;
      var nomeElimina = (payload.nome || '').toString().trim();

      if (!nomeElimina) {
        return risposta({ ok: false, errore: 'Nome location mancante.' });
      }

      var foglioLoc = ss.getSheetByName(sheetLocTab);
      if (!foglioLoc) {
        return risposta({ ok: false, errore: 'Scheda "' + sheetLocTab + '" non trovata.' });
      }

      // 1) Rimuove la riga corrispondente dalla scheda LOCATION (sparisce dalla
      //    tendina nativa, che punta a quell'intervallo).
      var ultimaRigaLoc = foglioLoc.getLastRow();
      if (ultimaRigaLoc >= rigaInizioLocTab) {
        var valoriLoc = foglioLoc.getRange(colLocTab + rigaInizioLocTab + ':' + colLocTab + ultimaRigaLoc).getValues();
        for (var i = 0; i < valoriLoc.length; i++) {
          var v = (valoriLoc[i][0] || '').toString().trim();
          if (v === nomeElimina) {
            foglioLoc.deleteRow(rigaInizioLocTab + i);
            break;
          }
        }
      }

      // 2) Le righe dell'Inventario che la usavano tornano a "?" (non vengono
      //    cancellate, solo il tag Location viene rimosso). sheetName è
      //    opzionale: se assente/non trovato si salta solo questo passaggio.
      var foglioInv = payload.sheetName ? ss.getSheetByName(payload.sheetName) : null;
      var righeInventarioAggiornate = 0;
      if (foglioInv) {
        var colInv = payload.colLocation || 'D';
        var rigaInizioInv = payload.rigaInizio || 4;
        var ultimaRigaInv = foglioInv.getLastRow();
        if (ultimaRigaInv >= rigaInizioInv) {
          var rangeInv = foglioInv.getRange(colInv + rigaInizioInv + ':' + colInv + ultimaRigaInv);
          var valoriInv = rangeInv.getValues();
          for (var j = 0; j < valoriInv.length; j++) {
            var vi = (valoriInv[j][0] || '').toString().trim();
            if (vi === nomeElimina) { valoriInv[j][0] = '?'; righeInventarioAggiornate++; }
          }
          if (righeInventarioAggiornate > 0) rangeInv.setValues(valoriInv);
        }
      }

      return risposta({ ok: true, righeInventarioAggiornate: righeInventarioAggiornate });
    }

    // ═════════════════════════════════════════════════════════════════════
    // Da qui in poi, tutte le azioni richiedono il foglio Inventario/scheda
    // indicata in sheetName — se manca o non esiste, errore esplicito.
    // ═════════════════════════════════════════════════════════════════════
    var sheetName = payload.sheetName;
    var sheet = ss.getSheetByName(sheetName);

    if (!sheet) {
      return risposta({ ok: false, errore: "Foglio '" + sheetName + "' non trovato." });
    }

    // --- AZIONE: LETTURA DATI ---
    if (payload.azione === "leggi") {
      var rigaInizio = payload.rigaInizio;
      var colUrlNum = colLetteraANumero(payload.colUrl);
      var colLinguaNum = colLetteraANumero(payload.colLingua);
      var colCondizioneNum = colLetteraANumero(payload.colCondizione);
      var colPrezzoNum = colLetteraANumero(payload.colPrezzo);
      var colLocationLettera = (payload.colLocation || 'D').toUpperCase().trim();
      var colLocationNum = colLetteraANumero(colLocationLettera);
      var filtroLocation = (payload.filtroLocation || '').toString().trim().toUpperCase();

      var lastRow = sheet.getLastRow();
      if (lastRow < rigaInizio) {
        return risposta({ ok: true, carte: [] });
      }

      var maxCol = Math.max(colUrlNum, colLinguaNum, colCondizioneNum, colPrezzoNum, colLocationNum, 3);
      var values = sheet.getRange(rigaInizio, 1, lastRow - rigaInizio + 1, maxCol).getValues();

      var carte = [];
      for (var i = 0; i < values.length; i++) {
        var rigaReale = rigaInizio + i;
        var urlBase = String(values[i][colUrlNum - 1] || "").trim();
        var lingua = String(values[i][colLinguaNum - 1] || "").trim();
        var condizione = String(values[i][colCondizioneNum - 1] || "").trim();
        var codice = String(values[i][2] || "").trim();
        var nome = String(values[i][1] || "").trim();
        var location = String(values[i][colLocationNum - 1] || "").trim();
        var prezzoPrecedenteRaw = values[i][colPrezzoNum - 1];
        var prezzoPrecedente;
        if (typeof prezzoPrecedenteRaw === 'number') {
          prezzoPrecedente = prezzoPrecedenteRaw;
        } else {
          prezzoPrecedente = String(prezzoPrecedenteRaw || '').trim();
        }

        if (filtroLocation && location.trim().toUpperCase() !== filtroLocation) {
          continue;
        }

        if (urlBase.indexOf("cardmarket.com") !== -1) {
          carte.push({
            rigaSheet: rigaReale,
            urlBase: urlBase,
            lingua: lingua,
            condizione: condizione,
            codice: codice,
            nome: nome,
            location: location,
            prezzoPrecedente: prezzoPrecedente
          });
        }
      }
      return risposta({ ok: true, carte: carte });
    }

    // --- AZIONE: ANTEPRIMA FOGLIO (tabella completa per anteprima_popup.js) ---
    // A differenza della lettura via export CSV pubblico (gviz/tq), usata in
    // precedenza da anteprima_popup.js, questa azione legge con
    // SpreadsheetApp/getDisplayValues() — che restituisce SEMPRE tutte le
    // righe della griglia reale, comprese quelle NASCOSTE manualmente
    // (tasto destro → Nascondi riga). L'export CSV pubblico, al contrario,
    // esclude del tutto le righe nascoste dal risultato (limite documentato
    // di Google, nessun parametro URL per aggirarlo) — causa reale delle
    // righe che sparivano/disallineavano nell'anteprima quando il foglio
    // conteneva righe nascoste prima della soglia di inizio dati.
    // getDisplayValues() (non getValues()) per restituire lo stesso testo
    // formattato mostrato nella cella (es. prezzi con virgola, date
    // formattate) — coerente con quanto l'export CSV restituiva prima.
    if (payload.azione === "leggiAnteprima") {
      var rigaInizioAnt = payload.rigaInizio || 4;
      var lastRowAnt = sheet.getLastRow();
      if (lastRowAnt < rigaInizioAnt) {
        return risposta({ ok: true, righe: [] });
      }
      // Margine di sicurezza: copre almeno fino alla colonna L anche se il
      // foglio ha ancora meno colonne popolate (es. foglio nuovo, poche
      // carte inserite) — le colonne configurate (Location/Lingua/ecc.)
      // vanno comunque mostrate anche se vuote.
      var lastColAnt = Math.max(sheet.getLastColumn(), 12);
      var numRigheAnt = lastRowAnt - rigaInizioAnt + 1;
      var valsAnt = sheet.getRange(rigaInizioAnt, 1, numRigheAnt, lastColAnt).getDisplayValues();

      var righeAnt = [];
      for (var ia = 0; ia < valsAnt.length; ia++) {
        righeAnt.push({
          rigaSheet: rigaInizioAnt + ia,
          celle: valsAnt[ia],
        });
      }
      return risposta({ ok: true, righe: righeAnt });
    }

    // --- AZIONE: ELENCA VALORI DISTINTI DI LOCATION (per popolare la tendina) ---
    if (payload.azione === "elencaLocation") {
      var colLocationLettera2 = (payload.colLocation || 'D').toUpperCase().trim();
      var colLocationNum2 = colLetteraANumero(colLocationLettera2);
      var rigaInizio2 = payload.rigaInizio || 4;

      var lastRow2 = sheet.getLastRow();
      if (lastRow2 < rigaInizio2) {
        return risposta({ ok: true, location: [], _debug: { lastRow: lastRow2, rigaInizio: rigaInizio2, colLettera: colLocationLettera2, colNum: colLocationNum2 } });
      }

      var valsLoc = sheet.getRange(rigaInizio2, colLocationNum2, lastRow2 - rigaInizio2 + 1, 1).getValues();
      var visti = {};
      var elenco = [];
      for (var j = 0; j < valsLoc.length; j++) {
        var loc = String(valsLoc[j][0] || '').trim();
        if (!loc) continue;
        var chiave = loc.toUpperCase();
        if (!visti[chiave]) {
          visti[chiave] = true;
          elenco.push(loc);
        }
      }
      elenco.sort(function(a, b) { return a.localeCompare(b); });
      // _debug: rimuovi questo campo una volta confermato che funziona —
      // serve solo per vedere a colpo d'occhio quale colonna/riga sono state
      // lette davvero, senza dover ispezionare i log di esecuzione.
      return risposta({ ok: true, location: elenco, _debug: { lastRow: lastRow2, rigaInizio: rigaInizio2, colLettera: colLocationLettera2, colNum: colLocationNum2, righeLette: valsLoc.length } });
    }

    // --- AZIONE: CERCA CARTA ESISTENTE (per controllo duplicati) ---
    if (payload.azione === "cerca") {
      var cercaCodice  = (payload.codice     || '').toString().trim().toUpperCase().replace(/[\s\-]/g, '');
      var cercaLingua  = normalizzaLingua((payload.lingua     || '').toString());
      var cercaCondiz  = normalizzaCondizione((payload.condizione || '').toString());

      var lastRow = sheet.getLastRow();
      var trovate = [];

      if (lastRow >= 2) {
        var vals = sheet.getRange(2, 2, lastRow - 1, 7).getValues();
        for (var i = 0; i < vals.length; i++) {
          var rigaReale  = i + 2;
          var codiceRiga = (vals[i][1] || '').toString().trim().toUpperCase().replace(/[\s\-]/g, '');
          var linguaRiga = normalizzaLingua((vals[i][4] || '').toString());
          var condizRiga = normalizzaCondizione((vals[i][5] || '').toString());

          if (codiceRiga === cercaCodice && linguaRiga === cercaLingua && condizRiga === cercaCondiz) {
            trovate.push({
              riga:      rigaReale,
              nome:      (vals[i][0] || '').toString().trim(),
              codice:    (vals[i][1] || '').toString().trim(),
              location:  (vals[i][2] || '').toString().trim(),
              qty:       Number(vals[i][3]) || 1,
              lingua:    (vals[i][4] || '').toString().trim(),
              condizione:(vals[i][5] || '').toString().trim(),
              url:       (vals[i][6] || '').toString().trim(),
            });
          }
        }
      }
      return risposta({ ok: true, trovate: trovate });
    }

    // --- AZIONE: CERCA BULK (controlla duplicati per più carte in un solo fetch) ---
    if (payload.azione === "cercaBulk") {
      var richieste = payload.richieste || []; // [{ idx, codice, lingua, condizione }]
      var lastRow = sheet.getLastRow();
      var foglioDati = [];

      if (lastRow >= 2) {
        var vals = sheet.getRange(2, 2, lastRow - 1, 7).getValues();
        for (var i = 0; i < vals.length; i++) {
          foglioDati.push({
            riga:      i + 2,
            codice:    (vals[i][1] || '').toString().trim().toUpperCase().replace(/[\s\-]/g, ''),
            lingua:    normalizzaLingua((vals[i][4] || '').toString()),
            condizione:normalizzaCondizione((vals[i][5] || '').toString()),
            nome:      (vals[i][0] || '').toString().trim(),
            location:  (vals[i][2] || '').toString().trim(),
            qty:       Number(vals[i][3]) || 1,
            url:       (vals[i][6] || '').toString().trim(),
          });
        }
      }

      var risultati = [];
      for (var r = 0; r < richieste.length; r++) {
        var req = richieste[r];
        var cercaCodice = (req.codice || '').toString().trim().toUpperCase().replace(/[\s\-]/g, '');
        var cercaLingua = normalizzaLingua((req.lingua || '').toString());
        var cercaCondiz = normalizzaCondizione((req.condizione || '').toString());
        var trovate = [];
        for (var f = 0; f < foglioDati.length; f++) {
          var fd = foglioDati[f];
          if (fd.codice === cercaCodice && fd.lingua === cercaLingua && fd.condizione === cercaCondiz) {
            trovate.push({ riga: fd.riga, nome: fd.nome, codice: fd.codice,
              location: fd.location, qty: fd.qty, lingua: fd.lingua,
              condizione: fd.condizione, url: fd.url });
          }
        }
        risultati.push({ idx: req.idx, trovate: trovate });
      }
      return risposta({ ok: true, risultati: risultati });
    }

    // --- AZIONE: AGGIORNA SOLO LA QTY DI UNA RIGA ESISTENTE ---
    if (payload.azione === "aggiornaQty") {
      var riga     = payload.riga;
      var nuovaQty = payload.qty;
      sheet.getRange(riga, colLetteraANumero('E')).setValue(nuovaQty);
      return risposta({ ok: true, riga: riga });
    }

    // --- AZIONE: AGGIUNGI NUOVA CARTA ---
    if (payload.azione === "aggiungi") {
      var rigaDati = payload.rigaDati;
      if (!rigaDati) {
        return risposta({ ok: false, errore: "rigaDati mancante nel payload." });
      }

      var colBValues = sheet.getRange("B:B").getValues();
      var ultimaRigaB = 0;
      for (var i = 0; i < colBValues.length; i++) {
        if (String(colBValues[i][0]).trim() !== '') {
          ultimaRigaB = i + 1;
        }
      }
      var primaRigaVuota = Math.max(ultimaRigaB + 1, 4); // le righe 1-3 sono riservate

      for (var colLettera in rigaDati) {
        var valore = rigaDati[colLettera];
        if (valore === undefined || valore === null) continue;
        var colN = colLetteraANumero(colLettera);
        if (colN < 1) continue;
        sheet.getRange(primaRigaVuota, colN).setValue(valore);
      }

      return risposta({ ok: true, riga: primaRigaVuota });
    }

    // --- AZIONE: LEGGI WISHLIST (righe complete: nome, codice, qty, lingua,
    // condizione, url, prezzo, prezzo obiettivo, note) — usata dal pannello
    // "📋 Wishlist attuale" della pagina Wishlist per mostrare l'elenco e
    // permettere "✓ Comprata" / "🗑️ Rimuovi". A differenza dell'azione
    // "leggi" (pensata per il controllo prezzi dell'Inventario, con Location
    // e filtro), questa restituisce TUTTE le colonne rilevanti per la
    // wishlist in un colpo solo. ---
    if (payload.azione === "leggiWishlist") {
      var rigaInizioWL = payload.rigaInizio || 4;
      var lastRowWL = sheet.getLastRow();
      if (lastRowWL < rigaInizioWL) {
        return risposta({ ok: true, righe: [] });
      }
      // B..K = colonne 2..11
      var valsWL = sheet.getRange(rigaInizioWL, 2, lastRowWL - rigaInizioWL + 1, 10).getValues();
      var righeWL = [];
      for (var iw = 0; iw < valsWL.length; iw++) {
        var rigaRealeWL = rigaInizioWL + iw;
        var nomeWL   = String(valsWL[iw][0] || '').trim();   // B
        var codiceWL = String(valsWL[iw][1] || '').trim();   // C
        var qtyWL    = valsWL[iw][3];                        // E
        var linguaWL = String(valsWL[iw][4] || '').trim();   // F
        var condWL   = String(valsWL[iw][5] || '').trim();   // G
        var urlWL    = String(valsWL[iw][6] || '').trim();   // H
        var prezzoWLRaw = valsWL[iw][7];                     // I
        var obiettivoWLRaw = valsWL[iw][8];                  // J
        var noteWL   = String(valsWL[iw][9] || '').trim();   // K

        // Riga considerata vuota/da ignorare se non ha nome né url.
        if (!nomeWL && !urlWL) continue;

        righeWL.push({
          riga:            rigaRealeWL,
          nome:            nomeWL,
          codice:          codiceWL,
          qty:             Number(qtyWL) || 1,
          lingua:          linguaWL,
          condizione:      condWL,
          url:             urlWL,
          prezzo:          (typeof prezzoWLRaw === 'number') ? prezzoWLRaw : (parseFloat(prezzoWLRaw) || null),
          prezzoObiettivo: (typeof obiettivoWLRaw === 'number') ? obiettivoWLRaw : (parseFloat(obiettivoWLRaw) || null),
          note:            noteWL,
        });
      }
      return risposta({ ok: true, righe: righeWL });
    }

    // --- AZIONE: SVUOTA RIGA (usata da "✓ Comprata" e "🗑️ Rimuovi" nella
    // Wishlist, per liberare la riga dopo averla eventualmente copiata in
    // Inventario). Generica: pulisce un intervallo di colonne su una riga,
    // qualunque sia il foglio — non elimina la riga fisica (niente shift
    // delle righe sottostanti), solo il contenuto delle celle. ---
    if (payload.azione === "svuotaRiga") {
      var rigaDaSvuotare = payload.riga;
      var colDaSvuotare  = colLetteraANumero(payload.colDa || 'B');
      var colASvuotare   = colLetteraANumero(payload.colA  || 'K');
      var numColSvuotare = colASvuotare - colDaSvuotare + 1;
      if (rigaDaSvuotare && numColSvuotare > 0) {
        sheet.getRange(rigaDaSvuotare, colDaSvuotare, 1, numColSvuotare).clearContent();
      }
      return risposta({ ok: true, riga: rigaDaSvuotare });
    }

    // --- FALLBACK: SCRITTURA PREZZI RIGA PER RIGA (nessuna azione esplicita) ---
    // Se arriviamo qui, l'azione non è una delle precedenti — questo ramo
    // esiste per il flusso "scriviDati/scriviUrl" del popup principale, che
    // NON manda un campo "azione", solo { sheetName, colPrezzo, prezzi }.
    // Guardia esplicita: se "prezzi" manca, l'azione richiesta non esiste
    // affatto (probabile refuso o mismatch di versione) — invece di andare
    // in crash su forEach di undefined, rispondiamo con un errore chiaro
    // che nomina l'azione ricevuta.
    if (!payload.prezzi) {
      return risposta({
        ok: false,
        errore: "Azione non riconosciuta: '" + payload.azione + "' (nessun ramo combacia e 'prezzi' è assente dal payload).",
        _azioneRicevuta: payload.azione || null
      });
    }

    var colPrezzo = (payload.colPrezzo || '').toUpperCase().trim();
    var prezzi    = payload.prezzi;
    var colNum    = colLetteraANumero(colPrezzo);

    var scritti = 0;
    prezzi.forEach(function(item) {
      if (item.riga && item.prezzo !== undefined) {
        var colTarget = item.colonna ? colLetteraANumero(item.colonna.toUpperCase().trim()) : colNum;
        sheet.getRange(item.riga, colTarget).setValue(item.prezzo);
        scritti++;
      }
    });

    return risposta({ ok: true, scritti: scritti });

  } catch (err) {
    return risposta({ ok: false, errore: err.toString() });
  }
}

function colLetteraANumero(col) {
  col = String(col).toUpperCase().trim();
  var n = 0;
  for (var i = 0; i < col.length; i++) {
    n = n * 26 + col.charCodeAt(i) - 64;
  }
  return n;
}

function risposta(obj) {
  return ContentService
    .createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}

function doOptions() {
  return ContentService.createTextOutput("").setMimeType(ContentService.MimeType.TEXT);
}

// Normalizza lingua: ITA/ITALIANO/IT → "IT", ENG/INGLESE/EN → "EN", ecc.
function normalizzaLingua(val) {
  var v = val.toString().trim().toUpperCase();
  var map = {
    'IT':1,'ITA':1,'ITALIANO':1,'ITALIAN':1,
    'EN':2,'ENG':2,'INGLESE':2,'ENGLISH':2,'ING':2,
    'FR':3,'FRA':3,'FRANCESE':3,'FRENCH':3,
    'DE':4,'GER':4,'TEDESCO':4,'GERMAN':4,'TED':4,
    'ES':5,'SPA':5,'SPAGNOLO':5,'SPANISH':5,'SP':5,
    'PT':6,'POR':6,'PORTOGHESE':6,'PORTUGUESE':6,
    'JA':7,'JP':7,'JAP':7,'GIAPPONESE':7,'JAPANESE':7,'GIAP':7,
    'KOR':8,'KO':8,'COREANO':8,'KOREAN':8,'COR':8,
    'CHN':9,'CHN-S':9,'CINESE-S':9,'CINESE':9,'CIN':9,'CHINESE-S':9,
    'CHN-T':10,'CIN-T':10,'CINESE-T':10,'CHINESE-T':10,
    'IND':11,'INDONESIANO':11,'INDONESIAN':11,
    'THAI':12,'TAI':12,'TAILANDESE':12,'THAI':12,
    'RU':13,'RUS':13,'RUSSO':13,'RUSSIAN':13,
  };
  var gruppoBreve = ['IT','EN','FR','DE','ES','PT','JA','KOR','CHN','CHN-T','IND','THAI','RU'];
  var idx = map[v];
  return idx ? gruppoBreve[idx - 1] : v;
}

// Normalizza condizione: rimuove +/- e porta al codice base (NM+/NM-/NM → "NM")
function normalizzaCondizione(val) {
  var v = val.toString().trim().toUpperCase();
  if (v.endsWith('+') || v.endsWith('-')) v = v.slice(0, -1).trim();
  var map = {
    'MINT':'MT','NEAR MINT':'NM','EXCELLENT':'EX',
    'GOOD':'GD','LIGHT PLAYED':'LP','PLAYED':'PL','POOR':'PO'
  };
  return map[v] || v;
}