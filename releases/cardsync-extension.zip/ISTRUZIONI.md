# CardSync Pro — Istruzioni

CardSync Pro è un'estensione Chrome che legge i prezzi delle carte Pokémon
(e dei prodotti sealed) da Cardmarket e li scrive automaticamente nel tuo
Google Sheet. Include anche due strumenti per **aggiungere** nuove righe al
foglio (carte sbustate e prodotti sealed) leggendo dati e prezzo
direttamente da Cardmarket.

---

## Cosa fa, in sintesi

- **Controllo prezzi** (popup principale): rilegge periodicamente gli URL
  Cardmarket già presenti nel foglio e aggiorna prezzo e variazione.
- **➕ Aggiungi carte sbustate**: incolli una lista di codici/nomi carta,
  l'estensione cerca ogni carta su Cardmarket, legge nome/prezzo e crea una
  nuova riga nel foglio.
- **📦 Aggiungi sealed**: stessa cosa per prodotti sealed (box, ETB, display…).
- Entrambi gli strumenti "aggiungi" girano in **bulk** (una lista intera,
  non una carta alla volta) e gestiscono da soli blocchi Cloudflare, rate
  limit, sessioni interrotte, carte ambigue da correggere a mano.

---

## PARTE 1 — Prepara il Google Sheet

1. Apri il tuo Google Sheet.
2. Clicca **Condividi** (in alto a destra).
3. Cambia accesso a **"Chiunque abbia il link può visualizzare"**
   — serve solo per la lettura degli URL, non per la scrittura.
4. Copia l'**ID del foglio** dall'URL:
   ```
   https://docs.google.com/spreadsheets/d/[ QUI C'È L'ID ]/edit
   ```
5. Prendi nota del **nome della scheda** (il nome della linguetta in basso,
   es. `Inventario`).

### Colonne attese (personalizzabili nel popup)

| Colonna predefinita | Contenuto |
|---|---|
| B | Nome carta/prodotto |
| C | Codice set (solo carte) |
| D | Location (facoltativo, per il filtro) |
| E | Quantità |
| F | Lingua |
| G | Condizione (solo carte) |
| H | URL Cardmarket |
| I | Prezzo |
| J | Variazione % (facoltativo) |
| K | Note (solo carte — RH/1ED/condizione +/-) |

Tutte le lettere colonna, tranne Note, si possono cambiare dal popup
principale (riquadro "📋 Colonne foglio"). La riga di inizio lettura è
configurabile allo stesso modo (default riga 4).

---

## PARTE 2 — Configura la Web App (per scrivere nel foglio)

1. Nel tuo Google Sheet vai su **Estensioni → Apps Script**.
2. Cancella tutto il codice esistente.
3. Incolla il contenuto del file `webapp_scrivi_prezzi.gs`.
4. Salva (Ctrl+S).
5. Clicca **"Distribuisci" → "Nuova distribuzione"**.
6. Impostazioni:
   - Tipo: **App web**
   - Esegui come: **Me (il tuo account)**
   - Accesso: **Chiunque**
7. Clicca **"Distribuisci"** e autorizza quando richiesto.
8. **Copia l'URL** che termina con `/exec` — serve nel passo successivo.

> ⚠️ Se in futuro modifichi lo script, ricordati di **"Gestisci
> distribuzioni" → modifica la versione attiva** (o crea una nuova
> distribuzione): salvare da solo l'editor non basta, l'URL pubblicato resta
> sulla versione precedente finché non ridistribuisci.

---

## PARTE 3 — Installa l'estensione Chrome

1. Apri Chrome e vai su `chrome://extensions`.
2. Attiva **"Modalità sviluppatore"** (interruttore in alto a destra).
3. Clicca **"Carica estensione non pacchettizzata"**.
4. Seleziona la cartella del progetto (quella con `manifest.json`).
5. L'estensione appare nella barra di Chrome 🃏.

---

## PARTE 4 — Prima configurazione

1. Clicca sull'icona dell'estensione.
2. Apri il riquadro **"⚡ Connessione"** e poi il toggle interno
   **"⚙️ Configura manualmente"**, dove compili:
   - **URL Web App** (dal Parte 2, quello che finisce in `/exec`)
   - **ID Google Sheet**
   - **Nome scheda foglio**
3. Clicca **"🔌 Controlla connessione"**: verifica che Web App e foglio
   siano raggiungibili, poi apre una tab su Cardmarket per controllare se
   sei loggato (accedi lì se serve).
4. Regola le colonne nel riquadro **"📋 Colonne foglio"** se non usi quelle
   predefinite.

Questa configurazione (URL Web App, ID foglio, nome scheda, tema, tutte le
impostazioni comportamentali) è **condivisa** tra popup principale e le due
pagine "Aggiungi carte"/"Aggiungi sealed" — la imposti una volta sola.

---

## PARTE 4bis — Profilo condiviso (più persone/PC)

Se più persone usano la stessa estensione su PC diversi (es. tu e un amico,
ciascuno con il proprio foglio/Web App), puoi evitare di ricopiare a mano
URL Web App/ID Sheet/Nome scheda ogni volta con un **registro profili**
condiviso: un secondo Google Sheet, separato dal tuo inventario, che
funziona da "elenco" con una riga per persona.

### Setup del registro (una tantum, lo fa una persona sola)

1. Crea un **nuovo** Google Sheet (es. "CardSync — Profili"), diverso da
   quello dell'inventario.
2. **Estensioni → Apps Script**, cancella il codice esistente e incolla il
   contenuto di `webapp_registro_profili.gs`. Salva.
3. **Distribuisci → Nuova distribuzione**: Tipo "App web", Esegui come "Me",
   Accesso "Chiunque". Distribuisci e autorizza.
4. Copia l'URL che finisce in `/exec`.
5. Condividi quell'URL con chi userà l'estensione insieme a te (stesso
   livello di riservatezza delle credenziali dei fogli: chi ha l'URL può
   leggere/scrivere tutti i profili nel registro).

### Uso quotidiano (ogni PC/installazione)

1. Apri il riquadro **"⚡ Connessione"**: la tendina **"Profilo"** compare
   subito, senza nient'altro attorno — nessun campo da compilare per
   vederla, l'URL del registro è già precompilato di default (lo stesso per
   tutti, essendo un unico registro condiviso). Aprire il riquadro rilegge
   sempre l'elenco più aggiornato dei profili.
2. La prima volta che configuri la TUA connessione, apri il toggle interno
   **"⚙️ Configura manualmente"**, compila URL Web App/ID Sheet/Nome scheda
   (Parte 4), poi clicca **"💾 Salva come profilo…"**, dai un nome (es. il
   tuo nome) e conferma.
3. Da quel momento, chiunque apra l'estensione può **scegliere quel nome
   dalla tendina "Profilo"**: viene caricato subito, nessun bottone a parte
   da cliccare, e non serve nemmeno aprire "⚙️ Configura manualmente".
4. Cambiare persona (es. il tuo amico usa il tuo PC) richiede solo aprire
   il riquadro "⚡ Connessione" e scegliere il suo nome dalla tendina.

---

## PARTE 5 — Login su Cardmarket (importante)

Diverse operazioni (controllo prezzi, aggiunta carte/sealed) leggono le
offerte da Cardmarket in una tab in background. Cardmarket nasconde il
bottone "Aggiungi al carrello" per le offerte non acquistabili da un
account non loggato, e questo viene usato dall'estensione come controllo
di attendibilità del prezzo — **senza essere loggati, ogni carta rischia di
risultare "Esaurita"**.

Prima di ogni sessione (▶ Avvia, 📋/📦 Aggiungi tutte) compare un modale di
promemoria ("🚀 Recluta il Team Rocket!"): dopo la conferma, l'estensione
verifica *davvero* il login (in modo silenzioso, senza rubarti il focus se
sei già loggato) e blocca l'avvio se risulti disconnesso, aprendoti una tab
per accedere.

---

## PARTE 6 — Controllo prezzi (popup principale)

1. Clicca **▶ Avvia** per la lettura reale, oppure **🧪 Prova** per un dry
   run (simula senza aprire tab né scrivere nel foglio).
2. La sessione riusa un'unica tab in background per tutte le carte,
   mostra una barra di progresso, un timer e i conteggi 🔺/🔻/➖.
3. Cliccando sulle pillole "🔺 saliti" / "🔻 scesi" si apre il dettaglio
   delle carte con la variazione di prezzo.
4. **Filtro Location**: se compili la colonna Location nel foglio, puoi
   restringere una sessione a un solo gruppo di carte dal menu a tendina
   "🗂️ Filtro Location" (aggiorna l'elenco col bottone dedicato).
5. Puoi fermare la sessione in ogni momento (🛑 Ferma): riprende dalla riga
   giusta al prossimo avvio.

### Impostazioni comportamentali (⚙, condivise ovunque)
- **Ritardo minimo/massimo**: intervallo casuale tra una carta e l'altra.
- **Timeout Cloudflare**: quanto aspettare che un blocco venga risolto a mano.
- **Soglia variazione minima**: sotto questa soglia il prezzo non viene
  riscritto (se "Solo variazioni di prezzo" è attivo).
- **Max N/D consecutivi**: dopo N carte non lette di fila, pausa anti-bot.
- **Pausa lunga ogni N carte**: pausa periodica indipendente dal ritardo base.
- **Avviso sonoro Cloudflare**: suona quando serve intervenire manualmente.

---

## PARTE 7 — Aggiungere carte sbustate (➕ Carte)

Apre una pagina dedicata (in una tab, non nel popup) con un campo di testo
bulk: **una carta per riga**.

### Formato riga
- `CODICE` — attaccato, zeri inclusi: `MEW008`, `SV01006`.
- `NOME NUMERO` — staccati, solo col vero nome carta: `Eevee 55`, `Mew 151`.
- Modificatori opzionali (in qualunque ordine, separati da spazio):
  lingua (`EN`, `JAP`, …), condizione (`NM`, `EX+`, `LP-`, …), `RH` (reverse
  holo), `1ED` (prima edizione).
- **Nomi che contengono parole come EX/GD** (es. "Mew EX"): separa nome e
  modificatori con una virgola — `Mew EX, EX RH` → nome "Mew EX",
  condizione EX, reverse holo. Senza virgola l'ultimo "EX" verrebbe letto
  come condizione.
- **Nota libera** (solo col formato con virgola): dopo la virgola,
  qualunque parola che non sia lingua/condizione/RH/1ED viene scritta nella
  colonna Note — `FST007, NM error` → codice FST007, condizione NM, nota
  "ERROR". Utile per le carte più vecchie il cui link Cardmarket non
  contiene il codice (es. set Fusion Strike). Non disponibile nel formato
  senza virgola: non c'è modo affidabile di distinguere una parola in più
  del nome da una nota senza il separatore esplicito.

Esempi validi: `CRI090` · `Eevee 55` · `xBLK026 EN NM RH` · `Mew EX, EX` ·
`FST007, NM error`

Clicca **📋 Aggiungi tutte** per avviare la sessione. Le carte non
riconosciute automaticamente finiscono in un pannello di **correzione
manuale** (link diretto alla ricerca Cardmarket, incolla l'URL corretto).
Le carte fallite per errore di rete/Cloudflare/timeout finiscono in un
riquadro copiabile per riprovare più tardi.

---

## PARTE 8 — Aggiungere prodotti sealed (📦 Sealed)

Stessa logica, un prodotto per riga: **nome completo del prodotto**
(scrivi "Elite Trainer Box" per esteso, non "ETB").

- Quantità: un numero finale (`… Elite Trainer Box 2`) oppure, se il nome
  finisce già con un numero che fa parte del nome (Series/Vol/Set/Box…),
  usa `xN`: `… Series 2 x3` → 3 copie.
- Lingua opzionale in qualunque punto della riga (default IT).

---

## PARTE 9 — Temi e altre funzioni

- **⚙ Aspetto**: 16 temi selezionabili (incluso "Team Rocket" e "Pokéball"),
  sincronizzati automaticamente su tutte le pagine dell'estensione.
- **📜 Registro modifiche**: apre la cronologia delle versioni in una tab,
  con lo stesso tema scelto.
- **🐛 Segnala un bug**: link in fondo alla pagina verso il modulo di
  segnalazione.
- **Log sessione**: copiabile, esportabile in CSV, cancellabile.

---
## PARTE 10 — Wishlist (carte da comprare)

Apre una pagina dedicata (🗂️ Wishlist dal popup principale) per registrare
le carte che vuoi comprare — non quelle già in collezione — su una scheda
separata dello stesso Google Sheet dell'Inventario (di norma chiamata
`Wishlist`, vedi Parte 1 per crearla).

### Aggiungere carte
Stesso bulk-add e stessa sintassi riga della Parte 7 ("Aggiungi carte
sbustate"). In più, aggiungi `@PREZZO` in qualunque punto della riga per
impostare un prezzo obiettivo — es. `MEW008 @15` o `Mew EX, EX @12`.
Facoltativo: senza `@` la colonna resta vuota, modificabile a mano nel
foglio in qualunque momento.

### Wishlist attuale
Clicca "↺ Carica" per vedere l'elenco delle carte già in wishlist. Le
righe con prezzo attuale ≤ prezzo obiettivo sono evidenziate in verde. Per
ogni carta:
- **✓ Comprata** — la scrive nell'Inventario (stessa Web App/foglio già
  configurati) e la rimuove dalla Wishlist.
- **🗑️ Rimuovi** — la toglie dalla Wishlist senza spostarla altrove.

### Aggiornare i prezzi
"🔄 Aggiorna prezzi" ricontrolla in sequenza il prezzo di tutte le carte
caricate — stesso comportamento (delay, gestione Cloudflare/rate limit) del
controllo prezzi principale.

---

## PARTE 11 — Gestione Location

Le location vivono in una scheda dedicata chiamata **"LOCATION"** (colonna
B, valori dalla riga 2 in poi) — quella già collegata alla validazione dati
della tendina Location nell'Inventario. Non serve crearla da zero: se hai
già una tendina Location che funziona nel foglio, questa è la scheda che la
alimenta.

Le pagine "➕ Carte", "📦 Sealed" e "✓ Comprata" (Wishlist) hanno un campo
**"📍 Location"** con autocompletamento su quell'elenco: scegli un valore
esistente dal menu a tendina, oppure scrivine uno nuovo — viene registrato
in automatico nella scheda LOCATION appena lo usi (avvio sessione bulk per
Carte/Sealed, click su "✓ Comprata" per Wishlist), e da quel momento compare
anche nella tendina nativa del foglio, non solo nelle carte appena aggiunte.
Vale per tutte le carte/prodotti di una sessione (non riga per riga) ed è
condiviso tra le tre pagine: impostalo una volta, resta anche passando da
una all'altra sullo stesso lotto.

Dal menu **📍 Gestisci location** (icona nell'header dell'hub) puoi anche:
- **➕ Aggiungere** una location senza dover aggiungere una carta insieme.
- **✏️ Rinominare** una location — aggiorna sia la scheda LOCATION sia
  tutte le righe dell'Inventario che la usavano.
- **🗑️ Eliminare** una location dalla scheda LOCATION (sparisce dalla
  tendina) — le righe dell'Inventario che la usavano tornano a `?` (stesso
  valore scritto di default), non vengono toccate/cancellate.

### Richiede un piccolo aggiornamento allo script Apps Script
Questa funzione usa quattro nuove azioni (`elencaLocationTab`,
`aggiungiLocationTab`, `rinominaLocationTab`, `eliminaLocationTab`) non
presenti nelle versioni precedenti di `webapp_scrivi_prezzi.gs`:

1. Apri il tuo Google Sheet → Estensioni → Apps Script.
2. Incolla il contenuto di `apps_script_location_snippet.gs` nel tuo
   `doPost(e)` esistente, accanto alle altre azioni (`elencaLocation`,
   `aggiungi`, ecc.) — vedi i commenti in testa al file per i dettagli.
   Se avevi già incollato una versione precedente di questo file, rimuovila
   prima (i nomi azione sono cambiati).
3. Salva (Ctrl+S).
4. **"Gestisci distribuzioni" → modifica la versione attiva** (o crea una
   nuova distribuzione): salvare da solo l'editor non basta, l'URL
   pubblicato resta sulla versione precedente finché non ridistribuisci.

Finché non fai questo passaggio, il campo "📍 Location" e il menu "📍
Gestisci location" restituiranno un errore di connessione.

---

## Significato dei valori nella cella prezzo

- `Esaurita` — pagina caricata correttamente ma nessuna offerta soddisfa i
  filtri lingua/condizione richiesti.
- `N/D` — la pagina non si è caricata/letta correttamente, riprova più tardi.
- `Timeout` — la pagina ha impiegato troppo a rispondere.
- Cella vuota dopo un blocco Cloudflare non risolto in tempo — la sessione
  passa alla carta successiva.

---

## Struttura dei file

```
cardmarket-extension/
├── manifest.json               — configurazione estensione
├── popup.html / popup.js       — controllo prezzi (popup principale)
├── aggiungi_carta_popup.html/.js   — bulk "aggiungi carte sbustate"
├── aggiungi_sealed_popup.html/.js  — bulk "aggiungi sealed"
├── aggiungi_wishlist_popup.html/.js  — bulk "wishlist" + gestione comprate/rimosse
├── changelog.html / changelog.js   — visualizzatore CHANGELOG.md
├── background.js               — service worker (logica di lettura Cardmarket)
├── content.js                  — legge il prezzo dalla pagina Cardmarket
├── shared.js                   — mappe/funzioni condivise (lingua, condizione, filtri)
├── tab_detect.js               — rileva se una pagina è aperta in tab o popup
├── offscreen.html / offscreen.js   — riproduzione avviso sonoro Cloudflare
├── sidebar.html                 — pannello laterale Google Sheets (anteprima carta)
├── CHANGELOG.md                 — cronologia versioni
├── webapp_scrivi_prezzi.gs      — script da incollare in Apps Script (foglio inventario)
├── webapp_registro_profili.gs  — script per un secondo Sheet "registro profili" (opzionale)
└── apps_script_location_snippet.gs — snippet da aggiungere al doPost esistente (rinomina/elimina location)

```

---

## Note importanti

- **Lascia Chrome aperto** mentre l'estensione lavora — le sessioni bulk
  possono richiedere diversi minuti su liste lunghe.
- Le sessioni interrotte (🛑 Ferma, o chiusura del popup) si possono
  **riprendere** dal punto esatto in cui erano rimaste, sia nel controllo
  prezzi sia nei due flussi bulk.
- Un blocco `Error 1015` (rate limit Cardmarket) mette in pausa
  automaticamente per 30 minuti prima di ritentare.
