// ── app.js ────────────────────────────────────────────────────────────────────
// Pagina hub (app.html): ospita le sezioni (Controllo prezzi/Carte/Sealed/
// Wishlist/Coda pendente) come SCHEDE cliccabili in alto (stile "Gestione
// attività"), una visibile alla volta — invece delle vecchie colonne
// affiancate con scroll orizzontale. Ogni iframe punta al file .html già
// esistente (nessuna modifica alla logica interna di bulk/Cloudflare/worker
// tab) — qui si gestisce l'header unico (badge profilo + 📜, al posto degli
// header duplicati di ogni pagina, nascosti via tab_detect.js/embedded-in-hub)
// e il caricamento di TUTTE le colonne insieme al boot, ANCHE quelle non
// visibili in questo momento: i controlli automatici (coda carte in attesa,
// autorun del controllo prezzi condiviso) devono continuare a girare in
// ogni sezione indipendentemente da quale scheda l'utente sta guardando —
// cambiare scheda nasconde/mostra solo il markup (CSS), non scarica né
// ricarica mai gli iframe delle sezioni non attive.

// ── LOGIN SUPABASE ────────────────────────────────────────────────────────────
assicuraLoginSupabase();

const LISTA_TEMI = ['purple', 'green', 'blue', 'contrast', 'dark', 'sakura', 'wine', 'autunno', 'estate', 'heartgold', 'soulsilver', 'steel', 'electric', 'grass', 'pokemon', 'team-rocket'];
const SEZIONI = ['prezzi', 'carte', 'sealed', 'wishlist', 'coda'];
// 'wishlist' e 'coda' non hanno un pannello impostazioni proprio (coda è
// nativa, non un iframe con le sue impostazioni bulk) — quindi non hanno un
// bottone ⚙ nel proprio column-header (vedi app.html).
const SEZIONI_SENZA_IMPOSTAZIONI = ['wishlist', 'coda'];

function applicaTema(nome) {
  LISTA_TEMI.forEach(t => document.body.classList.remove(`theme-${t}`));
  if (nome !== 'purple') document.body.classList.add(`theme-${nome}`);
  document.body.classList.toggle('tema-attivo', nome !== 'purple');
}

const comportamentoBtn = document.getElementById('comportamentoBtn');
const comportamentoPopover = document.getElementById('comportamentoPopover');

// FIX: il chip account (in alto a destra) era cliccabile e apriva un
// popover "Account" col solo bottone "Controlla connessione" — tolto su
// richiesta (l'estensione non deve richiedere click manuali). Il chip resta
// come semplice etichetta informativa (vedi aggiornaAccountChip più sotto),
// quindi qui rimane solo il popover "Comportamento".
comportamentoBtn.addEventListener('click', (e) => {
  e.stopPropagation();
  comportamentoPopover.classList.toggle('visible');
});

document.addEventListener('click', (e) => {
  if (comportamentoPopover.classList.contains('visible') && !comportamentoPopover.contains(e.target) && e.target !== comportamentoBtn) {
    comportamentoPopover.classList.remove('visible');
  }
});

// ── PROPAGAZIONE LOCATION NUOVE (senza popover — tolto su richiesta) ────────
// Prima esisteva qui un popover "📍 Gestisci location" (crea/rinomina/
// elimina) con pulsanti dedicati. Tolto perché l'app non deve avere
// pulsanti di gestione manuale per l'utente: le location si creano da sole
// quando qualcuno ne scrive una nuova aggiungendo una carta (vedi
// _registraLocationSeNuova in aggiungi_carta_popup.js/aggiungi_sealed_popup.js/
// aggiungi_wishlist_popup.js) — qui resta solo la parte che avvisa TUTTE le
// sezioni con un campo Location di ricaricare la propria lista, così nessuno
// deve mai venire ad aprire l'estensione per un aggiornamento manuale.
// FIX: prima "Prezzi" (popup.js) non era tra le sezioni avvisate — la sua
// tendina filtro restava ferma alla versione letta all'apertura finché non
// si premeva a mano "↺ Aggiorna elenco" (bottone anch'esso tolto).
function _rinfrescaLocationOvunque() {
  ['prezzi', 'carte', 'sealed', 'wishlist'].forEach((sezione) => {
    const colonna = document.querySelector(`.column[data-sezione="${sezione}"]`);
    const iframe = colonna ? colonna.querySelector('iframe') : null;
    if (iframe && iframe.contentWindow) iframe.contentWindow.postMessage({ type: 'CARDSYNC_REFRESH_LOCATION' }, '*');
  });
}

// Una pagina "aggiungi" (Carte/Sealed/Wishlist), scrivendo una location
// nuova mai vista prima, chiede all'hub di propagarla alle altre sezioni.
window.addEventListener('message', (e) => {
  if (e.data && e.data.type === 'CARDSYNC_LOCATION_ADDED') _rinfrescaLocationOvunque();
});

// ── POPOVER 🎛️ COMPORTAMENTO ──────────────────────────────────────────────────
// Ritardo min/max, Timeout Cloudflare, Pausa ogni N carte, Avviso sonoro:
// prima erano ripetuti identici in 4 pannelli diversi (Controllo prezzi,
// Carte, Sealed, Wishlist) — stesse chiavi storage, quattro copie di UI da
// mantenere. Ora vivono solo qui, raggiungibili da qualunque sezione;
// ognuna delle pagine nasconde la propria copia quando è nell'hub (vedi
// tab_detect.js/embedded-in-hub) e continua a leggere le stesse chiavi
// storage come ha sempre fatto — nessuna modifica alla logica interna di
// nessuna pagina, solo dove si TROVA il controllo.
const CF_LABELS = ['1 min', '2 min', '3 min', '4 min', '5 min', '6 min', '7 min', '8 min', '9 min', '10 min'];
const PAUSA_OGNI_LABELS = ['25', '50', '75', '100', 'Mai'];
const COMPORTAMENTO_DEFAULT = {
  sliderDelayMinSec: 10,
  sliderDelayMaxSec: 20,
  sliderCfTimeout: 3,
  sliderPausaOgni: 2,
  avvisoSonoro: true,
};
// Migrazione dal vecchio slider unico a preset (indice 0–7, "sliderDelay")
// — stesso fallback già presente in ogni pagina, per chi aggiorna
// l'estensione senza aver mai aperto una pagina più recente.
const LEGACY_DELAY_RANGES_SEC = [[1,3],[3,7],[5,10],[8,15],[12,20],[20,30],[30,45],[45,60]];

function aggiornaLabelComportamento() {
  const vMin = document.getElementById('hubSliderDelayMin').value;
  const vMax = document.getElementById('hubSliderDelayMax').value;
  document.getElementById('hubValDelayMin').textContent = vMin + 's';
  document.getElementById('hubValDelayMax').textContent = vMax + 's';
  document.getElementById('hubValCfTimeout').textContent = CF_LABELS[document.getElementById('hubSliderCfTimeout').value - 1] || CF_LABELS[2];
  document.getElementById('hubValPausaOgni').textContent = PAUSA_OGNI_LABELS[document.getElementById('hubSliderPausaOgni').value] ?? PAUSA_OGNI_LABELS[1];
}

document.getElementById('hubSliderDelayMin').addEventListener('input', (e) => {
  const vMin = parseInt(e.target.value);
  const sliderMax = document.getElementById('hubSliderDelayMax');
  if (vMin > parseInt(sliderMax.value)) sliderMax.value = vMin;
  aggiornaLabelComportamento();
  chrome.storage.local.set({ sliderDelayMinSec: vMin, sliderDelayMaxSec: parseInt(sliderMax.value) });
});
document.getElementById('hubSliderDelayMax').addEventListener('input', (e) => {
  const vMax = parseInt(e.target.value);
  const sliderMin = document.getElementById('hubSliderDelayMin');
  if (vMax < parseInt(sliderMin.value)) sliderMin.value = vMax;
  aggiornaLabelComportamento();
  chrome.storage.local.set({ sliderDelayMinSec: parseInt(sliderMin.value), sliderDelayMaxSec: vMax });
});
document.getElementById('hubSliderCfTimeout').addEventListener('input', (e) => {
  aggiornaLabelComportamento();
  chrome.storage.local.set({ sliderCfTimeout: parseInt(e.target.value) });
});
document.getElementById('hubSliderPausaOgni').addEventListener('input', (e) => {
  aggiornaLabelComportamento();
  chrome.storage.local.set({ sliderPausaOgni: parseInt(e.target.value) });
});
document.getElementById('hubAvvisoSonoro').addEventListener('change', (e) => {
  chrome.storage.local.set({ avvisoSonoro: e.target.checked });
});

// ── RIPRISTINA PREDEFINITI (Comportamento) ────────────────────────────────────
// Stesso pattern/stessi valori del bottone equivalente già presente nel
// popup "Controllo prezzi" (popup.js, btnResetDefaults) — qui riporta ai
// default solo i controlli presenti in QUESTA tendina (ritardo min/max,
// timeout Cloudflare, pausa ogni N carte, avviso sonoro).
document.getElementById('hubBtnResetComportamento').addEventListener('click', () => {
  document.getElementById('hubSliderDelayMin').value  = COMPORTAMENTO_DEFAULT.sliderDelayMinSec;
  document.getElementById('hubSliderDelayMax').value  = COMPORTAMENTO_DEFAULT.sliderDelayMaxSec;
  document.getElementById('hubSliderCfTimeout').value = COMPORTAMENTO_DEFAULT.sliderCfTimeout;
  document.getElementById('hubSliderPausaOgni').value = COMPORTAMENTO_DEFAULT.sliderPausaOgni;
  document.getElementById('hubAvvisoSonoro').checked  = COMPORTAMENTO_DEFAULT.avvisoSonoro;
  aggiornaLabelComportamento();
  chrome.storage.local.set({
    sliderDelayMinSec: COMPORTAMENTO_DEFAULT.sliderDelayMinSec,
    sliderDelayMaxSec: COMPORTAMENTO_DEFAULT.sliderDelayMaxSec,
    sliderCfTimeout:   COMPORTAMENTO_DEFAULT.sliderCfTimeout,
    sliderPausaOgni:   COMPORTAMENTO_DEFAULT.sliderPausaOgni,
    avvisoSonoro:      COMPORTAMENTO_DEFAULT.avvisoSonoro,
  });
});
chrome.storage.local.get(
  ['sliderDelay', 'sliderDelayMinSec', 'sliderDelayMaxSec', 'sliderCfTimeout', 'sliderPausaOgni', 'avvisoSonoro', 'aiutaGruppo', 'cardsyncDarkMode'],
  (saved) => {
    let vMin = saved.sliderDelayMinSec;
    let vMax = saved.sliderDelayMaxSec;
    if (vMin === undefined || vMax === undefined) {
      if (typeof saved.sliderDelay === 'number' && LEGACY_DELAY_RANGES_SEC[saved.sliderDelay]) {
        [vMin, vMax] = LEGACY_DELAY_RANGES_SEC[saved.sliderDelay];
      } else {
        vMin = COMPORTAMENTO_DEFAULT.sliderDelayMinSec;
        vMax = COMPORTAMENTO_DEFAULT.sliderDelayMaxSec;
      }
      chrome.storage.local.set({ sliderDelayMinSec: vMin, sliderDelayMaxSec: vMax });
    }
    document.getElementById('hubSliderDelayMin').value = vMin;
    document.getElementById('hubSliderDelayMax').value = vMax;
    document.getElementById('hubSliderCfTimeout').value = saved.sliderCfTimeout ?? COMPORTAMENTO_DEFAULT.sliderCfTimeout;
    document.getElementById('hubSliderPausaOgni').value = saved.sliderPausaOgni ?? COMPORTAMENTO_DEFAULT.sliderPausaOgni;
    document.getElementById('hubAvvisoSonoro').checked = saved.avvisoSonoro !== false;
    aggiornaLabelComportamento();
  }
);

chrome.storage.onChanged.addListener((changes) => {
  if (changes.sliderDelayMinSec) document.getElementById('hubSliderDelayMin').value = changes.sliderDelayMinSec.newValue ?? 10;
  if (changes.sliderDelayMaxSec) document.getElementById('hubSliderDelayMax').value = changes.sliderDelayMaxSec.newValue ?? 20;
  if (changes.sliderCfTimeout) document.getElementById('hubSliderCfTimeout').value = changes.sliderCfTimeout.newValue ?? 3;
  if (changes.sliderPausaOgni) document.getElementById('hubSliderPausaOgni').value = changes.sliderPausaOgni.newValue ?? 2;
  if (changes.sliderDelayMinSec || changes.sliderDelayMaxSec || changes.sliderCfTimeout || changes.sliderPausaOgni) aggiornaLabelComportamento();
  if (changes.avvisoSonoro !== undefined) document.getElementById('hubAvvisoSonoro').checked = changes.avvisoSonoro.newValue !== false;
});

chrome.storage.local.get(['selectedTheme'], (saved) => {
  applicaTema(saved.selectedTheme || 'purple');
});
chrome.storage.onChanged.addListener((changes) => {
  if (changes.selectedTheme) location.reload(); // FIX: refresh vero invece di un cambio "a caldo" incompleto
});

// Tema scuro: modificatore indipendente dal tema colore (classe separata) —
// arriva dal sito insieme al login (vedi background.js, messaggio
// CARDSYNC_OPEN_APP) e viene scritto nella stessa chiave storage che questa
// pagina e tutti gli iframe già leggono — qui ci si limita a leggerla/
// applicarla, nessun controllo manuale in questa pagina.
chrome.storage.local.get(['cardsyncDarkMode'], (saved) => {
  document.body.classList.toggle('modo-scuro', saved.cardsyncDarkMode === true);
});
chrome.storage.onChanged.addListener((changes) => {
  if (changes.cardsyncDarkMode) location.reload();
});

// ── POPUP "STO PER APRIRE CARDMARKET" ────────────────────────────────────────
// Il sito scrive un timestamp in questa chiave ad ogni apertura dell'app
// (vedi CARDSYNC_OPEN_APP in background.js) — qui lo intercettiamo per
// mostrare un avviso non bloccante: subito dopo, in background, si apre una
// tab Cardmarket per verificare/completare il login, e a fine controllo il
// focus torna da solo sulla tab del sito (vedi
// _controlloLoginAutomaticoAperturaApp in background.js). Il controllo alla
// lettura iniziale (< 5s) evita di mostrarlo su una riapertura normale
// dell'hub, quando il timestamp salvato è ormai vecchio.
function _mostraToastLoginCheck() {
  if (document.getElementById('cardsync-login-check-toast')) return; // già visibile, non sovrapporre
  const toast = document.createElement('div');
  toast.id = 'cardsync-login-check-toast';
  toast.style.cssText = 'position:fixed; top:14px; right:14px; z-index:999999; max-width:280px; background:#fff; color:#1a1625; border-radius:12px; padding:12px 14px; box-shadow:0 12px 32px rgba(0,0,0,0.25); font-family:"DM Sans", sans-serif; font-size:12.5px; line-height:1.4;';
  toast.innerHTML = '<div style="font-weight:800; margin-bottom:3px;">🔐 Verifica login Cardmarket</div><div style="color:#6b6478;">Sto per aprire una pagina di Cardmarket per controllare (o farti fare) il login — al termine torni automaticamente sul sito.</div>';
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 4000);
}
chrome.storage.local.get(['cardsyncLoginCheckToast'], (saved) => {
  if (saved.cardsyncLoginCheckToast && Date.now() - saved.cardsyncLoginCheckToast < 5000) _mostraToastLoginCheck();
});
chrome.storage.onChanged.addListener((changes) => {
  if (changes.cardsyncLoginCheckToast) _mostraToastLoginCheck();
});

// ── MENU ACCOUNT (identità Supabase reale) ──────────────────────────────────
// Il chip mostra ora l'account Supabase REALMENTE loggato (la parte prima
// della @ dell'email) invece del vecchio "profilo" — un'etichetta scelta a
// mano, senza alcun collegamento con chi fosse davvero loggato. Molto più
// affidabile: non può disallinearsi da chi ha fatto login per davvero.
function aggiornaAccountChip(nome) {
  const nameEl   = document.getElementById('accountChipName');
  const avatarEl = document.getElementById('accountChipAvatar');
  if (nome) {
    nameEl.textContent = nome;
    avatarEl.textContent = nome.trim().charAt(0).toUpperCase() || '?';
  } else {
    nameEl.textContent = 'Nessuno';
    avatarEl.textContent = '?';
  }
}

async function _aggiornaAccountChipDaSessione() {
  const { data } = await supabaseClient.auth.getSession();
  const email = data.session?.user?.email || '';
  aggiornaAccountChip(email.split('@')[0]);
}
_aggiornaAccountChipDaSessione();

// FIX: il blocco "Controlla connessione" (popover Account) è stato tolto —
// l'estensione non deve richiedere click manuali. La stessa identica
// funzione resta comunque disponibile (anche se nascosta) nel popup
// principale (vedi #btnControllaConnessione in popup.js), invariata.

// ── CHANGELOG ─────────────────────────────────────────────────────────────────
// Stessa azione su ogni pagina (apre changelog.html in una tab a parte) —
// centralizzata qui invece che inoltrata all'iframe, non c'è nulla di
// specifico alla sezione attiva da preservare.
document.getElementById('changelogLink').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('changelog.html') });
});

// ── GEAR PER COLONNA — INOLTRATO ALLA PROPRIA IFRAME ─────────────────────────
// A differenza del changelog, il pannello ⚙ ha contenuto diverso per ogni
// sezione (tema+comportamento in "Controllo prezzi", impostazioni bulk nelle
// altre) — ogni colonna ha il proprio bottone, che inoltra il click SOLO
// alla propria iframe (vedi 'CARDSYNC_TOGGLE_SETTINGS' nei rispettivi
// *_popup.js). Prima esisteva un unico gear nell'header che inoltrava alla
// "sezione attiva" — non ha più senso ora che tutte le colonne sono visibili
// insieme, quindi ognuna ha il suo.
// FIX: l'ingranaggio ora vive dentro la tab stessa (non più in una riga
// separata) — il click NON blocca la propagazione apposta: così, oltre ad
// aprire le impostazioni, porta anche in vista la sezione a cui
// appartengono (altrimenti si aprirebbe un pannello impostazioni dentro una
// colonna nascosta, invisibile finché non si cambia scheda a mano).
document.querySelectorAll('.column-gear-btn').forEach((btn) => {
  btn.addEventListener('click', () => {
    const sezione = btn.dataset.sezione;
    const colonna = document.querySelector(`.column[data-sezione="${sezione}"]`);
    const iframe = colonna ? colonna.querySelector('iframe') : null;
    if (iframe && iframe.contentWindow) {
      iframe.contentWindow.postMessage({ type: 'CARDSYNC_TOGGLE_SETTINGS' }, '*');
    }
    // Rotazione puramente decorativa: l'hub non conosce lo stato reale
    // (aperto/chiuso) del pannello dentro l'iframe, gira solo per dare un
    // riscontro visivo al click.
    btn.classList.toggle('open');
  });
});

// ── SCHEDE IN ALTO: UNA SEZIONE VISIBILE ALLA VOLTA ──────────────────────────
// Cliccare una scheda mostra la sua colonna e nasconde le altre (solo CSS:
// display, l'iframe resta caricato — vedi commento in cima al file). La
// sezione attiva viene ricordata (localStorage) così riaprendo l'hub si
// riparte dall'ultima guardata, non sempre da "Coda pendente".
function sezioneValida(s) {
  return SEZIONI.includes(s) ? s : null;
}

function sezioneDaHash() {
  return sezioneValida((location.hash || '').replace('#', ''));
}

function attivaSezione(sezione, { aggiornaHash = true } = {}) {
  sezione = sezioneValida(sezione)
    || sezioneValida(localStorage.getItem('cardsyncUltimaSezione'))
    || 'coda'; // prima pagina di default (era SEZIONI[0] = 'prezzi')

  document.querySelectorAll('.column').forEach((colonna) => {
    colonna.classList.toggle('tab-attiva', colonna.dataset.sezione === sezione);
  });
  document.querySelectorAll('.hub-tab').forEach((tab) => {
    tab.classList.toggle('active', tab.dataset.tabSezione === sezione);
  });
  if (aggiornaHash && location.hash !== '#' + sezione) {
    history.replaceState(null, '', '#' + sezione);
  }
  localStorage.setItem('cardsyncUltimaSezione', sezione);
}

document.querySelectorAll('.hub-tab').forEach((tab) => {
  tab.addEventListener('click', () => attivaSezione(tab.dataset.tabSezione));
});

window.addEventListener('hashchange', () => attivaSezione(sezioneDaHash()));

// ── MESSAGGI DA popup.js ──────────────────────────────────────────────────────
// Quando l'hub è già aperto in una tab e l'utente clicca di nuovo un bottone
// nel popup principale (es. "📦 Sealed"), popup.js porta questa tab in primo
// piano e manda questo messaggio per portare in primo piano la scheda giusta.
chrome.runtime.onMessage.addListener((message) => {
  if (message && message.type === 'CARDSYNC_APRI_SEZIONE' && message.sezione) {
    attivaSezione(message.sezione);
  }
});

// ── FOOTER UNICO ──────────────────────────────────────────────────────────────
// Sostituisce i 5 footer duplicati (uno per pagina) — versione letta dal
// manifest invece che scritta a mano, per non rischiare che resti disallineata
// come già successo in passato con i footer delle singole pagine.
document.getElementById('appFooterCredit').textContent =
  'CardSync Pro v' + chrome.runtime.getManifest().version + ' · © Lunachiara';

document.getElementById('appBugReportLink').addEventListener('click', (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: e.currentTarget.href });
});

// Easter egg (stessa goliardata già presente nel footer di ogni pagina).
(function () {
  let clicks = 0;
  let timer = null;
  const footer = document.getElementById('appFooterCredit');
  footer.addEventListener('click', () => {
    clicks++;
    clearTimeout(timer);
    timer = setTimeout(() => { clicks = 0; }, 600);
    if (clicks >= 3) {
      clicks = 0;
      chrome.tabs.create({ url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', active: true });
    }
  });
})();

// ── BOOT ──────────────────────────────────────────────────────────────────────
// Ogni iframe carica il proprio src SUBITO all'avvio, ANCHE se la sua scheda
// non è quella mostrata all'apertura — così i controlli automatici (coda
// carte in attesa, ordine di controllo prezzi da autorunnare) partono
// indipendentemente da quale scheda l'utente guarda per prima. La scheda
// mostrata all'apertura segue: #hash nell'URL, poi l'ultima sezione salvata,
// poi "Coda pendente" di default (vedi attivaSezione).
document.querySelectorAll('.column iframe[data-src]').forEach((iframe) => {
  if (!iframe.src) iframe.src = iframe.dataset.src;
});
attivaSezione(sezioneDaHash(), { aggiornaHash: false });
