// ── app.js ────────────────────────────────────────────────────────────────────
// Pagina hub (app.html): ospita le 5 sezioni (Controllo prezzi/Carte/Sealed/
// Wishlist/Anteprima) come iframe nella STESSA tab, con una tab-bar per
// passare dall'una all'altra senza aprire nuove tab del browser. Ogni iframe
// punta al file .html già esistente (nessuna modifica alla logica interna di
// bulk/Cloudflare/worker tab) — qui si gestisce tema condiviso, header unico
// (badge profilo + ⚙ + 📜, al posto degli header duplicati di ogni pagina,
// nascosti via tab_detect.js/embedded-in-hub), switch di visibilità tra gli
// iframe e caricamento lazy (l'iframe di una sezione viene navigato sul suo
// URL reale solo alla prima apertura di quella sezione, non tutte insieme al
// boot: evita di avviare 5 pagine bulk/anteprima/controllo-prezzi insieme).

// ── LOGIN SUPABASE ────────────────────────────────────────────────────────────
assicuraLoginSupabase();

const LISTA_TEMI = ['purple', 'green', 'blue', 'contrast', 'dark', 'sakura', 'wine', 'autunno', 'estate', 'heartgold', 'soulsilver', 'steel', 'electric', 'grass', 'pokemon', 'team-rocket'];
const SEZIONI = ['prezzi', 'carte', 'sealed', 'wishlist', 'anteprima'];
const SEZIONE_DEFAULT = 'prezzi';
// anteprima_popup.html non ha un pannello impostazioni proprio — il gear
// unico dell'hub non ha nulla da inoltrare quando questa sezione è attiva,
// quindi resta nascosto (vedi switchTo più sotto).
// anteprima_popup.html non ha mai avuto un pannello impostazioni proprio.
// aggiungi_wishlist_popup.html invece lo aveva, ma era fatto SOLO di
// controlli condivisi (Delay/Pausa/Avviso sonoro) — ora tutti spostati nel
// popover 🎛️ Comportamento qui sotto — quindi anche il suo gear locale
// resta vuoto e va disattivato allo stesso modo.
const SEZIONI_SENZA_IMPOSTAZIONI = ['anteprima', 'wishlist'];

let sezioneCorrente = SEZIONE_DEFAULT;

function applicaTema(nome) {
  LISTA_TEMI.forEach(t => document.body.classList.remove(`theme-${t}`));
  if (nome !== 'purple') document.body.classList.add(`theme-${nome}`);
}

// ── SELETTORE TEMA GLOBALE ────────────────────────────────────────────────────
// Prima il tema si poteva cambiare solo dalla sezione "Controllo prezzi" (unica
// pagina con la griglia temi nel proprio pannello ⚙) — qui nell'hub c'è un
// bottone 🎨 sempre raggiungibile, indipendentemente dalla sezione attiva.
// Scrive la stessa chiave storage già condivisa da tutte le pagine: ogni
// iframe si aggiorna da solo (ognuna ha già il proprio chrome.storage.onChanged
// per 'selectedTheme'), nessun postMessage necessario. Stessi 16 temi/colori/
// etichette della griglia in popup.html, per coerenza visiva.
const TEMI_INFO = [
  ['purple',      '#9472dc', null,        'Psychic Energy'],
  ['green',       '#2d9d52', null,        'Emerald'],
  ['blue',        '#2d7ebc', null,        'Sapphire'],
  ['wine',        '#7f1f36', '#e6bcc6',   'Ruby'],
  ['heartgold',   '#b8860b', '#f5dfa0',   'HeartGold'],
  ['soulsilver',  '#6b7d92', '#d4dce3',   'SoulSilver'],
  ['sakura',      '#d9709a', '#fbdbe9',   'Fairy Type'],
  ['autunno',     '#b8652f', '#f2cea0',   'Fighting Type'],
  ['estate',      '#14a89c', '#a4ecdc',   'Water Type'],
  ['steel',       '#6e7f8d', '#cfd8dc',   'Steel Type'],
  ['electric',    '#e0ac00', '#fdf0a0',   'Electric Type'],
  ['grass',       '#3f9e6f', '#a8e0c0',   'Grass Type'],
  ['dark',        '#1e1e2e', '#a78bfa',   'Dark Type'],
  ['team-rocket', '#e53935', '#1a1a1a',   'Team Rocket'],
  ['pokemon',     '#cc0000', '#111111',   'Pokéball'],
  ['contrast',    '#0047b3', '#000',      'Wise Glasses'],
];

function aggiornaThemeGridActive(temaAttivo) {
  document.querySelectorAll('.theme-btn').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.tema === temaAttivo);
  });
}

function costruisciThemeGrid() {
  const grid = document.getElementById('themeGrid');
  TEMI_INFO.forEach(([id, bg, borderColor, label]) => {
    const btn = document.createElement('button');
    btn.className = 'theme-btn';
    btn.dataset.tema = id;
    const swatch = document.createElement('span');
    swatch.className = 'swatch';
    swatch.style.background = bg;
    if (borderColor) swatch.style.borderColor = borderColor;
    btn.appendChild(swatch);
    btn.appendChild(document.createTextNode(label));
    btn.addEventListener('click', () => {
      applicaTema(id);
      aggiornaThemeGridActive(id);
      chrome.storage.local.set({ selectedTheme: id });
    });
    grid.appendChild(btn);
  });
}
costruisciThemeGrid();

const themeBtn = document.getElementById('themeBtn');
const themePopover = document.getElementById('themePopover');
const accountChip = document.getElementById('accountChip');
const accountPopover = document.getElementById('accountPopover');
const comportamentoBtn = document.getElementById('comportamentoBtn');
const comportamentoPopover = document.getElementById('comportamentoPopover');
const locationBtn = document.getElementById('locationBtn');
const locationPopover = document.getElementById('locationPopover');

// Un solo popover aperto alla volta (comportamento, location, tema o
// account) — aprirne uno chiude gli altri, invece di sovrapporsi.
function chiudiTuttiIPopover(tranne) {
  [themePopover, accountPopover, comportamentoPopover, locationPopover].forEach((p) => { if (p !== tranne) p.classList.remove('visible'); });
}

themeBtn.addEventListener('click', (e) => {
  e.stopPropagation();
  const apriva = themePopover.classList.contains('visible');
  chiudiTuttiIPopover();
  themePopover.classList.toggle('visible', !apriva);
});

accountChip.addEventListener('click', (e) => {
  e.stopPropagation();
  const apriva = accountPopover.classList.contains('visible');
  chiudiTuttiIPopover();
  accountPopover.classList.toggle('visible', !apriva);
});

comportamentoBtn.addEventListener('click', (e) => {
  e.stopPropagation();
  const apriva = comportamentoPopover.classList.contains('visible');
  chiudiTuttiIPopover();
  comportamentoPopover.classList.toggle('visible', !apriva);
});

locationBtn.addEventListener('click', (e) => {
  e.stopPropagation();
  const apriva = locationPopover.classList.contains('visible');
  chiudiTuttiIPopover();
  locationPopover.classList.toggle('visible', !apriva);
  if (!apriva) _caricaElencoLocationHub();
});

document.addEventListener('click', (e) => {
  if (themePopover.classList.contains('visible') && !themePopover.contains(e.target) && e.target !== themeBtn) {
    themePopover.classList.remove('visible');
  }
  if (accountPopover.classList.contains('visible') && !accountPopover.contains(e.target) && !accountChip.contains(e.target)) {
    accountPopover.classList.remove('visible');
  }
  if (comportamentoPopover.classList.contains('visible') && !comportamentoPopover.contains(e.target) && e.target !== comportamentoBtn) {
    comportamentoPopover.classList.remove('visible');
  }
  if (locationPopover.classList.contains('visible') && !locationPopover.contains(e.target) && e.target !== locationBtn) {
    locationPopover.classList.remove('visible');
  }
});

// ── POPOVER 📍 GESTISCI LOCATION ──────────────────────────────────────────────
// Rinomina/elimina/aggiunge un valore nella scheda dedicata "LOCATION"
// (colonna B, valori da riga 2) — quella collegata alla validazione dati
// della tendina Location nell'Inventario. Richiede le quattro azioni in
// apps_script_location_snippet.gs: 'elencaLocationTab', 'aggiungiLocationTab',
// 'rinominaLocationTab', 'eliminaLocationTab'. Rinomina/elimina propagano
// anche alle righe dell'Inventario che usano quel valore ("eliminare" le
// riporta a "?", non cancella righe). Dopo ogni modifica, avvisa le pagine
// Carte/Sealed/Wishlist (le uniche con un proprio campo Location) di
// ricaricare la loro datalist.
const LOCATION_TAB_NAME = 'LOCATION';
const LOCATION_TAB_COL = 'B';
const LOCATION_TAB_RIGA_INIZIO = 2;

function _rinfrescaLocationOvunque() {
  ['carte', 'sealed', 'wishlist'].forEach((sezione) => {
    const slot = document.querySelector(`.frame-slot[data-sezione="${sezione}"]`);
    const iframe = slot ? slot.querySelector('iframe') : null;
    if (iframe && iframe.contentWindow) iframe.contentWindow.postMessage({ type: 'CARDSYNC_REFRESH_LOCATION' }, '*');
  });
  if (locationPopover.classList.contains('visible')) _caricaElencoLocationHub();
}

// Una pagina "aggiungi" (Carte/Sealed/Wishlist), scrivendo una location
// nuova mai vista prima, chiede all'hub di registrarla — vedi
// 'CARDSYNC_LOCATION_ADDED' più sotto.
window.addEventListener('message', (e) => {
  if (e.data && e.data.type === 'CARDSYNC_LOCATION_ADDED') _rinfrescaLocationOvunque();
});

async function _caricaElencoLocationHub() {
  const wrap = document.getElementById('locationListWrap');
  wrap.innerHTML = '<p class="account-popover-hint">⏳ Carico…</p>';
  try {
    const data = await chiamaSupabase('elencaLocationTab', {});
    if (!data.ok) { wrap.innerHTML = '<p class="account-popover-hint">❌ ' + (data.errore || 'Errore nel caricamento.') + '</p>'; return; }
    const location = data.location || [];
    if (location.length === 0) { wrap.innerHTML = '<p class="account-popover-hint">Nessuna location salvata.</p>'; return; }
    wrap.innerHTML = '';
    location.forEach((nome) => wrap.appendChild(_creaRigaLocationHub(nome)));
  } catch (e) {
    wrap.innerHTML = '<p class="account-popover-hint">❌ ' + e.message + '</p>';
  }
}

document.getElementById('inputNuovaLocationHub').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') document.getElementById('btnAggiungiLocationHub').click();
});

document.getElementById('btnAggiungiLocationHub').addEventListener('click', async () => {
  const input = document.getElementById('inputNuovaLocationHub');
  const nome = input.value.trim();
  if (!nome) return;
  const btn = document.getElementById('btnAggiungiLocationHub');
  btn.disabled = true;
  try {
    const data = await chiamaSupabase('aggiungiLocationTab', { nome });
    if (!data.ok) { alert('Errore: ' + (data.errore || 'sconosciuto')); btn.disabled = false; return; }
    input.value = '';
    _rinfrescaLocationOvunque();
  } catch (e) {
    alert('Errore: ' + e.message);
  }
  btn.disabled = false;
});

function _creaRigaLocationHub(nome) {
  const div = document.createElement('div');
  div.className = 'location-item';

  const nameEl = document.createElement('span');
  nameEl.className = 'location-item-name';
  nameEl.textContent = nome;
  nameEl.title = nome;

  const btnRinomina = document.createElement('button');
  btnRinomina.className = 'location-item-btn';
  btnRinomina.title = 'Rinomina';
  btnRinomina.textContent = '✏️';

  const btnElimina = document.createElement('button');
  btnElimina.className = 'location-item-btn';
  btnElimina.title = 'Elimina (le righe tornano a "?")';
  btnElimina.textContent = '🗑️';

  btnRinomina.addEventListener('click', async () => {
    const nuovoNome = (prompt('Nuovo nome per "' + nome + '":', nome) || '').trim();
    if (!nuovoNome || nuovoNome === nome) return;
    btnRinomina.disabled = true;
    btnElimina.disabled = true;
    try {
      const data = await chiamaSupabase('rinominaLocationTab', { vecchioNome: nome, nuovoNome });
      if (!data.ok) { alert('Errore: ' + (data.errore || 'sconosciuto')); btnRinomina.disabled = false; btnElimina.disabled = false; return; }
      _rinfrescaLocationOvunque();
      _caricaElencoLocationHub();
    } catch (e) {
      alert('Errore: ' + e.message);
      btnRinomina.disabled = false;
      btnElimina.disabled = false;
    }
  });

  btnElimina.addEventListener('click', async () => {
    if (!confirm('Eliminare "' + nome + '"? Le carte che la usano torneranno a "?" — non vengono cancellate.')) return;
    btnRinomina.disabled = true;
    btnElimina.disabled = true;
    try {
      const data = await chiamaSupabase('eliminaLocationTab', { nome });
      if (!data.ok) { alert('Errore: ' + (data.errore || 'sconosciuto')); btnRinomina.disabled = false; btnElimina.disabled = false; return; }
      _rinfrescaLocationOvunque();
      _caricaElencoLocationHub();
    } catch (e) {
      alert('Errore: ' + e.message);
      btnRinomina.disabled = false;
      btnElimina.disabled = false;
    }
  });

  div.appendChild(nameEl);
  div.appendChild(btnRinomina);
  div.appendChild(btnElimina);
  return div;
}

document.getElementById('btnAggiornaLocationHub').addEventListener('click', _caricaElencoLocationHub);

// ── POPOVER 🎛️ COMPORTAMENTO ──────────────────────────────────────────────────
// Ritardo min/max, Timeout Cloudflare, Pausa ogni N carte, Avviso sonoro:
// prima erano ripetuti identici in 4 pannelli diversi (Controllo prezzi,
// Carte, Sealed, Wishlist) — stesse chiavi storage, quattro copie di UI da
// mantenere. Ora vivono solo qui, raggiungibili da qualunque sezione;
// ognuna delle pagine nasconde la propria copia quando è nell'hub (vedi
// tab_detect.js/embedded-in-hub) e continua a leggere le stesse chiavi
// storage come ha sempre fatto — nessuna modifica alla logica interna di
// nessuna pagina, solo dove si TROVA il controllo.
const CF_LABELS = ['1 min', '2 min', '3 min', '4 min', '5 min', '6 min', '7 min', '8 min', '9 min', '10 min'];
const PAUSA_OGNI_LABELS = ['25', '50', '75', '100', 'Mai'];
const COMPORTAMENTO_DEFAULT = {
  sliderDelayMinSec: 10,
  sliderDelayMaxSec: 20,
  sliderCfTimeout: 3,
  sliderPausaOgni: 2,
  avvisoSonoro: true,
};
// Migrazione dal vecchio slider unico a preset (indice 0–7, "sliderDelay")
// — stesso fallback già presente in ogni pagina, per chi aggiorna
// l'estensione senza aver mai aperto una pagina più recente.
const LEGACY_DELAY_RANGES_SEC = [[1,3],[3,7],[5,10],[8,15],[12,20],[20,30],[30,45],[45,60]];

function aggiornaLabelComportamento() {
  const vMin = document.getElementById('hubSliderDelayMin').value;
  const vMax = document.getElementById('hubSliderDelayMax').value;
  document.getElementById('hubValDelayMin').textContent = vMin + 's';
  document.getElementById('hubValDelayMax').textContent = vMax + 's';
  document.getElementById('hubValCfTimeout').textContent = CF_LABELS[document.getElementById('hubSliderCfTimeout').value - 1] || CF_LABELS[2];
  document.getElementById('hubValPausaOgni').textContent = PAUSA_OGNI_LABELS[document.getElementById('hubSliderPausaOgni').value] ?? PAUSA_OGNI_LABELS[1];
}

document.getElementById('hubSliderDelayMin').addEventListener('input', (e) => {
  const vMin = parseInt(e.target.value);
  const sliderMax = document.getElementById('hubSliderDelayMax');
  if (vMin > parseInt(sliderMax.value)) sliderMax.value = vMin;
  aggiornaLabelComportamento();
  chrome.storage.local.set({ sliderDelayMinSec: vMin, sliderDelayMaxSec: parseInt(sliderMax.value) });
});
document.getElementById('hubSliderDelayMax').addEventListener('input', (e) => {
  const vMax = parseInt(e.target.value);
  const sliderMin = document.getElementById('hubSliderDelayMin');
  if (vMax < parseInt(sliderMin.value)) sliderMin.value = vMax;
  aggiornaLabelComportamento();
  chrome.storage.local.set({ sliderDelayMinSec: parseInt(sliderMin.value), sliderDelayMaxSec: vMax });
});
document.getElementById('hubSliderCfTimeout').addEventListener('input', (e) => {
  aggiornaLabelComportamento();
  chrome.storage.local.set({ sliderCfTimeout: parseInt(e.target.value) });
});
document.getElementById('hubSliderPausaOgni').addEventListener('input', (e) => {
  aggiornaLabelComportamento();
  chrome.storage.local.set({ sliderPausaOgni: parseInt(e.target.value) });
});
document.getElementById('hubAvvisoSonoro').addEventListener('change', (e) => {
  chrome.storage.local.set({ avvisoSonoro: e.target.checked });
});
document.getElementById('hubAiutaGruppo').addEventListener('change', (e) => {
  chrome.storage.local.set({ aiutaGruppo: e.target.checked });
});
document.getElementById('hubTemaScuro').addEventListener('change', (e) => {
  document.body.classList.toggle('modo-scuro', e.target.checked);
  chrome.storage.local.set({ cardsyncDarkMode: e.target.checked });
});

chrome.storage.local.get(
  ['sliderDelay', 'sliderDelayMinSec', 'sliderDelayMaxSec', 'sliderCfTimeout', 'sliderPausaOgni', 'avvisoSonoro', 'aiutaGruppo', 'cardsyncDarkMode'],
  (saved) => {
    let vMin = saved.sliderDelayMinSec;
    let vMax = saved.sliderDelayMaxSec;
    if (vMin === undefined || vMax === undefined) {
      if (typeof saved.sliderDelay === 'number' && LEGACY_DELAY_RANGES_SEC[saved.sliderDelay]) {
        [vMin, vMax] = LEGACY_DELAY_RANGES_SEC[saved.sliderDelay];
      } else {
        vMin = COMPORTAMENTO_DEFAULT.sliderDelayMinSec;
        vMax = COMPORTAMENTO_DEFAULT.sliderDelayMaxSec;
      }
      chrome.storage.local.set({ sliderDelayMinSec: vMin, sliderDelayMaxSec: vMax });
    }
    document.getElementById('hubSliderDelayMin').value = vMin;
    document.getElementById('hubSliderDelayMax').value = vMax;
    document.getElementById('hubSliderCfTimeout').value = saved.sliderCfTimeout ?? COMPORTAMENTO_DEFAULT.sliderCfTimeout;
    document.getElementById('hubSliderPausaOgni').value = saved.sliderPausaOgni ?? COMPORTAMENTO_DEFAULT.sliderPausaOgni;
    document.getElementById('hubAvvisoSonoro').checked = saved.avvisoSonoro !== false;
    // FIX (Fase 8 — consenso esplicito): mai attivo di default, stesso
    // principio già seguito ovunque per questo interruttore specifico.
    document.getElementById('hubAiutaGruppo').checked = saved.aiutaGruppo === true;
    document.getElementById('hubTemaScuro').checked = saved.cardsyncDarkMode === true;
    aggiornaLabelComportamento();
  }
);

chrome.storage.onChanged.addListener((changes) => {
  if (changes.sliderDelayMinSec) document.getElementById('hubSliderDelayMin').value = changes.sliderDelayMinSec.newValue ?? 10;
  if (changes.sliderDelayMaxSec) document.getElementById('hubSliderDelayMax').value = changes.sliderDelayMaxSec.newValue ?? 20;
  if (changes.sliderCfTimeout) document.getElementById('hubSliderCfTimeout').value = changes.sliderCfTimeout.newValue ?? 3;
  if (changes.sliderPausaOgni) document.getElementById('hubSliderPausaOgni').value = changes.sliderPausaOgni.newValue ?? 2;
  if (changes.sliderDelayMinSec || changes.sliderDelayMaxSec || changes.sliderCfTimeout || changes.sliderPausaOgni) aggiornaLabelComportamento();
  if (changes.avvisoSonoro !== undefined) document.getElementById('hubAvvisoSonoro').checked = changes.avvisoSonoro.newValue !== false;
  if (changes.aiutaGruppo !== undefined) document.getElementById('hubAiutaGruppo').checked = changes.aiutaGruppo.newValue === true;
  if (changes.cardsyncDarkMode !== undefined) document.getElementById('hubTemaScuro').checked = changes.cardsyncDarkMode.newValue === true;
});

chrome.storage.local.get(['selectedTheme'], (saved) => {
  const tema = saved.selectedTheme || 'purple';
  applicaTema(tema);
  aggiornaThemeGridActive(tema);
});
chrome.storage.onChanged.addListener((changes) => {
  if (changes.selectedTheme) {
    const tema = changes.selectedTheme.newValue || 'purple';
    applicaTema(tema);
    aggiornaThemeGridActive(tema);
  }
});

// Tema scuro: modificatore indipendente dal tema colore (classe separata,
// vedi popup.js per il toggle vero e proprio nelle Impostazioni) — qui ci
// si limita a leggerlo/applicarlo, sincronizzato in tempo reale.
chrome.storage.local.get(['cardsyncDarkMode'], (saved) => {
  document.body.classList.toggle('modo-scuro', saved.cardsyncDarkMode === true);
});
chrome.storage.onChanged.addListener((changes) => {
  if (changes.cardsyncDarkMode) {
    document.body.classList.toggle('modo-scuro', changes.cardsyncDarkMode.newValue === true);
  }
});

// ── MENU ACCOUNT (identità Supabase reale) ──────────────────────────────────
// Il chip mostra ora l'account Supabase REALMENTE loggato (la parte prima
// della @ dell'email) invece del vecchio "profilo" — un'etichetta scelta a
// mano, senza alcun collegamento con chi fosse davvero loggato. Molto più
// affidabile: non può disallinearsi da chi ha fatto login per davvero.
function aggiornaAccountChip(nome) {
  const nameEl   = document.getElementById('accountChipName');
  const avatarEl = document.getElementById('accountChipAvatar');
  if (nome) {
    nameEl.textContent = nome;
    avatarEl.textContent = nome.trim().charAt(0).toUpperCase() || '?';
  } else {
    nameEl.textContent = 'Nessuno';
    avatarEl.textContent = '?';
  }
}

async function _aggiornaAccountChipDaSessione() {
  const { data } = await supabaseClient.auth.getSession();
  const email = data.session?.user?.email || '';
  aggiornaAccountChip(email.split('@')[0]);
}
_aggiornaAccountChipDaSessione();

// ── SISTEMA PROFILI — GUSCIO VUOTO ──────────────────────────────────────────
// Il vecchio sistema (registro profili su Google Apps Script) è stato
// rimosso con la migrazione a Supabase. La tendina resta come punto di
// aggancio per un futuro sistema profili basato su Supabase.
document.getElementById('hubSelectProfilo')?.addEventListener('change', () => {
  alert('Il sistema profili è in aggiornamento — non ancora disponibile.');
});

// ── CONTROLLA CONNESSIONE ─────────────────────────────────────────────────────
// Stesso controllo in due passi del popup principale (Supabase + login
// Cardmarket), col solo esito mostrato sul bottone stesso: il popover non ha
// un'area di stato dedicata come #status nel popup.
document.getElementById('hubBtnControllaConnessione').addEventListener('click', async () => {
  const btn = document.getElementById('hubBtnControllaConnessione');
  const testoOriginale = '🔌 Controlla connessione';

  btn.disabled = true;
  btn.textContent = '⏳ Controllo Supabase...';
  try {
    const data = await chiamaSupabase('elencaLocation', {});
    if (!data.ok) {
      btn.textContent = '❌ ' + (data.errore || 'Errore Supabase');
      setTimeout(() => { btn.textContent = testoOriginale; btn.disabled = false; }, 3500);
      return;
    }
  } catch (e) {
    btn.textContent = '❌ Rete non raggiungibile';
    setTimeout(() => { btn.textContent = testoOriginale; btn.disabled = false; }, 3500);
    return;
  }

  btn.textContent = '🔎 Controllo login Cardmarket...';
  chrome.runtime.sendMessage({ type: 'APRI_TAB_CONTROLLO_LOGIN' }, (risposta) => {
    if (risposta && risposta.loggato === true) btn.textContent = '✅ Connesso e loggato';
    else if (risposta && risposta.loggato === false) btn.textContent = '🔒 Non loggato — accedi nella tab aperta';
    else btn.textContent = '❓ Login non verificabile';
    setTimeout(() => { btn.textContent = testoOriginale; btn.disabled = false; }, 3500);
  });
});

document.getElementById('hubBtnSalvaProfilo')?.addEventListener('click', () => {
  alert('Il sistema profili è in aggiornamento — non ancora disponibile.');
});

// ── CHANGELOG ─────────────────────────────────────────────────────────────────
// Stessa azione su ogni pagina (apre changelog.html in una tab a parte) —
// centralizzata qui invece che inoltrata all'iframe, non c'è nulla di
// specifico alla sezione attiva da preservare.
document.getElementById('changelogLink').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('changelog.html') });
});

// ── GEAR — INOLTRATO ALL'IFRAME ATTIVO ───────────────────────────────────────
// A differenza del changelog, il pannello ⚙ ha contenuto diverso per ogni
// sezione (tema+comportamento in "Controllo prezzi", impostazioni bulk nelle
// altre) — l'hub non lo ricostruisce, si limita a inoltrare il click alla
// pagina che sta mostrando in quel momento (vedi 'CARDSYNC_TOGGLE_SETTINGS'
// nei rispettivi *_popup.js).
const gearBtn = document.getElementById('gearBtn');

gearBtn.addEventListener('click', () => {
  if (SEZIONI_SENZA_IMPOSTAZIONI.includes(sezioneCorrente)) return;
  const slot = document.querySelector(`.frame-slot[data-sezione="${sezioneCorrente}"]`);
  const iframe = slot ? slot.querySelector('iframe') : null;
  if (iframe && iframe.contentWindow) {
    iframe.contentWindow.postMessage({ type: 'CARDSYNC_TOGGLE_SETTINGS' }, '*');
  }
  // Rotazione puramente decorativa: l'hub non conosce lo stato reale
  // (aperto/chiuso) del pannello dentro l'iframe, gira solo per dare un
  // riscontro visivo al click.
  gearBtn.classList.toggle('open');
});

// ── SWITCH SEZIONE ────────────────────────────────────────────────────────────
function sezioneValida(s) {
  return SEZIONI.includes(s) ? s : SEZIONE_DEFAULT;
}

function sezioneDaHash() {
  return sezioneValida((location.hash || '').replace('#', ''));
}

function caricaIframeSeServe(sezione) {
  const slot = document.querySelector(`.frame-slot[data-sezione="${sezione}"]`);
  if (!slot) return;
  const iframe = slot.querySelector('iframe');
  if (iframe && !iframe.src && iframe.dataset.src) {
    iframe.src = iframe.dataset.src;
  }
}

function switchTo(sezione, { aggiornaHash = true } = {}) {
  sezione = sezioneValida(sezione);
  sezioneCorrente = sezione;

  document.querySelectorAll('.tab-btn').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.sezione === sezione);
  });
  document.querySelectorAll('.frame-slot').forEach((slot) => {
    slot.classList.toggle('active', slot.dataset.sezione === sezione);
  });

  gearBtn.classList.toggle('hidden-for-section', SEZIONI_SENZA_IMPOSTAZIONI.includes(sezione));
  gearBtn.classList.remove('open');

  caricaIframeSeServe(sezione);

  if (aggiornaHash && location.hash !== '#' + sezione) {
    history.replaceState(null, '', '#' + sezione);
  }
}

document.getElementById('tabBar').addEventListener('click', (e) => {
  const btn = e.target.closest('.tab-btn');
  if (!btn) return;
  switchTo(btn.dataset.sezione);
});

window.addEventListener('hashchange', () => switchTo(sezioneDaHash()));

// ── MESSAGGI DA popup.js ──────────────────────────────────────────────────────
// Quando l'hub è già aperto in una tab e l'utente clicca di nuovo un bottone
// nel popup principale (es. "📦 Sealed"), popup.js porta questa tab in primo
// piano e manda questo messaggio per cambiare sezione, invece di aprirne
// un'altra.
chrome.runtime.onMessage.addListener((message) => {
  if (message && message.type === 'CARDSYNC_APRI_SEZIONE' && message.sezione) {
    switchTo(message.sezione);
  }
});

// ── FOOTER UNICO ──────────────────────────────────────────────────────────────
// Sostituisce i 5 footer duplicati (uno per pagina) — versione letta dal
// manifest invece che scritta a mano, per non rischiare che resti disallineata
// come già successo in passato con i footer delle singole pagine.
document.getElementById('appFooterCredit').textContent =
  'CardSync Pro v' + chrome.runtime.getManifest().version + ' · © Lunachiara';

document.getElementById('appBugReportLink').addEventListener('click', (e) => {
  e.preventDefault();
  chrome.tabs.create({ url: e.currentTarget.href });
});

// Easter egg (stessa goliardata già presente nel footer di ogni pagina).
(function () {
  let clicks = 0;
  let timer = null;
  const footer = document.getElementById('appFooterCredit');
  footer.addEventListener('click', () => {
    clicks++;
    clearTimeout(timer);
    timer = setTimeout(() => { clicks = 0; }, 600);
    if (clicks >= 3) {
      clicks = 0;
      chrome.tabs.create({ url: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ', active: true });
    }
  });
})();

// ── BOOT ──────────────────────────────────────────────────────────────────────
switchTo(sezioneDaHash(), { aggiornaHash: false });

// Su richiesta: aprire l'estensione non deve obbligare a cliccare
// "Aggiungi Carte" o "Prezzi" perché i rispettivi controlli automatici
// partano. Questi due iframe vengono quindi caricati SUBITO all'avvio, anche
// se non sono la sezione visibile in quel momento — caricarli fa partire i
// loro script, che da soli controllano se c'è lavoro in attesa (righe
// pending in 'coda_carte', oppure un ordine 'controlla_prezzi' da autorunnare)
// indipendentemente da quale sezione l'utente vede per prima aprendo l'app.
// caricaIframeSeServe non fa nulla se l'iframe ha già un src (quindi è
// sicura da richiamare anche per la sezione già mostrata da switchTo sopra).
caricaIframeSeServe('carte');
caricaIframeSeServe('prezzi');
caricaIframeSeServe('wishlist');
