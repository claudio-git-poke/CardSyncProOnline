// ── dark-mode.js — applica il tema scuro salvato, su qualunque pagina ──────
// Incluso in tutte le pagine dell'estensione (popup, app.html/iframe,
// aggiungi_*_popup.html) — ognuna legge la stessa preferenza salvata e
// applica/toglie la classe da sola, così restano sempre sincronizzate.
(function () {
  function applica(attivo) {
    document.body.classList.toggle('cardsync-dark', !!attivo);
  }

  chrome.storage.local.get(['cardsyncDarkMode'], (r) => {
    applica(r.cardsyncDarkMode === true);
  });

  // Se il tema viene cambiato da UN'ALTRA pagina/iframe mentre questa è
  // aperta, si aggiorna da sola — niente bisogno di ricaricare.
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.cardsyncDarkMode) {
      applica(changes.cardsyncDarkMode.newValue === true);
    }
  });

  // Esposta globalmente: il toggle nelle Impostazioni la richiama al click.
  window.cardsyncImpostaTemaScuro = function (attivo) {
    chrome.storage.local.set({ cardsyncDarkMode: !!attivo });
    applica(attivo); // applica subito anche qui, non aspetta il round-trip dello storage
  };
})();
